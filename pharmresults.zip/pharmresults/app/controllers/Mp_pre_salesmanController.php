<?php 
/**
 * Mp_pre_salesman Page Controller
 * @category  Controller
 */
class Mp_pre_salesmanController extends BaseController{
	function __construct(){
		parent::__construct();
		$this->tablename = "mp_pre_salesman";
	}
	/**
     * List page records
     * @param $fieldname (filter record by a field) 
     * @param $fieldvalue (filter field value)
     * @return BaseView
     */
	function index($fieldname = null , $fieldvalue = null){
		$request = $this->request;
		$db = $this->GetModel();
		$tablename = $this->tablename;
		$fields = array("id", 
			"date", 
			"in_time", 
			"discount", 
			"status", 
			"description", 
			"agentname", 
			"cus_id", 
			"cus_picture", 
			"delivered_to", 
			"delivered_by", 
			"delivered_date", 
			"delivered_description", 
			"shippingcharges", 
			"prescription_id", 
			"region_id", 
			"vehicle_id", 
			"driver_id", 
			"payment_method", 
			"total_gross_amt", 
			"total_bill", 
			"total_paid", 
			"source", 
			"store_id", 
			"sales_man_id", 
			"total_tax", 
			"doctor_details", 
			"patient_details", 
			"taxes_names", 
			"cash", 
			"cheque_amount", 
			"credit_amount", 
			"schemes", 
			"bank_deposit", 
			"return_stock_val");
		$pagination = $this->get_pagination(MAX_RECORD_COUNT); // get current pagination e.g array(page_number, page_limit)
		//search table record
		if(!empty($request->search)){
			$text = trim($request->search); 
			$search_condition = "(
				mp_pre_salesman.id LIKE ? OR 
				mp_pre_salesman.date LIKE ? OR 
				mp_pre_salesman.in_time LIKE ? OR 
				mp_pre_salesman.discount LIKE ? OR 
				mp_pre_salesman.status LIKE ? OR 
				mp_pre_salesman.description LIKE ? OR 
				mp_pre_salesman.agentname LIKE ? OR 
				mp_pre_salesman.cus_id LIKE ? OR 
				mp_pre_salesman.cus_picture LIKE ? OR 
				mp_pre_salesman.delivered_to LIKE ? OR 
				mp_pre_salesman.delivered_by LIKE ? OR 
				mp_pre_salesman.delivered_date LIKE ? OR 
				mp_pre_salesman.delivered_description LIKE ? OR 
				mp_pre_salesman.shippingcharges LIKE ? OR 
				mp_pre_salesman.prescription_id LIKE ? OR 
				mp_pre_salesman.region_id LIKE ? OR 
				mp_pre_salesman.vehicle_id LIKE ? OR 
				mp_pre_salesman.driver_id LIKE ? OR 
				mp_pre_salesman.payment_method LIKE ? OR 
				mp_pre_salesman.total_gross_amt LIKE ? OR 
				mp_pre_salesman.total_bill LIKE ? OR 
				mp_pre_salesman.total_paid LIKE ? OR 
				mp_pre_salesman.source LIKE ? OR 
				mp_pre_salesman.store_id LIKE ? OR 
				mp_pre_salesman.sales_man_id LIKE ? OR 
				mp_pre_salesman.total_tax LIKE ? OR 
				mp_pre_salesman.doctor_details LIKE ? OR 
				mp_pre_salesman.patient_details LIKE ? OR 
				mp_pre_salesman.taxes_names LIKE ? OR 
				mp_pre_salesman.cash LIKE ? OR 
				mp_pre_salesman.cheque_amount LIKE ? OR 
				mp_pre_salesman.credit_amount LIKE ? OR 
				mp_pre_salesman.schemes LIKE ? OR 
				mp_pre_salesman.bank_deposit LIKE ? OR 
				mp_pre_salesman.return_stock_val LIKE ?
			)";
			$search_params = array(
				"%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%"
			);
			//setting search conditions
			$db->where($search_condition, $search_params);
			 //template to use when ajax search
			$this->view->search_template = "mp_pre_salesman/search.php";
		}
		if(!empty($request->orderby)){
			$orderby = $request->orderby;
			$ordertype = (!empty($request->ordertype) ? $request->ordertype : ORDER_TYPE);
			$db->orderBy($orderby, $ordertype);
		}
		else{
			$db->orderBy("mp_pre_salesman.id", ORDER_TYPE);
		}
		if($fieldname){
			$db->where($fieldname , $fieldvalue); //filter by a single field name
		}
		$tc = $db->withTotalCount();
		$records = $db->get($tablename, $pagination, $fields);
		$records_count = count($records);
		$total_records = intval($tc->totalCount);
		$page_limit = $pagination[1];
		$total_pages = ceil($total_records / $page_limit);
		$data = new stdClass;
		$data->records = $records;
		$data->record_count = $records_count;
		$data->total_records = $total_records;
		$data->total_page = $total_pages;
		if($db->getLastError()){
			$this->set_page_error();
		}
		$page_title = $this->view->page_title = "Mp Pre Salesman";
		$this->view->report_filename = date('Y-m-d') . '-' . $page_title;
		$this->view->report_title = $page_title;
		$this->view->report_layout = "report_layout.php";
		$this->view->report_paper_size = "A4";
		$this->view->report_orientation = "portrait";
		$this->render_view("mp_pre_salesman/list.php", $data); //render the full page
	}
	/**
     * View record detail 
	 * @param $rec_id (select record by table primary key) 
     * @param $value value (select record by value of field name(rec_id))
     * @return BaseView
     */
	function view($rec_id = null, $value = null){
		$request = $this->request;
		$db = $this->GetModel();
		$rec_id = $this->rec_id = urldecode($rec_id);
		$tablename = $this->tablename;
		$fields = array("id", 
			"date", 
			"in_time", 
			"discount", 
			"status", 
			"description", 
			"agentname", 
			"cus_id", 
			"cus_picture", 
			"delivered_to", 
			"delivered_by", 
			"delivered_date", 
			"delivered_description", 
			"shippingcharges", 
			"prescription_id", 
			"region_id", 
			"vehicle_id", 
			"driver_id", 
			"payment_method", 
			"total_gross_amt", 
			"total_bill", 
			"total_paid", 
			"source", 
			"store_id", 
			"sales_man_id", 
			"total_tax", 
			"doctor_details", 
			"patient_details", 
			"taxes_names", 
			"cash", 
			"cheque_amount", 
			"credit_amount", 
			"schemes", 
			"bank_deposit", 
			"return_stock_val");
		if($value){
			$db->where($rec_id, urldecode($value)); //select record based on field name
		}
		else{
			$db->where("mp_pre_salesman.id", $rec_id);; //select record based on primary key
		}
		$record = $db->getOne($tablename, $fields );
		if($record){
			$page_title = $this->view->page_title = "View  Mp Pre Salesman";
		$this->view->report_filename = date('Y-m-d') . '-' . $page_title;
		$this->view->report_title = $page_title;
		$this->view->report_layout = "report_layout.php";
		$this->view->report_paper_size = "A4";
		$this->view->report_orientation = "portrait";
		}
		else{
			if($db->getLastError()){
				$this->set_page_error();
			}
			else{
				$this->set_page_error("No record found");
			}
		}
		return $this->render_view("mp_pre_salesman/view.php", $record);
	}
	/**
     * Insert new record to the database table
	 * @param $formdata array() from $_POST
     * @return BaseView
     */
	function add($formdata = null){
		if($formdata){
			$db = $this->GetModel();
			$tablename = $this->tablename;
			$request = $this->request;
			//fillable fields
			$fields = $this->fields = array("date","in_time","discount","status","description","agentname","cus_id","cus_picture","delivered_to","delivered_by","delivered_date","delivered_description","shippingcharges","prescription_id","region_id","vehicle_id","driver_id","payment_method","total_gross_amt","total_bill","total_paid","source","store_id","sales_man_id","total_tax","doctor_details","patient_details","taxes_names","cash","cheque_amount","credit_amount","schemes","bank_deposit","return_stock_val");
			$postdata = $this->format_request_data($formdata);
			$this->rules_array = array(
				'date' => 'required',
				'in_time' => 'required',
				'discount' => 'required|numeric',
				'status' => 'required',
				'description' => 'required',
				'agentname' => 'required',
				'cus_id' => 'required|numeric',
				'cus_picture' => 'required',
				'delivered_to' => 'required',
				'delivered_by' => 'required',
				'delivered_date' => 'required',
				'delivered_description' => 'required',
				'shippingcharges' => 'required|numeric',
				'prescription_id' => 'required|numeric',
				'region_id' => 'required|numeric',
				'vehicle_id' => 'required|numeric',
				'driver_id' => 'required|numeric',
				'payment_method' => 'required|numeric',
				'total_gross_amt' => 'required|numeric',
				'total_bill' => 'required|numeric',
				'total_paid' => 'required|numeric',
				'source' => 'required|numeric',
				'store_id' => 'required|numeric',
				'sales_man_id' => 'required|numeric',
				'total_tax' => 'required|numeric',
				'doctor_details' => 'required',
				'patient_details' => 'required',
				'taxes_names' => 'required',
				'cash' => 'required|numeric',
				'cheque_amount' => 'required|numeric',
				'credit_amount' => 'required|numeric',
				'schemes' => 'required',
				'bank_deposit' => 'required|numeric',
				'return_stock_val' => 'required|numeric',
			);
			$this->sanitize_array = array(
				'date' => 'sanitize_string',
				'in_time' => 'sanitize_string',
				'discount' => 'sanitize_string',
				'status' => 'sanitize_string',
				'description' => 'sanitize_string',
				'agentname' => 'sanitize_string',
				'cus_id' => 'sanitize_string',
				'cus_picture' => 'sanitize_string',
				'delivered_to' => 'sanitize_string',
				'delivered_by' => 'sanitize_string',
				'delivered_date' => 'sanitize_string',
				'delivered_description' => 'sanitize_string',
				'shippingcharges' => 'sanitize_string',
				'prescription_id' => 'sanitize_string',
				'region_id' => 'sanitize_string',
				'vehicle_id' => 'sanitize_string',
				'driver_id' => 'sanitize_string',
				'payment_method' => 'sanitize_string',
				'total_gross_amt' => 'sanitize_string',
				'total_bill' => 'sanitize_string',
				'total_paid' => 'sanitize_string',
				'source' => 'sanitize_string',
				'store_id' => 'sanitize_string',
				'sales_man_id' => 'sanitize_string',
				'total_tax' => 'sanitize_string',
				'doctor_details' => 'sanitize_string',
				'patient_details' => 'sanitize_string',
				'taxes_names' => 'sanitize_string',
				'cash' => 'sanitize_string',
				'cheque_amount' => 'sanitize_string',
				'credit_amount' => 'sanitize_string',
				'schemes' => 'sanitize_string',
				'bank_deposit' => 'sanitize_string',
				'return_stock_val' => 'sanitize_string',
			);
			$this->filter_vals = true; //set whether to remove empty fields
			$modeldata = $this->modeldata = $this->validate_form($postdata);
			if($this->validated()){
				$rec_id = $this->rec_id = $db->insert($tablename, $modeldata);
				if($rec_id){
					$this->set_flash_msg("Record added successfully", "success");
					return	$this->redirect("mp_pre_salesman");
				}
				else{
					$this->set_page_error();
				}
			}
		}
		$page_title = $this->view->page_title = "Add New Mp Pre Salesman";
		$this->render_view("mp_pre_salesman/add.php");
	}
	/**
     * Update table record with formdata
	 * @param $rec_id (select record by table primary key)
	 * @param $formdata array() from $_POST
     * @return array
     */
	function edit($rec_id = null, $formdata = null){
		$request = $this->request;
		$db = $this->GetModel();
		$this->rec_id = $rec_id;
		$tablename = $this->tablename;
		 //editable fields
		$fields = $this->fields = array("id","date","in_time","discount","status","description","agentname","cus_id","cus_picture","delivered_to","delivered_by","delivered_date","delivered_description","shippingcharges","prescription_id","region_id","vehicle_id","driver_id","payment_method","total_gross_amt","total_bill","total_paid","source","store_id","sales_man_id","total_tax","doctor_details","patient_details","taxes_names","cash","cheque_amount","credit_amount","schemes","bank_deposit","return_stock_val");
		if($formdata){
			$postdata = $this->format_request_data($formdata);
			$this->rules_array = array(
				'date' => 'required',
				'in_time' => 'required',
				'discount' => 'required|numeric',
				'status' => 'required',
				'description' => 'required',
				'agentname' => 'required',
				'cus_id' => 'required|numeric',
				'cus_picture' => 'required',
				'delivered_to' => 'required',
				'delivered_by' => 'required',
				'delivered_date' => 'required',
				'delivered_description' => 'required',
				'shippingcharges' => 'required|numeric',
				'prescription_id' => 'required|numeric',
				'region_id' => 'required|numeric',
				'vehicle_id' => 'required|numeric',
				'driver_id' => 'required|numeric',
				'payment_method' => 'required|numeric',
				'total_gross_amt' => 'required|numeric',
				'total_bill' => 'required|numeric',
				'total_paid' => 'required|numeric',
				'source' => 'required|numeric',
				'store_id' => 'required|numeric',
				'sales_man_id' => 'required|numeric',
				'total_tax' => 'required|numeric',
				'doctor_details' => 'required',
				'patient_details' => 'required',
				'taxes_names' => 'required',
				'cash' => 'required|numeric',
				'cheque_amount' => 'required|numeric',
				'credit_amount' => 'required|numeric',
				'schemes' => 'required',
				'bank_deposit' => 'required|numeric',
				'return_stock_val' => 'required|numeric',
			);
			$this->sanitize_array = array(
				'date' => 'sanitize_string',
				'in_time' => 'sanitize_string',
				'discount' => 'sanitize_string',
				'status' => 'sanitize_string',
				'description' => 'sanitize_string',
				'agentname' => 'sanitize_string',
				'cus_id' => 'sanitize_string',
				'cus_picture' => 'sanitize_string',
				'delivered_to' => 'sanitize_string',
				'delivered_by' => 'sanitize_string',
				'delivered_date' => 'sanitize_string',
				'delivered_description' => 'sanitize_string',
				'shippingcharges' => 'sanitize_string',
				'prescription_id' => 'sanitize_string',
				'region_id' => 'sanitize_string',
				'vehicle_id' => 'sanitize_string',
				'driver_id' => 'sanitize_string',
				'payment_method' => 'sanitize_string',
				'total_gross_amt' => 'sanitize_string',
				'total_bill' => 'sanitize_string',
				'total_paid' => 'sanitize_string',
				'source' => 'sanitize_string',
				'store_id' => 'sanitize_string',
				'sales_man_id' => 'sanitize_string',
				'total_tax' => 'sanitize_string',
				'doctor_details' => 'sanitize_string',
				'patient_details' => 'sanitize_string',
				'taxes_names' => 'sanitize_string',
				'cash' => 'sanitize_string',
				'cheque_amount' => 'sanitize_string',
				'credit_amount' => 'sanitize_string',
				'schemes' => 'sanitize_string',
				'bank_deposit' => 'sanitize_string',
				'return_stock_val' => 'sanitize_string',
			);
			$modeldata = $this->modeldata = $this->validate_form($postdata);
			if($this->validated()){
				$db->where("mp_pre_salesman.id", $rec_id);;
				$bool = $db->update($tablename, $modeldata);
				$numRows = $db->getRowCount(); //number of affected rows. 0 = no record field updated
				if($bool && $numRows){
					$this->set_flash_msg("Record updated successfully", "success");
					return $this->redirect("mp_pre_salesman");
				}
				else{
					if($db->getLastError()){
						$this->set_page_error();
					}
					elseif(!$numRows){
						//not an error, but no record was updated
						$page_error = "No record updated";
						$this->set_page_error($page_error);
						$this->set_flash_msg($page_error, "warning");
						return	$this->redirect("mp_pre_salesman");
					}
				}
			}
		}
		$db->where("mp_pre_salesman.id", $rec_id);;
		$data = $db->getOne($tablename, $fields);
		$page_title = $this->view->page_title = "Edit  Mp Pre Salesman";
		if(!$data){
			$this->set_page_error();
		}
		return $this->render_view("mp_pre_salesman/edit.php", $data);
	}
	/**
     * Update single field
	 * @param $rec_id (select record by table primary key)
	 * @param $formdata array() from $_POST
     * @return array
     */
	function editfield($rec_id = null, $formdata = null){
		$db = $this->GetModel();
		$this->rec_id = $rec_id;
		$tablename = $this->tablename;
		//editable fields
		$fields = $this->fields = array("id","date","in_time","discount","status","description","agentname","cus_id","cus_picture","delivered_to","delivered_by","delivered_date","delivered_description","shippingcharges","prescription_id","region_id","vehicle_id","driver_id","payment_method","total_gross_amt","total_bill","total_paid","source","store_id","sales_man_id","total_tax","doctor_details","patient_details","taxes_names","cash","cheque_amount","credit_amount","schemes","bank_deposit","return_stock_val");
		$page_error = null;
		if($formdata){
			$postdata = array();
			$fieldname = $formdata['name'];
			$fieldvalue = $formdata['value'];
			$postdata[$fieldname] = $fieldvalue;
			$postdata = $this->format_request_data($postdata);
			$this->rules_array = array(
				'date' => 'required',
				'in_time' => 'required',
				'discount' => 'required|numeric',
				'status' => 'required',
				'description' => 'required',
				'agentname' => 'required',
				'cus_id' => 'required|numeric',
				'cus_picture' => 'required',
				'delivered_to' => 'required',
				'delivered_by' => 'required',
				'delivered_date' => 'required',
				'delivered_description' => 'required',
				'shippingcharges' => 'required|numeric',
				'prescription_id' => 'required|numeric',
				'region_id' => 'required|numeric',
				'vehicle_id' => 'required|numeric',
				'driver_id' => 'required|numeric',
				'payment_method' => 'required|numeric',
				'total_gross_amt' => 'required|numeric',
				'total_bill' => 'required|numeric',
				'total_paid' => 'required|numeric',
				'source' => 'required|numeric',
				'store_id' => 'required|numeric',
				'sales_man_id' => 'required|numeric',
				'total_tax' => 'required|numeric',
				'doctor_details' => 'required',
				'patient_details' => 'required',
				'taxes_names' => 'required',
				'cash' => 'required|numeric',
				'cheque_amount' => 'required|numeric',
				'credit_amount' => 'required|numeric',
				'schemes' => 'required',
				'bank_deposit' => 'required|numeric',
				'return_stock_val' => 'required|numeric',
			);
			$this->sanitize_array = array(
				'date' => 'sanitize_string',
				'in_time' => 'sanitize_string',
				'discount' => 'sanitize_string',
				'status' => 'sanitize_string',
				'description' => 'sanitize_string',
				'agentname' => 'sanitize_string',
				'cus_id' => 'sanitize_string',
				'cus_picture' => 'sanitize_string',
				'delivered_to' => 'sanitize_string',
				'delivered_by' => 'sanitize_string',
				'delivered_date' => 'sanitize_string',
				'delivered_description' => 'sanitize_string',
				'shippingcharges' => 'sanitize_string',
				'prescription_id' => 'sanitize_string',
				'region_id' => 'sanitize_string',
				'vehicle_id' => 'sanitize_string',
				'driver_id' => 'sanitize_string',
				'payment_method' => 'sanitize_string',
				'total_gross_amt' => 'sanitize_string',
				'total_bill' => 'sanitize_string',
				'total_paid' => 'sanitize_string',
				'source' => 'sanitize_string',
				'store_id' => 'sanitize_string',
				'sales_man_id' => 'sanitize_string',
				'total_tax' => 'sanitize_string',
				'doctor_details' => 'sanitize_string',
				'patient_details' => 'sanitize_string',
				'taxes_names' => 'sanitize_string',
				'cash' => 'sanitize_string',
				'cheque_amount' => 'sanitize_string',
				'credit_amount' => 'sanitize_string',
				'schemes' => 'sanitize_string',
				'bank_deposit' => 'sanitize_string',
				'return_stock_val' => 'sanitize_string',
			);
			$this->filter_rules = true; //filter validation rules by excluding fields not in the formdata
			$modeldata = $this->modeldata = $this->validate_form($postdata);
			if($this->validated()){
				$db->where("mp_pre_salesman.id", $rec_id);;
				$bool = $db->update($tablename, $modeldata);
				$numRows = $db->getRowCount();
				if($bool && $numRows){
					return render_json(
						array(
							'num_rows' =>$numRows,
							'rec_id' =>$rec_id,
						)
					);
				}
				else{
					if($db->getLastError()){
						$page_error = $db->getLastError();
					}
					elseif(!$numRows){
						$page_error = "No record updated";
					}
					render_error($page_error);
				}
			}
			else{
				render_error($this->view->page_error);
			}
		}
		return null;
	}
	/**
     * Delete record from the database
	 * Support multi delete by separating record id by comma.
     * @return BaseView
     */
	function delete($rec_id = null){
		Csrf::cross_check();
		$request = $this->request;
		$db = $this->GetModel();
		$tablename = $this->tablename;
		$this->rec_id = $rec_id;
		//form multiple delete, split record id separated by comma into array
		$arr_rec_id = array_map('trim', explode(",", $rec_id));
		$db->where("mp_pre_salesman.id", $arr_rec_id, "in");
		$bool = $db->delete($tablename);
		if($bool){
			$this->set_flash_msg("Record deleted successfully", "success");
		}
		elseif($db->getLastError()){
			$page_error = $db->getLastError();
			$this->set_flash_msg($page_error, "danger");
		}
		return	$this->redirect("mp_pre_salesman");
	}
}
