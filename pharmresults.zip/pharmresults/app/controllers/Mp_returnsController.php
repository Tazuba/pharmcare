<?php 
/**
 * Mp_returns Page Controller
 * @category  Controller
 */
class Mp_returnsController extends BaseController{
	function __construct(){
		parent::__construct();
		$this->tablename = "mp_returns";
	}
	/**
     * List page records
     * @param $fieldname (filter record by a field) 
     * @param $fieldvalue (filter field value)
     * @return BaseView
     */
	function index($fieldname = null , $fieldvalue = null){
		$request = $this->request;
		$db = $this->GetModel();
		$tablename = $this->tablename;
		$fields = array("id", 
			"invoice_no", 
			"transaction_id", 
			"date", 
			"in_time", 
			"discount", 
			"status", 
			"description", 
			"agentname", 
			"cus_id", 
			"cus_picture", 
			"delivered_to", 
			"delivered_by", 
			"delivered_date", 
			"delivered_description", 
			"shippingcharges", 
			"prescription_id", 
			"region_id", 
			"vehicle_id", 
			"driver_id", 
			"payment_method", 
			"total_gross_amt", 
			"total_bill", 
			"total_paid", 
			"source", 
			"store_id", 
			"sales_man_id", 
			"total_tax", 
			"doctor_details", 
			"patient_details", 
			"taxes_names");
		$pagination = $this->get_pagination(MAX_RECORD_COUNT); // get current pagination e.g array(page_number, page_limit)
		//search table record
		if(!empty($request->search)){
			$text = trim($request->search); 
			$search_condition = "(
				mp_returns.id LIKE ? OR 
				mp_returns.invoice_no LIKE ? OR 
				mp_returns.transaction_id LIKE ? OR 
				mp_returns.date LIKE ? OR 
				mp_returns.in_time LIKE ? OR 
				mp_returns.discount LIKE ? OR 
				mp_returns.status LIKE ? OR 
				mp_returns.description LIKE ? OR 
				mp_returns.agentname LIKE ? OR 
				mp_returns.cus_id LIKE ? OR 
				mp_returns.cus_picture LIKE ? OR 
				mp_returns.delivered_to LIKE ? OR 
				mp_returns.delivered_by LIKE ? OR 
				mp_returns.delivered_date LIKE ? OR 
				mp_returns.delivered_description LIKE ? OR 
				mp_returns.shippingcharges LIKE ? OR 
				mp_returns.prescription_id LIKE ? OR 
				mp_returns.region_id LIKE ? OR 
				mp_returns.vehicle_id LIKE ? OR 
				mp_returns.driver_id LIKE ? OR 
				mp_returns.payment_method LIKE ? OR 
				mp_returns.total_gross_amt LIKE ? OR 
				mp_returns.total_bill LIKE ? OR 
				mp_returns.total_paid LIKE ? OR 
				mp_returns.source LIKE ? OR 
				mp_returns.store_id LIKE ? OR 
				mp_returns.sales_man_id LIKE ? OR 
				mp_returns.total_tax LIKE ? OR 
				mp_returns.doctor_details LIKE ? OR 
				mp_returns.patient_details LIKE ? OR 
				mp_returns.taxes_names LIKE ?
			)";
			$search_params = array(
				"%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%"
			);
			//setting search conditions
			$db->where($search_condition, $search_params);
			 //template to use when ajax search
			$this->view->search_template = "mp_returns/search.php";
		}
		if(!empty($request->orderby)){
			$orderby = $request->orderby;
			$ordertype = (!empty($request->ordertype) ? $request->ordertype : ORDER_TYPE);
			$db->orderBy($orderby, $ordertype);
		}
		else{
			$db->orderBy("mp_returns.id", ORDER_TYPE);
		}
		if($fieldname){
			$db->where($fieldname , $fieldvalue); //filter by a single field name
		}
		$tc = $db->withTotalCount();
		$records = $db->get($tablename, $pagination, $fields);
		$records_count = count($records);
		$total_records = intval($tc->totalCount);
		$page_limit = $pagination[1];
		$total_pages = ceil($total_records / $page_limit);
		$data = new stdClass;
		$data->records = $records;
		$data->record_count = $records_count;
		$data->total_records = $total_records;
		$data->total_page = $total_pages;
		if($db->getLastError()){
			$this->set_page_error();
		}
		$page_title = $this->view->page_title = "Mp Returns";
		$this->view->report_filename = date('Y-m-d') . '-' . $page_title;
		$this->view->report_title = $page_title;
		$this->view->report_layout = "report_layout.php";
		$this->view->report_paper_size = "A4";
		$this->view->report_orientation = "portrait";
		$this->render_view("mp_returns/list.php", $data); //render the full page
	}
	/**
     * View record detail 
	 * @param $rec_id (select record by table primary key) 
     * @param $value value (select record by value of field name(rec_id))
     * @return BaseView
     */
	function view($rec_id = null, $value = null){
		$request = $this->request;
		$db = $this->GetModel();
		$rec_id = $this->rec_id = urldecode($rec_id);
		$tablename = $this->tablename;
		$fields = array("id", 
			"invoice_no", 
			"transaction_id", 
			"date", 
			"in_time", 
			"discount", 
			"status", 
			"description", 
			"agentname", 
			"cus_id", 
			"cus_picture", 
			"delivered_to", 
			"delivered_by", 
			"delivered_date", 
			"delivered_description", 
			"shippingcharges", 
			"prescription_id", 
			"region_id", 
			"vehicle_id", 
			"driver_id", 
			"payment_method", 
			"total_gross_amt", 
			"total_bill", 
			"total_paid", 
			"source", 
			"store_id", 
			"sales_man_id", 
			"total_tax", 
			"doctor_details", 
			"patient_details", 
			"taxes_names");
		if($value){
			$db->where($rec_id, urldecode($value)); //select record based on field name
		}
		else{
			$db->where("mp_returns.id", $rec_id);; //select record based on primary key
		}
		$record = $db->getOne($tablename, $fields );
		if($record){
			$page_title = $this->view->page_title = "View  Mp Returns";
		$this->view->report_filename = date('Y-m-d') . '-' . $page_title;
		$this->view->report_title = $page_title;
		$this->view->report_layout = "report_layout.php";
		$this->view->report_paper_size = "A4";
		$this->view->report_orientation = "portrait";
		}
		else{
			if($db->getLastError()){
				$this->set_page_error();
			}
			else{
				$this->set_page_error("No record found");
			}
		}
		return $this->render_view("mp_returns/view.php", $record);
	}
	/**
     * Insert new record to the database table
	 * @param $formdata array() from $_POST
     * @return BaseView
     */
	function add($formdata = null){
		if($formdata){
			$db = $this->GetModel();
			$tablename = $this->tablename;
			$request = $this->request;
			//fillable fields
			$fields = $this->fields = array("invoice_no","transaction_id","date","in_time","discount","status","description","agentname","cus_id","cus_picture","delivered_to","delivered_by","delivered_date","delivered_description","shippingcharges","prescription_id","region_id","vehicle_id","driver_id","payment_method","total_gross_amt","total_bill","total_paid","source","store_id","sales_man_id","total_tax","doctor_details","patient_details","taxes_names");
			$postdata = $this->format_request_data($formdata);
			$this->rules_array = array(
				'invoice_no' => 'required',
				'transaction_id' => 'required|numeric',
				'date' => 'required',
				'in_time' => 'required',
				'discount' => 'required|numeric',
				'status' => 'required',
				'description' => 'required',
				'agentname' => 'required',
				'cus_id' => 'required|numeric',
				'cus_picture' => 'required',
				'delivered_to' => 'required',
				'delivered_by' => 'required',
				'delivered_date' => 'required',
				'delivered_description' => 'required',
				'shippingcharges' => 'required|numeric',
				'prescription_id' => 'required|numeric',
				'region_id' => 'required|numeric',
				'vehicle_id' => 'required|numeric',
				'driver_id' => 'required|numeric',
				'payment_method' => 'required|numeric',
				'total_gross_amt' => 'required|numeric',
				'total_bill' => 'required|numeric',
				'total_paid' => 'required|numeric',
				'source' => 'required|numeric',
				'store_id' => 'required|numeric',
				'sales_man_id' => 'required|numeric',
				'total_tax' => 'required|numeric',
				'doctor_details' => 'required',
				'patient_details' => 'required',
				'taxes_names' => 'required',
			);
			$this->sanitize_array = array(
				'invoice_no' => 'sanitize_string',
				'transaction_id' => 'sanitize_string',
				'date' => 'sanitize_string',
				'in_time' => 'sanitize_string',
				'discount' => 'sanitize_string',
				'status' => 'sanitize_string',
				'description' => 'sanitize_string',
				'agentname' => 'sanitize_string',
				'cus_id' => 'sanitize_string',
				'cus_picture' => 'sanitize_string',
				'delivered_to' => 'sanitize_string',
				'delivered_by' => 'sanitize_string',
				'delivered_date' => 'sanitize_string',
				'delivered_description' => 'sanitize_string',
				'shippingcharges' => 'sanitize_string',
				'prescription_id' => 'sanitize_string',
				'region_id' => 'sanitize_string',
				'vehicle_id' => 'sanitize_string',
				'driver_id' => 'sanitize_string',
				'payment_method' => 'sanitize_string',
				'total_gross_amt' => 'sanitize_string',
				'total_bill' => 'sanitize_string',
				'total_paid' => 'sanitize_string',
				'source' => 'sanitize_string',
				'store_id' => 'sanitize_string',
				'sales_man_id' => 'sanitize_string',
				'total_tax' => 'sanitize_string',
				'doctor_details' => 'sanitize_string',
				'patient_details' => 'sanitize_string',
				'taxes_names' => 'sanitize_string',
			);
			$this->filter_vals = true; //set whether to remove empty fields
			$modeldata = $this->modeldata = $this->validate_form($postdata);
			if($this->validated()){
				$rec_id = $this->rec_id = $db->insert($tablename, $modeldata);
				if($rec_id){
					$this->set_flash_msg("Record added successfully", "success");
					return	$this->redirect("mp_returns");
				}
				else{
					$this->set_page_error();
				}
			}
		}
		$page_title = $this->view->page_title = "Add New Mp Returns";
		$this->render_view("mp_returns/add.php");
	}
	/**
     * Update table record with formdata
	 * @param $rec_id (select record by table primary key)
	 * @param $formdata array() from $_POST
     * @return array
     */
	function edit($rec_id = null, $formdata = null){
		$request = $this->request;
		$db = $this->GetModel();
		$this->rec_id = $rec_id;
		$tablename = $this->tablename;
		 //editable fields
		$fields = $this->fields = array("id","invoice_no","transaction_id","date","in_time","discount","status","description","agentname","cus_id","cus_picture","delivered_to","delivered_by","delivered_date","delivered_description","shippingcharges","prescription_id","region_id","vehicle_id","driver_id","payment_method","total_gross_amt","total_bill","total_paid","source","store_id","sales_man_id","total_tax","doctor_details","patient_details","taxes_names");
		if($formdata){
			$postdata = $this->format_request_data($formdata);
			$this->rules_array = array(
				'invoice_no' => 'required',
				'transaction_id' => 'required|numeric',
				'date' => 'required',
				'in_time' => 'required',
				'discount' => 'required|numeric',
				'status' => 'required',
				'description' => 'required',
				'agentname' => 'required',
				'cus_id' => 'required|numeric',
				'cus_picture' => 'required',
				'delivered_to' => 'required',
				'delivered_by' => 'required',
				'delivered_date' => 'required',
				'delivered_description' => 'required',
				'shippingcharges' => 'required|numeric',
				'prescription_id' => 'required|numeric',
				'region_id' => 'required|numeric',
				'vehicle_id' => 'required|numeric',
				'driver_id' => 'required|numeric',
				'payment_method' => 'required|numeric',
				'total_gross_amt' => 'required|numeric',
				'total_bill' => 'required|numeric',
				'total_paid' => 'required|numeric',
				'source' => 'required|numeric',
				'store_id' => 'required|numeric',
				'sales_man_id' => 'required|numeric',
				'total_tax' => 'required|numeric',
				'doctor_details' => 'required',
				'patient_details' => 'required',
				'taxes_names' => 'required',
			);
			$this->sanitize_array = array(
				'invoice_no' => 'sanitize_string',
				'transaction_id' => 'sanitize_string',
				'date' => 'sanitize_string',
				'in_time' => 'sanitize_string',
				'discount' => 'sanitize_string',
				'status' => 'sanitize_string',
				'description' => 'sanitize_string',
				'agentname' => 'sanitize_string',
				'cus_id' => 'sanitize_string',
				'cus_picture' => 'sanitize_string',
				'delivered_to' => 'sanitize_string',
				'delivered_by' => 'sanitize_string',
				'delivered_date' => 'sanitize_string',
				'delivered_description' => 'sanitize_string',
				'shippingcharges' => 'sanitize_string',
				'prescription_id' => 'sanitize_string',
				'region_id' => 'sanitize_string',
				'vehicle_id' => 'sanitize_string',
				'driver_id' => 'sanitize_string',
				'payment_method' => 'sanitize_string',
				'total_gross_amt' => 'sanitize_string',
				'total_bill' => 'sanitize_string',
				'total_paid' => 'sanitize_string',
				'source' => 'sanitize_string',
				'store_id' => 'sanitize_string',
				'sales_man_id' => 'sanitize_string',
				'total_tax' => 'sanitize_string',
				'doctor_details' => 'sanitize_string',
				'patient_details' => 'sanitize_string',
				'taxes_names' => 'sanitize_string',
			);
			$modeldata = $this->modeldata = $this->validate_form($postdata);
			if($this->validated()){
				$db->where("mp_returns.id", $rec_id);;
				$bool = $db->update($tablename, $modeldata);
				$numRows = $db->getRowCount(); //number of affected rows. 0 = no record field updated
				if($bool && $numRows){
					$this->set_flash_msg("Record updated successfully", "success");
					return $this->redirect("mp_returns");
				}
				else{
					if($db->getLastError()){
						$this->set_page_error();
					}
					elseif(!$numRows){
						//not an error, but no record was updated
						$page_error = "No record updated";
						$this->set_page_error($page_error);
						$this->set_flash_msg($page_error, "warning");
						return	$this->redirect("mp_returns");
					}
				}
			}
		}
		$db->where("mp_returns.id", $rec_id);;
		$data = $db->getOne($tablename, $fields);
		$page_title = $this->view->page_title = "Edit  Mp Returns";
		if(!$data){
			$this->set_page_error();
		}
		return $this->render_view("mp_returns/edit.php", $data);
	}
	/**
     * Update single field
	 * @param $rec_id (select record by table primary key)
	 * @param $formdata array() from $_POST
     * @return array
     */
	function editfield($rec_id = null, $formdata = null){
		$db = $this->GetModel();
		$this->rec_id = $rec_id;
		$tablename = $this->tablename;
		//editable fields
		$fields = $this->fields = array("id","invoice_no","transaction_id","date","in_time","discount","status","description","agentname","cus_id","cus_picture","delivered_to","delivered_by","delivered_date","delivered_description","shippingcharges","prescription_id","region_id","vehicle_id","driver_id","payment_method","total_gross_amt","total_bill","total_paid","source","store_id","sales_man_id","total_tax","doctor_details","patient_details","taxes_names");
		$page_error = null;
		if($formdata){
			$postdata = array();
			$fieldname = $formdata['name'];
			$fieldvalue = $formdata['value'];
			$postdata[$fieldname] = $fieldvalue;
			$postdata = $this->format_request_data($postdata);
			$this->rules_array = array(
				'invoice_no' => 'required',
				'transaction_id' => 'required|numeric',
				'date' => 'required',
				'in_time' => 'required',
				'discount' => 'required|numeric',
				'status' => 'required',
				'description' => 'required',
				'agentname' => 'required',
				'cus_id' => 'required|numeric',
				'cus_picture' => 'required',
				'delivered_to' => 'required',
				'delivered_by' => 'required',
				'delivered_date' => 'required',
				'delivered_description' => 'required',
				'shippingcharges' => 'required|numeric',
				'prescription_id' => 'required|numeric',
				'region_id' => 'required|numeric',
				'vehicle_id' => 'required|numeric',
				'driver_id' => 'required|numeric',
				'payment_method' => 'required|numeric',
				'total_gross_amt' => 'required|numeric',
				'total_bill' => 'required|numeric',
				'total_paid' => 'required|numeric',
				'source' => 'required|numeric',
				'store_id' => 'required|numeric',
				'sales_man_id' => 'required|numeric',
				'total_tax' => 'required|numeric',
				'doctor_details' => 'required',
				'patient_details' => 'required',
				'taxes_names' => 'required',
			);
			$this->sanitize_array = array(
				'invoice_no' => 'sanitize_string',
				'transaction_id' => 'sanitize_string',
				'date' => 'sanitize_string',
				'in_time' => 'sanitize_string',
				'discount' => 'sanitize_string',
				'status' => 'sanitize_string',
				'description' => 'sanitize_string',
				'agentname' => 'sanitize_string',
				'cus_id' => 'sanitize_string',
				'cus_picture' => 'sanitize_string',
				'delivered_to' => 'sanitize_string',
				'delivered_by' => 'sanitize_string',
				'delivered_date' => 'sanitize_string',
				'delivered_description' => 'sanitize_string',
				'shippingcharges' => 'sanitize_string',
				'prescription_id' => 'sanitize_string',
				'region_id' => 'sanitize_string',
				'vehicle_id' => 'sanitize_string',
				'driver_id' => 'sanitize_string',
				'payment_method' => 'sanitize_string',
				'total_gross_amt' => 'sanitize_string',
				'total_bill' => 'sanitize_string',
				'total_paid' => 'sanitize_string',
				'source' => 'sanitize_string',
				'store_id' => 'sanitize_string',
				'sales_man_id' => 'sanitize_string',
				'total_tax' => 'sanitize_string',
				'doctor_details' => 'sanitize_string',
				'patient_details' => 'sanitize_string',
				'taxes_names' => 'sanitize_string',
			);
			$this->filter_rules = true; //filter validation rules by excluding fields not in the formdata
			$modeldata = $this->modeldata = $this->validate_form($postdata);
			if($this->validated()){
				$db->where("mp_returns.id", $rec_id);;
				$bool = $db->update($tablename, $modeldata);
				$numRows = $db->getRowCount();
				if($bool && $numRows){
					return render_json(
						array(
							'num_rows' =>$numRows,
							'rec_id' =>$rec_id,
						)
					);
				}
				else{
					if($db->getLastError()){
						$page_error = $db->getLastError();
					}
					elseif(!$numRows){
						$page_error = "No record updated";
					}
					render_error($page_error);
				}
			}
			else{
				render_error($this->view->page_error);
			}
		}
		return null;
	}
	/**
     * Delete record from the database
	 * Support multi delete by separating record id by comma.
     * @return BaseView
     */
	function delete($rec_id = null){
		Csrf::cross_check();
		$request = $this->request;
		$db = $this->GetModel();
		$tablename = $this->tablename;
		$this->rec_id = $rec_id;
		//form multiple delete, split record id separated by comma into array
		$arr_rec_id = array_map('trim', explode(",", $rec_id));
		$db->where("mp_returns.id", $arr_rec_id, "in");
		$bool = $db->delete($tablename);
		if($bool){
			$this->set_flash_msg("Record deleted successfully", "success");
		}
		elseif($db->getLastError()){
			$page_error = $db->getLastError();
			$this->set_flash_msg($page_error, "danger");
		}
		return	$this->redirect("mp_returns");
	}
}
