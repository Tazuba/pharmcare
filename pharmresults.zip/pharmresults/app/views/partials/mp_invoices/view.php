<?php
$comp_model = new SharedController;
$page_element_id = "view-page-" . random_str();
$current_page = $this->set_current_page_link();
$csrf_token = Csrf::$token;
//Page Data Information from Controller
$data = $this->view_data;
//$rec_id = $data['__tableprimarykey'];
$page_id = $this->route->page_id; //Page id from url
$view_title = $this->view_title;
$show_header = $this->show_header;
$show_edit_btn = $this->show_edit_btn;
$show_delete_btn = $this->show_delete_btn;
$show_export_btn = $this->show_export_btn;
?>
<section class="page" id="<?php echo $page_element_id; ?>" data-page-type="view"  data-display-type="table" data-page-url="<?php print_link($current_page); ?>">
    <?php
    if( $show_header == true ){
    ?>
    <div  class="bg-light p-3 mb-3">
        <div class="container">
            <div class="row ">
                <div class="col ">
                    <h4 class="record-title">View  Mp Invoices</h4>
                </div>
            </div>
        </div>
    </div>
    <?php
    }
    ?>
    <div  class="">
        <div class="container">
            <div class="row ">
                <div class="col-md-12 comp-grid">
                    <?php $this :: display_page_errors(); ?>
                    <div  class="card animated fadeIn page-content">
                        <?php
                        $counter = 0;
                        if(!empty($data)){
                        $rec_id = (!empty($data['id']) ? urlencode($data['id']) : null);
                        $counter++;
                        ?>
                        <div id="page-report-body" class="">
                            <table class="table table-hover table-borderless table-striped">
                                <!-- Table Body Start -->
                                <tbody class="page-data" id="page-data-<?php echo $page_element_id; ?>">
                                    <tr  class="td-id">
                                        <th class="title"> Id: </th>
                                        <td class="value"> <?php echo $data['id']; ?></td>
                                    </tr>
                                    <tr  class="td-transaction_id">
                                        <th class="title"> Transaction Id: </th>
                                        <td class="value">
                                            <span  data-value="<?php echo $data['transaction_id']; ?>" 
                                                data-pk="<?php echo $data['id'] ?>" 
                                                data-url="<?php print_link("mp_invoices/editfield/" . urlencode($data['id'])); ?>" 
                                                data-name="transaction_id" 
                                                data-title="Enter Transaction Id" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="number" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['transaction_id']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-date">
                                        <th class="title"> Date: </th>
                                        <td class="value">
                                            <span  data-flatpickr="{ enableTime: false, minDate: '', maxDate: ''}" 
                                                data-value="<?php echo $data['date']; ?>" 
                                                data-pk="<?php echo $data['id'] ?>" 
                                                data-url="<?php print_link("mp_invoices/editfield/" . urlencode($data['id'])); ?>" 
                                                data-name="date" 
                                                data-title="Enter Date" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="flatdatetimepicker" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['date']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-in_time">
                                        <th class="title"> In Time: </th>
                                        <td class="value">
                                            <span  data-value="<?php echo $data['in_time']; ?>" 
                                                data-pk="<?php echo $data['id'] ?>" 
                                                data-url="<?php print_link("mp_invoices/editfield/" . urlencode($data['id'])); ?>" 
                                                data-name="in_time" 
                                                data-title="Enter In Time" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="time" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['in_time']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-discount">
                                        <th class="title"> Discount: </th>
                                        <td class="value">
                                            <span  data-step="0.1" 
                                                data-value="<?php echo $data['discount']; ?>" 
                                                data-pk="<?php echo $data['id'] ?>" 
                                                data-url="<?php print_link("mp_invoices/editfield/" . urlencode($data['id'])); ?>" 
                                                data-name="discount" 
                                                data-title="Enter Discount" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="number" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['discount']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-status">
                                        <th class="title"> Status: </th>
                                        <td class="value">
                                            <span  data-value="<?php echo $data['status']; ?>" 
                                                data-pk="<?php echo $data['id'] ?>" 
                                                data-url="<?php print_link("mp_invoices/editfield/" . urlencode($data['id'])); ?>" 
                                                data-name="status" 
                                                data-title="Enter Status" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="text" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['status']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-description">
                                        <th class="title"> Description: </th>
                                        <td class="value">
                                            <span  data-value="<?php echo $data['description']; ?>" 
                                                data-pk="<?php echo $data['id'] ?>" 
                                                data-url="<?php print_link("mp_invoices/editfield/" . urlencode($data['id'])); ?>" 
                                                data-name="description" 
                                                data-title="Enter Description" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="text" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['description']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-agentname">
                                        <th class="title"> Agentname: </th>
                                        <td class="value">
                                            <span  data-value="<?php echo $data['agentname']; ?>" 
                                                data-pk="<?php echo $data['id'] ?>" 
                                                data-url="<?php print_link("mp_invoices/editfield/" . urlencode($data['id'])); ?>" 
                                                data-name="agentname" 
                                                data-title="Enter Agentname" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="text" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['agentname']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-cus_id">
                                        <th class="title"> Cus Id: </th>
                                        <td class="value">
                                            <span  data-value="<?php echo $data['cus_id']; ?>" 
                                                data-pk="<?php echo $data['id'] ?>" 
                                                data-url="<?php print_link("mp_invoices/editfield/" . urlencode($data['id'])); ?>" 
                                                data-name="cus_id" 
                                                data-title="Enter Cus Id" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="number" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['cus_id']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-cus_picture">
                                        <th class="title"> Cus Picture: </th>
                                        <td class="value">
                                            <span  data-value="<?php echo $data['cus_picture']; ?>" 
                                                data-pk="<?php echo $data['id'] ?>" 
                                                data-url="<?php print_link("mp_invoices/editfield/" . urlencode($data['id'])); ?>" 
                                                data-name="cus_picture" 
                                                data-title="Enter Cus Picture" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="text" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['cus_picture']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-delivered_to">
                                        <th class="title"> Delivered To: </th>
                                        <td class="value">
                                            <span  data-value="<?php echo $data['delivered_to']; ?>" 
                                                data-pk="<?php echo $data['id'] ?>" 
                                                data-url="<?php print_link("mp_invoices/editfield/" . urlencode($data['id'])); ?>" 
                                                data-name="delivered_to" 
                                                data-title="Enter Delivered To" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="text" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['delivered_to']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-delivered_by">
                                        <th class="title"> Delivered By: </th>
                                        <td class="value">
                                            <span  data-value="<?php echo $data['delivered_by']; ?>" 
                                                data-pk="<?php echo $data['id'] ?>" 
                                                data-url="<?php print_link("mp_invoices/editfield/" . urlencode($data['id'])); ?>" 
                                                data-name="delivered_by" 
                                                data-title="Enter Delivered By" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="text" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['delivered_by']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-delivered_date">
                                        <th class="title"> Delivered Date: </th>
                                        <td class="value">
                                            <span  data-flatpickr="{ enableTime: false, minDate: '', maxDate: ''}" 
                                                data-value="<?php echo $data['delivered_date']; ?>" 
                                                data-pk="<?php echo $data['id'] ?>" 
                                                data-url="<?php print_link("mp_invoices/editfield/" . urlencode($data['id'])); ?>" 
                                                data-name="delivered_date" 
                                                data-title="Enter Delivered Date" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="flatdatetimepicker" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['delivered_date']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-delivered_description">
                                        <th class="title"> Delivered Description: </th>
                                        <td class="value">
                                            <span  data-value="<?php echo $data['delivered_description']; ?>" 
                                                data-pk="<?php echo $data['id'] ?>" 
                                                data-url="<?php print_link("mp_invoices/editfield/" . urlencode($data['id'])); ?>" 
                                                data-name="delivered_description" 
                                                data-title="Enter Delivered Description" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="text" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['delivered_description']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-shippingcharges">
                                        <th class="title"> Shippingcharges: </th>
                                        <td class="value">
                                            <span  data-step="0.1" 
                                                data-value="<?php echo $data['shippingcharges']; ?>" 
                                                data-pk="<?php echo $data['id'] ?>" 
                                                data-url="<?php print_link("mp_invoices/editfield/" . urlencode($data['id'])); ?>" 
                                                data-name="shippingcharges" 
                                                data-title="Enter Shippingcharges" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="number" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['shippingcharges']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-prescription_id">
                                        <th class="title"> Prescription Id: </th>
                                        <td class="value">
                                            <span  data-value="<?php echo $data['prescription_id']; ?>" 
                                                data-pk="<?php echo $data['id'] ?>" 
                                                data-url="<?php print_link("mp_invoices/editfield/" . urlencode($data['id'])); ?>" 
                                                data-name="prescription_id" 
                                                data-title="Enter Prescription Id" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="number" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['prescription_id']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-region_id">
                                        <th class="title"> Region Id: </th>
                                        <td class="value">
                                            <span  data-value="<?php echo $data['region_id']; ?>" 
                                                data-pk="<?php echo $data['id'] ?>" 
                                                data-url="<?php print_link("mp_invoices/editfield/" . urlencode($data['id'])); ?>" 
                                                data-name="region_id" 
                                                data-title="Enter Region Id" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="number" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['region_id']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-vehicle_id">
                                        <th class="title"> Vehicle Id: </th>
                                        <td class="value">
                                            <span  data-value="<?php echo $data['vehicle_id']; ?>" 
                                                data-pk="<?php echo $data['id'] ?>" 
                                                data-url="<?php print_link("mp_invoices/editfield/" . urlencode($data['id'])); ?>" 
                                                data-name="vehicle_id" 
                                                data-title="Enter Vehicle Id" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="number" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['vehicle_id']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-driver_id">
                                        <th class="title"> Driver Id: </th>
                                        <td class="value">
                                            <span  data-value="<?php echo $data['driver_id']; ?>" 
                                                data-pk="<?php echo $data['id'] ?>" 
                                                data-url="<?php print_link("mp_invoices/editfield/" . urlencode($data['id'])); ?>" 
                                                data-name="driver_id" 
                                                data-title="Enter Driver Id" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="number" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['driver_id']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-payment_method">
                                        <th class="title"> Payment Method: </th>
                                        <td class="value">
                                            <span  data-value="<?php echo $data['payment_method']; ?>" 
                                                data-pk="<?php echo $data['id'] ?>" 
                                                data-url="<?php print_link("mp_invoices/editfield/" . urlencode($data['id'])); ?>" 
                                                data-name="payment_method" 
                                                data-title="Enter Payment Method" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="number" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['payment_method']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-total_gross_amt">
                                        <th class="title"> Total Gross Amt: </th>
                                        <td class="value">
                                            <span  data-step="0.1" 
                                                data-value="<?php echo $data['total_gross_amt']; ?>" 
                                                data-pk="<?php echo $data['id'] ?>" 
                                                data-url="<?php print_link("mp_invoices/editfield/" . urlencode($data['id'])); ?>" 
                                                data-name="total_gross_amt" 
                                                data-title="Enter Total Gross Amt" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="number" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['total_gross_amt']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-total_bill">
                                        <th class="title"> Total Bill: </th>
                                        <td class="value">
                                            <span  data-step="0.1" 
                                                data-value="<?php echo $data['total_bill']; ?>" 
                                                data-pk="<?php echo $data['id'] ?>" 
                                                data-url="<?php print_link("mp_invoices/editfield/" . urlencode($data['id'])); ?>" 
                                                data-name="total_bill" 
                                                data-title="Enter Total Bill" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="number" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['total_bill']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-total_paid">
                                        <th class="title"> Total Paid: </th>
                                        <td class="value">
                                            <span  data-step="0.1" 
                                                data-value="<?php echo $data['total_paid']; ?>" 
                                                data-pk="<?php echo $data['id'] ?>" 
                                                data-url="<?php print_link("mp_invoices/editfield/" . urlencode($data['id'])); ?>" 
                                                data-name="total_paid" 
                                                data-title="Enter Total Paid" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="number" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['total_paid']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-source">
                                        <th class="title"> Source: </th>
                                        <td class="value">
                                            <span  data-value="<?php echo $data['source']; ?>" 
                                                data-pk="<?php echo $data['id'] ?>" 
                                                data-url="<?php print_link("mp_invoices/editfield/" . urlencode($data['id'])); ?>" 
                                                data-name="source" 
                                                data-title="Enter Source" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="number" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['source']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-store_id">
                                        <th class="title"> Store Id: </th>
                                        <td class="value">
                                            <span  data-value="<?php echo $data['store_id']; ?>" 
                                                data-pk="<?php echo $data['id'] ?>" 
                                                data-url="<?php print_link("mp_invoices/editfield/" . urlencode($data['id'])); ?>" 
                                                data-name="store_id" 
                                                data-title="Enter Store Id" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="number" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['store_id']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-sales_man_id">
                                        <th class="title"> Sales Man Id: </th>
                                        <td class="value">
                                            <span  data-value="<?php echo $data['sales_man_id']; ?>" 
                                                data-pk="<?php echo $data['id'] ?>" 
                                                data-url="<?php print_link("mp_invoices/editfield/" . urlencode($data['id'])); ?>" 
                                                data-name="sales_man_id" 
                                                data-title="Enter Sales Man Id" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="number" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['sales_man_id']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-total_tax">
                                        <th class="title"> Total Tax: </th>
                                        <td class="value">
                                            <span  data-step="0.1" 
                                                data-value="<?php echo $data['total_tax']; ?>" 
                                                data-pk="<?php echo $data['id'] ?>" 
                                                data-url="<?php print_link("mp_invoices/editfield/" . urlencode($data['id'])); ?>" 
                                                data-name="total_tax" 
                                                data-title="Enter Total Tax" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="number" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['total_tax']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-doctor_details">
                                        <th class="title"> Doctor Details: </th>
                                        <td class="value">
                                            <span  data-pk="<?php echo $data['id'] ?>" 
                                                data-url="<?php print_link("mp_invoices/editfield/" . urlencode($data['id'])); ?>" 
                                                data-name="doctor_details" 
                                                data-title="Enter Doctor Details" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="textarea" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['doctor_details']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-patient_details">
                                        <th class="title"> Patient Details: </th>
                                        <td class="value">
                                            <span  data-pk="<?php echo $data['id'] ?>" 
                                                data-url="<?php print_link("mp_invoices/editfield/" . urlencode($data['id'])); ?>" 
                                                data-name="patient_details" 
                                                data-title="Enter Patient Details" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="textarea" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['patient_details']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-taxes_names">
                                        <th class="title"> Taxes Names: </th>
                                        <td class="value">
                                            <span  data-value="<?php echo $data['taxes_names']; ?>" 
                                                data-pk="<?php echo $data['id'] ?>" 
                                                data-url="<?php print_link("mp_invoices/editfield/" . urlencode($data['id'])); ?>" 
                                                data-name="taxes_names" 
                                                data-title="Enter Taxes Names" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="text" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['taxes_names']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                </tbody>
                                <!-- Table Body End -->
                            </table>
                        </div>
                        <div class="p-3 d-flex">
                            <div class="dropup export-btn-holder mx-1">
                                <button class="btn btn-sm btn-primary dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <i class="fa fa-save"></i> Export
                                </button>
                                <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                    <?php $export_print_link = $this->set_current_page_link(array('format' => 'print')); ?>
                                    <a class="dropdown-item export-link-btn" data-format="print" href="<?php print_link($export_print_link); ?>" target="_blank">
                                        <img src="<?php print_link('assets/images/print.png') ?>" class="mr-2" /> PRINT
                                        </a>
                                        <?php $export_pdf_link = $this->set_current_page_link(array('format' => 'pdf')); ?>
                                        <a class="dropdown-item export-link-btn" data-format="pdf" href="<?php print_link($export_pdf_link); ?>" target="_blank">
                                            <img src="<?php print_link('assets/images/pdf.png') ?>" class="mr-2" /> PDF
                                            </a>
                                            <?php $export_word_link = $this->set_current_page_link(array('format' => 'word')); ?>
                                            <a class="dropdown-item export-link-btn" data-format="word" href="<?php print_link($export_word_link); ?>" target="_blank">
                                                <img src="<?php print_link('assets/images/doc.png') ?>" class="mr-2" /> WORD
                                                </a>
                                                <?php $export_csv_link = $this->set_current_page_link(array('format' => 'csv')); ?>
                                                <a class="dropdown-item export-link-btn" data-format="csv" href="<?php print_link($export_csv_link); ?>" target="_blank">
                                                    <img src="<?php print_link('assets/images/csv.png') ?>" class="mr-2" /> CSV
                                                    </a>
                                                    <?php $export_excel_link = $this->set_current_page_link(array('format' => 'excel')); ?>
                                                    <a class="dropdown-item export-link-btn" data-format="excel" href="<?php print_link($export_excel_link); ?>" target="_blank">
                                                        <img src="<?php print_link('assets/images/xsl.png') ?>" class="mr-2" /> EXCEL
                                                        </a>
                                                    </div>
                                                </div>
                                                <a class="btn btn-sm btn-info"  href="<?php print_link("mp_invoices/edit/$rec_id"); ?>">
                                                    <i class="fa fa-edit"></i> Edit
                                                </a>
                                                <a class="btn btn-sm btn-danger record-delete-btn mx-1"  href="<?php print_link("mp_invoices/delete/$rec_id/?csrf_token=$csrf_token&redirect=$current_page"); ?>" data-prompt-msg="Are you sure you want to delete this record?" data-display-style="modal">
                                                    <i class="fa fa-times"></i> Delete
                                                </a>
                                            </div>
                                            <?php
                                            }
                                            else{
                                            ?>
                                            <!-- Empty Record Message -->
                                            <div class="text-muted p-3">
                                                <i class="fa fa-ban"></i> No Record Found
                                            </div>
                                            <?php
                                            }
                                            ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
