<?php
$comp_model = new SharedController;
$page_element_id = "view-page-" . random_str();
$current_page = $this->set_current_page_link();
$csrf_token = Csrf::$token;
//Page Data Information from Controller
$data = $this->view_data;
//$rec_id = $data['__tableprimarykey'];
$page_id = $this->route->page_id; //Page id from url
$view_title = $this->view_title;
$show_header = $this->show_header;
$show_edit_btn = $this->show_edit_btn;
$show_delete_btn = $this->show_delete_btn;
$show_export_btn = $this->show_export_btn;
?>
<section class="page" id="<?php echo $page_element_id; ?>" data-page-type="view"  data-display-type="table" data-page-url="<?php print_link($current_page); ?>">
    <?php
    if( $show_header == true ){
    ?>
    <div  class="bg-light p-3 mb-3">
        <div class="container">
            <div class="row ">
                <div class="col ">
                    <h4 class="record-title">View  Mp Sales Receipt</h4>
                </div>
            </div>
        </div>
    </div>
    <?php
    }
    ?>
    <div  class="">
        <div class="container">
            <div class="row ">
                <div class="col-md-12 comp-grid">
                    <?php $this :: display_page_errors(); ?>
                    <div  class="card animated fadeIn page-content">
                        <?php
                        $counter = 0;
                        if(!empty($data)){
                        $rec_id = (!empty($data['id']) ? urlencode($data['id']) : null);
                        $counter++;
                        ?>
                        <div id="page-report-body" class="">
                            <table class="table table-hover table-borderless table-striped">
                                <!-- Table Body Start -->
                                <tbody class="page-data" id="page-data-<?php echo $page_element_id; ?>">
                                    <tr  class="td-id">
                                        <th class="title"> Id: </th>
                                        <td class="value"> <?php echo $data['id']; ?></td>
                                    </tr>
                                    <tr  class="td-transaction_id">
                                        <th class="title"> Transaction Id: </th>
                                        <td class="value">
                                            <span  data-value="<?php echo $data['transaction_id']; ?>" 
                                                data-pk="<?php echo $data['id'] ?>" 
                                                data-url="<?php print_link("mp_sales_receipt/editfield/" . urlencode($data['id'])); ?>" 
                                                data-name="transaction_id" 
                                                data-title="Enter Transaction Id" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="number" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['transaction_id']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-date">
                                        <th class="title"> Date: </th>
                                        <td class="value">
                                            <span  data-flatpickr="{ enableTime: false, minDate: '', maxDate: ''}" 
                                                data-value="<?php echo $data['date']; ?>" 
                                                data-pk="<?php echo $data['id'] ?>" 
                                                data-url="<?php print_link("mp_sales_receipt/editfield/" . urlencode($data['id'])); ?>" 
                                                data-name="date" 
                                                data-title="Enter Date" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="flatdatetimepicker" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['date']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-time_in">
                                        <th class="title"> Time In: </th>
                                        <td class="value">
                                            <span  data-value="<?php echo $data['time_in']; ?>" 
                                                data-pk="<?php echo $data['id'] ?>" 
                                                data-url="<?php print_link("mp_sales_receipt/editfield/" . urlencode($data['id'])); ?>" 
                                                data-name="time_in" 
                                                data-title="Enter Time In" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="time" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['time_in']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-user">
                                        <th class="title"> User: </th>
                                        <td class="value">
                                            <span  data-value="<?php echo $data['user']; ?>" 
                                                data-pk="<?php echo $data['id'] ?>" 
                                                data-url="<?php print_link("mp_sales_receipt/editfield/" . urlencode($data['id'])); ?>" 
                                                data-name="user" 
                                                data-title="Enter User" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="text" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['user']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-payee_id">
                                        <th class="title"> Payee Id: </th>
                                        <td class="value">
                                            <span  data-value="<?php echo $data['payee_id']; ?>" 
                                                data-pk="<?php echo $data['id'] ?>" 
                                                data-url="<?php print_link("mp_sales_receipt/editfield/" . urlencode($data['id'])); ?>" 
                                                data-name="payee_id" 
                                                data-title="Enter Payee Id" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="number" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['payee_id']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-method">
                                        <th class="title"> Method: </th>
                                        <td class="value">
                                            <span  data-value="<?php echo $data['method']; ?>" 
                                                data-pk="<?php echo $data['id'] ?>" 
                                                data-url="<?php print_link("mp_sales_receipt/editfield/" . urlencode($data['id'])); ?>" 
                                                data-name="method" 
                                                data-title="Enter Method" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="text" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['method']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-ref_no">
                                        <th class="title"> Ref No: </th>
                                        <td class="value">
                                            <span  data-value="<?php echo $data['ref_no']; ?>" 
                                                data-pk="<?php echo $data['id'] ?>" 
                                                data-url="<?php print_link("mp_sales_receipt/editfield/" . urlencode($data['id'])); ?>" 
                                                data-name="ref_no" 
                                                data-title="Enter Ref No" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="text" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['ref_no']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-billing_address">
                                        <th class="title"> Billing Address: </th>
                                        <td class="value">
                                            <span  data-value="<?php echo $data['billing_address']; ?>" 
                                                data-pk="<?php echo $data['id'] ?>" 
                                                data-url="<?php print_link("mp_sales_receipt/editfield/" . urlencode($data['id'])); ?>" 
                                                data-name="billing_address" 
                                                data-title="Enter Billing Address" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="text" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['billing_address']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-total_bill">
                                        <th class="title"> Total Bill: </th>
                                        <td class="value">
                                            <span  data-step="0.1" 
                                                data-value="<?php echo $data['total_bill']; ?>" 
                                                data-pk="<?php echo $data['id'] ?>" 
                                                data-url="<?php print_link("mp_sales_receipt/editfield/" . urlencode($data['id'])); ?>" 
                                                data-name="total_bill" 
                                                data-title="Enter Total Bill" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="number" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['total_bill']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-total_paid">
                                        <th class="title"> Total Paid: </th>
                                        <td class="value">
                                            <span  data-step="0.1" 
                                                data-value="<?php echo $data['total_paid']; ?>" 
                                                data-pk="<?php echo $data['id'] ?>" 
                                                data-url="<?php print_link("mp_sales_receipt/editfield/" . urlencode($data['id'])); ?>" 
                                                data-name="total_paid" 
                                                data-title="Enter Total Paid" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="number" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['total_paid']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-invoicemessage">
                                        <th class="title"> Invoicemessage: </th>
                                        <td class="value">
                                            <span  data-value="<?php echo $data['invoicemessage']; ?>" 
                                                data-pk="<?php echo $data['id'] ?>" 
                                                data-url="<?php print_link("mp_sales_receipt/editfield/" . urlencode($data['id'])); ?>" 
                                                data-name="invoicemessage" 
                                                data-title="Enter Invoicemessage" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="text" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['invoicemessage']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-memo">
                                        <th class="title"> Memo: </th>
                                        <td class="value">
                                            <span  data-value="<?php echo $data['memo']; ?>" 
                                                data-pk="<?php echo $data['id'] ?>" 
                                                data-url="<?php print_link("mp_sales_receipt/editfield/" . urlencode($data['id'])); ?>" 
                                                data-name="memo" 
                                                data-title="Enter Memo" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="text" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['memo']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-attachment">
                                        <th class="title"> Attachment: </th>
                                        <td class="value">
                                            <span  data-value="<?php echo $data['attachment']; ?>" 
                                                data-pk="<?php echo $data['id'] ?>" 
                                                data-url="<?php print_link("mp_sales_receipt/editfield/" . urlencode($data['id'])); ?>" 
                                                data-name="attachment" 
                                                data-title="Browse..." 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="text" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['attachment']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-total_discount">
                                        <th class="title"> Total Discount: </th>
                                        <td class="value">
                                            <span  data-step="0.1" 
                                                data-value="<?php echo $data['total_discount']; ?>" 
                                                data-pk="<?php echo $data['id'] ?>" 
                                                data-url="<?php print_link("mp_sales_receipt/editfield/" . urlencode($data['id'])); ?>" 
                                                data-name="total_discount" 
                                                data-title="Enter Total Discount" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="number" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['total_discount']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-total_tax">
                                        <th class="title"> Total Tax: </th>
                                        <td class="value">
                                            <span  data-step="0.1" 
                                                data-value="<?php echo $data['total_tax']; ?>" 
                                                data-pk="<?php echo $data['id'] ?>" 
                                                data-url="<?php print_link("mp_sales_receipt/editfield/" . urlencode($data['id'])); ?>" 
                                                data-name="total_tax" 
                                                data-title="Enter Total Tax" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="number" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['total_tax']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-gross_total">
                                        <th class="title"> Gross Total: </th>
                                        <td class="value">
                                            <span  data-step="0.1" 
                                                data-value="<?php echo $data['gross_total']; ?>" 
                                                data-pk="<?php echo $data['id'] ?>" 
                                                data-url="<?php print_link("mp_sales_receipt/editfield/" . urlencode($data['id'])); ?>" 
                                                data-name="gross_total" 
                                                data-title="Enter Gross Total" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="number" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['gross_total']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-parent_tax_name">
                                        <th class="title"> Parent Tax Name: </th>
                                        <td class="value">
                                            <span  data-value="<?php echo $data['parent_tax_name']; ?>" 
                                                data-pk="<?php echo $data['id'] ?>" 
                                                data-url="<?php print_link("mp_sales_receipt/editfield/" . urlencode($data['id'])); ?>" 
                                                data-name="parent_tax_name" 
                                                data-title="Enter Parent Tax Name" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="text" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['parent_tax_name']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                </tbody>
                                <!-- Table Body End -->
                            </table>
                        </div>
                        <div class="p-3 d-flex">
                            <div class="dropup export-btn-holder mx-1">
                                <button class="btn btn-sm btn-primary dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <i class="fa fa-save"></i> Export
                                </button>
                                <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                    <?php $export_print_link = $this->set_current_page_link(array('format' => 'print')); ?>
                                    <a class="dropdown-item export-link-btn" data-format="print" href="<?php print_link($export_print_link); ?>" target="_blank">
                                        <img src="<?php print_link('assets/images/print.png') ?>" class="mr-2" /> PRINT
                                        </a>
                                        <?php $export_pdf_link = $this->set_current_page_link(array('format' => 'pdf')); ?>
                                        <a class="dropdown-item export-link-btn" data-format="pdf" href="<?php print_link($export_pdf_link); ?>" target="_blank">
                                            <img src="<?php print_link('assets/images/pdf.png') ?>" class="mr-2" /> PDF
                                            </a>
                                            <?php $export_word_link = $this->set_current_page_link(array('format' => 'word')); ?>
                                            <a class="dropdown-item export-link-btn" data-format="word" href="<?php print_link($export_word_link); ?>" target="_blank">
                                                <img src="<?php print_link('assets/images/doc.png') ?>" class="mr-2" /> WORD
                                                </a>
                                                <?php $export_csv_link = $this->set_current_page_link(array('format' => 'csv')); ?>
                                                <a class="dropdown-item export-link-btn" data-format="csv" href="<?php print_link($export_csv_link); ?>" target="_blank">
                                                    <img src="<?php print_link('assets/images/csv.png') ?>" class="mr-2" /> CSV
                                                    </a>
                                                    <?php $export_excel_link = $this->set_current_page_link(array('format' => 'excel')); ?>
                                                    <a class="dropdown-item export-link-btn" data-format="excel" href="<?php print_link($export_excel_link); ?>" target="_blank">
                                                        <img src="<?php print_link('assets/images/xsl.png') ?>" class="mr-2" /> EXCEL
                                                        </a>
                                                    </div>
                                                </div>
                                                <a class="btn btn-sm btn-info"  href="<?php print_link("mp_sales_receipt/edit/$rec_id"); ?>">
                                                    <i class="fa fa-edit"></i> Edit
                                                </a>
                                                <a class="btn btn-sm btn-danger record-delete-btn mx-1"  href="<?php print_link("mp_sales_receipt/delete/$rec_id/?csrf_token=$csrf_token&redirect=$current_page"); ?>" data-prompt-msg="Are you sure you want to delete this record?" data-display-style="modal">
                                                    <i class="fa fa-times"></i> Delete
                                                </a>
                                            </div>
                                            <?php
                                            }
                                            else{
                                            ?>
                                            <!-- Empty Record Message -->
                                            <div class="text-muted p-3">
                                                <i class="fa fa-ban"></i> No Record Found
                                            </div>
                                            <?php
                                            }
                                            ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
