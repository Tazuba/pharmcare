<?php
$comp_model = new SharedController;
$page_element_id = "view-page-" . random_str();
$current_page = $this->set_current_page_link();
$csrf_token = Csrf::$token;
//Page Data Information from Controller
$data = $this->view_data;
//$rec_id = $data['__tableprimarykey'];
$page_id = $this->route->page_id; //Page id from url
$view_title = $this->view_title;
$show_header = $this->show_header;
$show_edit_btn = $this->show_edit_btn;
$show_delete_btn = $this->show_delete_btn;
$show_export_btn = $this->show_export_btn;
?>
<section class="page" id="<?php echo $page_element_id; ?>" data-page-type="view"  data-display-type="table" data-page-url="<?php print_link($current_page); ?>">
    <?php
    if( $show_header == true ){
    ?>
    <div  class="bg-light p-3 mb-3">
        <div class="container">
            <div class="row ">
                <div class="col ">
                    <h4 class="record-title">View  Mp Langingpage</h4>
                </div>
            </div>
        </div>
    </div>
    <?php
    }
    ?>
    <div  class="">
        <div class="container">
            <div class="row ">
                <div class="col-md-12 comp-grid">
                    <?php $this :: display_page_errors(); ?>
                    <div  class="card animated fadeIn page-content">
                        <?php
                        $counter = 0;
                        if(!empty($data)){
                        $rec_id = (!empty($data['id']) ? urlencode($data['id']) : null);
                        $counter++;
                        ?>
                        <div id="page-report-body" class="">
                            <table class="table table-hover table-borderless table-striped">
                                <!-- Table Body Start -->
                                <tbody class="page-data" id="page-data-<?php echo $page_element_id; ?>">
                                    <tr  class="td-id">
                                        <th class="title"> Id: </th>
                                        <td class="value"> <?php echo $data['id']; ?></td>
                                    </tr>
                                    <tr  class="td-companyname">
                                        <th class="title"> Companyname: </th>
                                        <td class="value">
                                            <span  data-value="<?php echo $data['companyname']; ?>" 
                                                data-pk="<?php echo $data['id'] ?>" 
                                                data-url="<?php print_link("mp_langingpage/editfield/" . urlencode($data['id'])); ?>" 
                                                data-name="companyname" 
                                                data-title="Enter Companyname" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="text" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['companyname']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-companydescription">
                                        <th class="title"> Companydescription: </th>
                                        <td class="value">
                                            <span  data-value="<?php echo $data['companydescription']; ?>" 
                                                data-pk="<?php echo $data['id'] ?>" 
                                                data-url="<?php print_link("mp_langingpage/editfield/" . urlencode($data['id'])); ?>" 
                                                data-name="companydescription" 
                                                data-title="Enter Companydescription" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="text" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['companydescription']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-companykeywords">
                                        <th class="title"> Companykeywords: </th>
                                        <td class="value">
                                            <span  data-value="<?php echo $data['companykeywords']; ?>" 
                                                data-pk="<?php echo $data['id'] ?>" 
                                                data-url="<?php print_link("mp_langingpage/editfield/" . urlencode($data['id'])); ?>" 
                                                data-name="companykeywords" 
                                                data-title="Enter Companykeywords" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="text" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['companykeywords']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-license_no">
                                        <th class="title"> License No: </th>
                                        <td class="value">
                                            <span  data-value="<?php echo $data['license_no']; ?>" 
                                                data-pk="<?php echo $data['id'] ?>" 
                                                data-url="<?php print_link("mp_langingpage/editfield/" . urlencode($data['id'])); ?>" 
                                                data-name="license_no" 
                                                data-title="Enter License No" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="text" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['license_no']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-printer_enable">
                                        <th class="title"> Printer Enable: </th>
                                        <td class="value">
                                            <span  data-value="<?php echo $data['printer_enable']; ?>" 
                                                data-pk="<?php echo $data['id'] ?>" 
                                                data-url="<?php print_link("mp_langingpage/editfield/" . urlencode($data['id'])); ?>" 
                                                data-name="printer_enable" 
                                                data-title="Enter Printer Enable" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="text" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['printer_enable']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-address">
                                        <th class="title"> Address: </th>
                                        <td class="value">
                                            <span  data-value="<?php echo $data['address']; ?>" 
                                                data-pk="<?php echo $data['id'] ?>" 
                                                data-url="<?php print_link("mp_langingpage/editfield/" . urlencode($data['id'])); ?>" 
                                                data-name="address" 
                                                data-title="Enter Address" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="text" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['address']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-email">
                                        <th class="title"> Email: </th>
                                        <td class="value">
                                            <span  data-value="<?php echo $data['email']; ?>" 
                                                data-pk="<?php echo $data['id'] ?>" 
                                                data-url="<?php print_link("mp_langingpage/editfield/" . urlencode($data['id'])); ?>" 
                                                data-name="email" 
                                                data-title="Enter Email" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="email" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['email']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-contact">
                                        <th class="title"> Contact: </th>
                                        <td class="value">
                                            <span  data-value="<?php echo $data['contact']; ?>" 
                                                data-pk="<?php echo $data['id'] ?>" 
                                                data-url="<?php print_link("mp_langingpage/editfield/" . urlencode($data['id'])); ?>" 
                                                data-name="contact" 
                                                data-title="Enter Contact" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="text" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['contact']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-logo">
                                        <th class="title"> Logo: </th>
                                        <td class="value">
                                            <span  data-value="<?php echo $data['logo']; ?>" 
                                                data-pk="<?php echo $data['id'] ?>" 
                                                data-url="<?php print_link("mp_langingpage/editfield/" . urlencode($data['id'])); ?>" 
                                                data-name="logo" 
                                                data-title="Enter Logo" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="text" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['logo']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-left_icon">
                                        <th class="title"> Left Icon: </th>
                                        <td class="value">
                                            <span  data-value="<?php echo $data['left_icon']; ?>" 
                                                data-pk="<?php echo $data['id'] ?>" 
                                                data-url="<?php print_link("mp_langingpage/editfield/" . urlencode($data['id'])); ?>" 
                                                data-name="left_icon" 
                                                data-title="Enter Left Icon" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="text" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['left_icon']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-right_icon">
                                        <th class="title"> Right Icon: </th>
                                        <td class="value">
                                            <span  data-value="<?php echo $data['right_icon']; ?>" 
                                                data-pk="<?php echo $data['id'] ?>" 
                                                data-url="<?php print_link("mp_langingpage/editfield/" . urlencode($data['id'])); ?>" 
                                                data-name="right_icon" 
                                                data-title="Enter Right Icon" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="text" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['right_icon']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-banner">
                                        <th class="title"> Banner: </th>
                                        <td class="value">
                                            <span  data-value="<?php echo $data['banner']; ?>" 
                                                data-pk="<?php echo $data['id'] ?>" 
                                                data-url="<?php print_link("mp_langingpage/editfield/" . urlencode($data['id'])); ?>" 
                                                data-name="banner" 
                                                data-title="Enter Banner" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="text" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['banner']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-slider1">
                                        <th class="title"> Slider1: </th>
                                        <td class="value">
                                            <span  data-value="<?php echo $data['slider1']; ?>" 
                                                data-pk="<?php echo $data['id'] ?>" 
                                                data-url="<?php print_link("mp_langingpage/editfield/" . urlencode($data['id'])); ?>" 
                                                data-name="slider1" 
                                                data-title="Enter Slider1" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="text" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['slider1']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-slider2">
                                        <th class="title"> Slider2: </th>
                                        <td class="value">
                                            <span  data-value="<?php echo $data['slider2']; ?>" 
                                                data-pk="<?php echo $data['id'] ?>" 
                                                data-url="<?php print_link("mp_langingpage/editfield/" . urlencode($data['id'])); ?>" 
                                                data-name="slider2" 
                                                data-title="Enter Slider2" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="text" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['slider2']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-slider3">
                                        <th class="title"> Slider3: </th>
                                        <td class="value">
                                            <span  data-value="<?php echo $data['slider3']; ?>" 
                                                data-pk="<?php echo $data['id'] ?>" 
                                                data-url="<?php print_link("mp_langingpage/editfield/" . urlencode($data['id'])); ?>" 
                                                data-name="slider3" 
                                                data-title="Enter Slider3" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="text" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['slider3']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-slider4">
                                        <th class="title"> Slider4: </th>
                                        <td class="value">
                                            <span  data-value="<?php echo $data['slider4']; ?>" 
                                                data-pk="<?php echo $data['id'] ?>" 
                                                data-url="<?php print_link("mp_langingpage/editfield/" . urlencode($data['id'])); ?>" 
                                                data-name="slider4" 
                                                data-title="Enter Slider4" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="text" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['slider4']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-slider5">
                                        <th class="title"> Slider5: </th>
                                        <td class="value">
                                            <span  data-value="<?php echo $data['slider5']; ?>" 
                                                data-pk="<?php echo $data['id'] ?>" 
                                                data-url="<?php print_link("mp_langingpage/editfield/" . urlencode($data['id'])); ?>" 
                                                data-name="slider5" 
                                                data-title="Enter Slider5" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="text" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['slider5']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-title1">
                                        <th class="title"> Title1: </th>
                                        <td class="value">
                                            <span  data-value="<?php echo $data['title1']; ?>" 
                                                data-pk="<?php echo $data['id'] ?>" 
                                                data-url="<?php print_link("mp_langingpage/editfield/" . urlencode($data['id'])); ?>" 
                                                data-name="title1" 
                                                data-title="Enter Title1" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="text" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['title1']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-title2">
                                        <th class="title"> Title2: </th>
                                        <td class="value">
                                            <span  data-value="<?php echo $data['title2']; ?>" 
                                                data-pk="<?php echo $data['id'] ?>" 
                                                data-url="<?php print_link("mp_langingpage/editfield/" . urlencode($data['id'])); ?>" 
                                                data-name="title2" 
                                                data-title="Enter Title2" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="text" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['title2']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-title3">
                                        <th class="title"> Title3: </th>
                                        <td class="value">
                                            <span  data-value="<?php echo $data['title3']; ?>" 
                                                data-pk="<?php echo $data['id'] ?>" 
                                                data-url="<?php print_link("mp_langingpage/editfield/" . urlencode($data['id'])); ?>" 
                                                data-name="title3" 
                                                data-title="Enter Title3" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="text" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['title3']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-title4">
                                        <th class="title"> Title4: </th>
                                        <td class="value">
                                            <span  data-value="<?php echo $data['title4']; ?>" 
                                                data-pk="<?php echo $data['id'] ?>" 
                                                data-url="<?php print_link("mp_langingpage/editfield/" . urlencode($data['id'])); ?>" 
                                                data-name="title4" 
                                                data-title="Enter Title4" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="text" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['title4']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-title5">
                                        <th class="title"> Title5: </th>
                                        <td class="value">
                                            <span  data-value="<?php echo $data['title5']; ?>" 
                                                data-pk="<?php echo $data['id'] ?>" 
                                                data-url="<?php print_link("mp_langingpage/editfield/" . urlencode($data['id'])); ?>" 
                                                data-name="title5" 
                                                data-title="Enter Title5" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="text" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['title5']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-title6">
                                        <th class="title"> Title6: </th>
                                        <td class="value">
                                            <span  data-value="<?php echo $data['title6']; ?>" 
                                                data-pk="<?php echo $data['id'] ?>" 
                                                data-url="<?php print_link("mp_langingpage/editfield/" . urlencode($data['id'])); ?>" 
                                                data-name="title6" 
                                                data-title="Enter Title6" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="text" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['title6']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-subtitle6">
                                        <th class="title"> Subtitle6: </th>
                                        <td class="value">
                                            <span  data-value="<?php echo $data['subtitle6']; ?>" 
                                                data-pk="<?php echo $data['id'] ?>" 
                                                data-url="<?php print_link("mp_langingpage/editfield/" . urlencode($data['id'])); ?>" 
                                                data-name="subtitle6" 
                                                data-title="Enter Subtitle6" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="text" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['subtitle6']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-subtitle6one">
                                        <th class="title"> Subtitle6one: </th>
                                        <td class="value">
                                            <span  data-value="<?php echo $data['subtitle6one']; ?>" 
                                                data-pk="<?php echo $data['id'] ?>" 
                                                data-url="<?php print_link("mp_langingpage/editfield/" . urlencode($data['id'])); ?>" 
                                                data-name="subtitle6one" 
                                                data-title="Enter Subtitle6one" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="text" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['subtitle6one']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-title8">
                                        <th class="title"> Title8: </th>
                                        <td class="value">
                                            <span  data-value="<?php echo $data['title8']; ?>" 
                                                data-pk="<?php echo $data['id'] ?>" 
                                                data-url="<?php print_link("mp_langingpage/editfield/" . urlencode($data['id'])); ?>" 
                                                data-name="title8" 
                                                data-title="Enter Title8" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="text" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['title8']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-title9">
                                        <th class="title"> Title9: </th>
                                        <td class="value">
                                            <span  data-value="<?php echo $data['title9']; ?>" 
                                                data-pk="<?php echo $data['id'] ?>" 
                                                data-url="<?php print_link("mp_langingpage/editfield/" . urlencode($data['id'])); ?>" 
                                                data-name="title9" 
                                                data-title="Enter Title9" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="text" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['title9']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-title10">
                                        <th class="title"> Title10: </th>
                                        <td class="value">
                                            <span  data-value="<?php echo $data['title10']; ?>" 
                                                data-pk="<?php echo $data['id'] ?>" 
                                                data-url="<?php print_link("mp_langingpage/editfield/" . urlencode($data['id'])); ?>" 
                                                data-name="title10" 
                                                data-title="Enter Title10" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="text" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['title10']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-currency">
                                        <th class="title"> Currency: </th>
                                        <td class="value">
                                            <span  data-value="<?php echo $data['currency']; ?>" 
                                                data-pk="<?php echo $data['id'] ?>" 
                                                data-url="<?php print_link("mp_langingpage/editfield/" . urlencode($data['id'])); ?>" 
                                                data-name="currency" 
                                                data-title="Enter Currency" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="text" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['currency']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-decimal_points">
                                        <th class="title"> Decimal Points: </th>
                                        <td class="value">
                                            <span  data-value="<?php echo $data['decimal_points']; ?>" 
                                                data-pk="<?php echo $data['id'] ?>" 
                                                data-url="<?php print_link("mp_langingpage/editfield/" . urlencode($data['id'])); ?>" 
                                                data-name="decimal_points" 
                                                data-title="Enter Decimal Points" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="number" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['decimal_points']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-language">
                                        <th class="title"> Language: </th>
                                        <td class="value">
                                            <span  data-value="<?php echo $data['language']; ?>" 
                                                data-pk="<?php echo $data['id'] ?>" 
                                                data-url="<?php print_link("mp_langingpage/editfield/" . urlencode($data['id'])); ?>" 
                                                data-name="language" 
                                                data-title="Enter Language" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="text" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['language']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-primarycolor">
                                        <th class="title"> Primarycolor: </th>
                                        <td class="value">
                                            <span  data-value="<?php echo $data['primarycolor']; ?>" 
                                                data-pk="<?php echo $data['id'] ?>" 
                                                data-url="<?php print_link("mp_langingpage/editfield/" . urlencode($data['id'])); ?>" 
                                                data-name="primarycolor" 
                                                data-title="Enter Primarycolor" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="text" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['primarycolor']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-theme_pri_hover">
                                        <th class="title"> Theme Pri Hover: </th>
                                        <td class="value">
                                            <span  data-value="<?php echo $data['theme_pri_hover']; ?>" 
                                                data-pk="<?php echo $data['id'] ?>" 
                                                data-url="<?php print_link("mp_langingpage/editfield/" . urlencode($data['id'])); ?>" 
                                                data-name="theme_pri_hover" 
                                                data-title="Enter Theme Pri Hover" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="text" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['theme_pri_hover']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-expirey">
                                        <th class="title"> Expirey: </th>
                                        <td class="value">
                                            <span  data-value="<?php echo $data['expirey']; ?>" 
                                                data-pk="<?php echo $data['id'] ?>" 
                                                data-url="<?php print_link("mp_langingpage/editfield/" . urlencode($data['id'])); ?>" 
                                                data-name="expirey" 
                                                data-title="Enter Expirey" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="number" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['expirey']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-startday">
                                        <th class="title"> Startday: </th>
                                        <td class="value">
                                            <span  data-value="<?php echo $data['startday']; ?>" 
                                                data-pk="<?php echo $data['id'] ?>" 
                                                data-url="<?php print_link("mp_langingpage/editfield/" . urlencode($data['id'])); ?>" 
                                                data-name="startday" 
                                                data-title="Enter Startday" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="number" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['startday']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-startmonth">
                                        <th class="title"> Startmonth: </th>
                                        <td class="value">
                                            <span  data-value="<?php echo $data['startmonth']; ?>" 
                                                data-pk="<?php echo $data['id'] ?>" 
                                                data-url="<?php print_link("mp_langingpage/editfield/" . urlencode($data['id'])); ?>" 
                                                data-name="startmonth" 
                                                data-title="Enter Startmonth" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="number" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['startmonth']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-endday">
                                        <th class="title"> Endday: </th>
                                        <td class="value">
                                            <span  data-value="<?php echo $data['endday']; ?>" 
                                                data-pk="<?php echo $data['id'] ?>" 
                                                data-url="<?php print_link("mp_langingpage/editfield/" . urlencode($data['id'])); ?>" 
                                                data-name="endday" 
                                                data-title="Enter Endday" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="number" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['endday']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-endmonth">
                                        <th class="title"> Endmonth: </th>
                                        <td class="value">
                                            <span  data-value="<?php echo $data['endmonth']; ?>" 
                                                data-pk="<?php echo $data['id'] ?>" 
                                                data-url="<?php print_link("mp_langingpage/editfield/" . urlencode($data['id'])); ?>" 
                                                data-name="endmonth" 
                                                data-title="Enter Endmonth" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="number" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['endmonth']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-enable_sms">
                                        <th class="title"> Enable Sms: </th>
                                        <td class="value">
                                            <span  data-value="<?php echo $data['enable_sms']; ?>" 
                                                data-pk="<?php echo $data['id'] ?>" 
                                                data-url="<?php print_link("mp_langingpage/editfield/" . urlencode($data['id'])); ?>" 
                                                data-name="enable_sms" 
                                                data-title="Enter Enable Sms" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="text" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['enable_sms']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-sms_domain_name">
                                        <th class="title"> Sms Domain Name: </th>
                                        <td class="value">
                                            <span  data-value="<?php echo $data['sms_domain_name']; ?>" 
                                                data-pk="<?php echo $data['id'] ?>" 
                                                data-url="<?php print_link("mp_langingpage/editfield/" . urlencode($data['id'])); ?>" 
                                                data-name="sms_domain_name" 
                                                data-title="Enter Sms Domain Name" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="text" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['sms_domain_name']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-sms_email_id">
                                        <th class="title"> Sms Email Id: </th>
                                        <td class="value">
                                            <span  data-value="<?php echo $data['sms_email_id']; ?>" 
                                                data-pk="<?php echo $data['id'] ?>" 
                                                data-url="<?php print_link("mp_langingpage/editfield/" . urlencode($data['id'])); ?>" 
                                                data-name="sms_email_id" 
                                                data-title="Enter Sms Email Id" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="email" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['sms_email_id']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-sms_token_key">
                                        <th class="title"> Sms Token Key: </th>
                                        <td class="value">
                                            <span  data-value="<?php echo $data['sms_token_key']; ?>" 
                                                data-pk="<?php echo $data['id'] ?>" 
                                                data-url="<?php print_link("mp_langingpage/editfield/" . urlencode($data['id'])); ?>" 
                                                data-name="sms_token_key" 
                                                data-title="Enter Sms Token Key" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="text" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['sms_token_key']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-sms_mobile_number">
                                        <th class="title"> Sms Mobile Number: </th>
                                        <td class="value">
                                            <span  data-value="<?php echo $data['sms_mobile_number']; ?>" 
                                                data-pk="<?php echo $data['id'] ?>" 
                                                data-url="<?php print_link("mp_langingpage/editfield/" . urlencode($data['id'])); ?>" 
                                                data-name="sms_mobile_number" 
                                                data-title="Enter Sms Mobile Number" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="text" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['sms_mobile_number']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-enable_email">
                                        <th class="title"> Enable Email: </th>
                                        <td class="value">
                                            <span  data-value="<?php echo $data['enable_email']; ?>" 
                                                data-pk="<?php echo $data['id'] ?>" 
                                                data-url="<?php print_link("mp_langingpage/editfield/" . urlencode($data['id'])); ?>" 
                                                data-name="enable_email" 
                                                data-title="Enter Enable Email" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="email" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['enable_email']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-account_address">
                                        <th class="title"> Account Address: </th>
                                        <td class="value">
                                            <span  data-value="<?php echo $data['account_address']; ?>" 
                                                data-pk="<?php echo $data['id'] ?>" 
                                                data-url="<?php print_link("mp_langingpage/editfield/" . urlencode($data['id'])); ?>" 
                                                data-name="account_address" 
                                                data-title="Enter Account Address" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="text" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['account_address']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-account_password">
                                        <th class="title"> Account Password: </th>
                                        <td class="value">
                                            <span  data-value="<?php echo $data['account_password']; ?>" 
                                                data-pk="<?php echo $data['id'] ?>" 
                                                data-url="<?php print_link("mp_langingpage/editfield/" . urlencode($data['id'])); ?>" 
                                                data-name="account_password" 
                                                data-title="Enter Account Password" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="password" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['account_password']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-email_host_port">
                                        <th class="title"> Email Host Port: </th>
                                        <td class="value">
                                            <span  data-value="<?php echo $data['email_host_port']; ?>" 
                                                data-pk="<?php echo $data['id'] ?>" 
                                                data-url="<?php print_link("mp_langingpage/editfield/" . urlencode($data['id'])); ?>" 
                                                data-name="email_host_port" 
                                                data-title="Enter Email Host Port" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="email" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['email_host_port']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-email_host_server">
                                        <th class="title"> Email Host Server: </th>
                                        <td class="value">
                                            <span  data-value="<?php echo $data['email_host_server']; ?>" 
                                                data-pk="<?php echo $data['id'] ?>" 
                                                data-url="<?php print_link("mp_langingpage/editfield/" . urlencode($data['id'])); ?>" 
                                                data-name="email_host_server" 
                                                data-title="Enter Email Host Server" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="email" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['email_host_server']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-receipt_labels">
                                        <th class="title"> Receipt Labels: </th>
                                        <td class="value">
                                            <span  data-pk="<?php echo $data['id'] ?>" 
                                                data-url="<?php print_link("mp_langingpage/editfield/" . urlencode($data['id'])); ?>" 
                                                data-name="receipt_labels" 
                                                data-title="Enter Receipt Labels" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="textarea" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['receipt_labels']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                </tbody>
                                <!-- Table Body End -->
                            </table>
                        </div>
                        <div class="p-3 d-flex">
                            <div class="dropup export-btn-holder mx-1">
                                <button class="btn btn-sm btn-primary dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <i class="fa fa-save"></i> Export
                                </button>
                                <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                    <?php $export_print_link = $this->set_current_page_link(array('format' => 'print')); ?>
                                    <a class="dropdown-item export-link-btn" data-format="print" href="<?php print_link($export_print_link); ?>" target="_blank">
                                        <img src="<?php print_link('assets/images/print.png') ?>" class="mr-2" /> PRINT
                                        </a>
                                        <?php $export_pdf_link = $this->set_current_page_link(array('format' => 'pdf')); ?>
                                        <a class="dropdown-item export-link-btn" data-format="pdf" href="<?php print_link($export_pdf_link); ?>" target="_blank">
                                            <img src="<?php print_link('assets/images/pdf.png') ?>" class="mr-2" /> PDF
                                            </a>
                                            <?php $export_word_link = $this->set_current_page_link(array('format' => 'word')); ?>
                                            <a class="dropdown-item export-link-btn" data-format="word" href="<?php print_link($export_word_link); ?>" target="_blank">
                                                <img src="<?php print_link('assets/images/doc.png') ?>" class="mr-2" /> WORD
                                                </a>
                                                <?php $export_csv_link = $this->set_current_page_link(array('format' => 'csv')); ?>
                                                <a class="dropdown-item export-link-btn" data-format="csv" href="<?php print_link($export_csv_link); ?>" target="_blank">
                                                    <img src="<?php print_link('assets/images/csv.png') ?>" class="mr-2" /> CSV
                                                    </a>
                                                    <?php $export_excel_link = $this->set_current_page_link(array('format' => 'excel')); ?>
                                                    <a class="dropdown-item export-link-btn" data-format="excel" href="<?php print_link($export_excel_link); ?>" target="_blank">
                                                        <img src="<?php print_link('assets/images/xsl.png') ?>" class="mr-2" /> EXCEL
                                                        </a>
                                                    </div>
                                                </div>
                                                <a class="btn btn-sm btn-info"  href="<?php print_link("mp_langingpage/edit/$rec_id"); ?>">
                                                    <i class="fa fa-edit"></i> Edit
                                                </a>
                                                <a class="btn btn-sm btn-danger record-delete-btn mx-1"  href="<?php print_link("mp_langingpage/delete/$rec_id/?csrf_token=$csrf_token&redirect=$current_page"); ?>" data-prompt-msg="Are you sure you want to delete this record?" data-display-style="modal">
                                                    <i class="fa fa-times"></i> Delete
                                                </a>
                                            </div>
                                            <?php
                                            }
                                            else{
                                            ?>
                                            <!-- Empty Record Message -->
                                            <div class="text-muted p-3">
                                                <i class="fa fa-ban"></i> No Record Found
                                            </div>
                                            <?php
                                            }
                                            ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
