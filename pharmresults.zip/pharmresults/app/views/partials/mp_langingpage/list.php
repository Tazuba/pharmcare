<?php
$comp_model = new SharedController;
$page_element_id = "list-page-" . random_str();
$current_page = $this->set_current_page_link();
$csrf_token = Csrf::$token;
//Page Data From Controller
$view_data = $this->view_data;
$records = $view_data->records;
$record_count = $view_data->record_count;
$total_records = $view_data->total_records;
$field_name = $this->route->field_name;
$field_value = $this->route->field_value;
$view_title = $this->view_title;
$show_header = $this->show_header;
$show_footer = $this->show_footer;
$show_pagination = $this->show_pagination;
?>
<section class="page" id="<?php echo $page_element_id; ?>" data-page-type="list"  data-display-type="table" data-page-url="<?php print_link($current_page); ?>">
    <?php
    if( $show_header == true ){
    ?>
    <div  class="bg-light p-3 mb-3">
        <div class="container-fluid">
            <div class="row ">
                <div class="col ">
                    <h4 class="record-title">Mp Langingpage</h4>
                </div>
                <div class="col-sm-3 ">
                    <a  class="btn btn btn-primary my-1" href="<?php print_link("mp_langingpage/add") ?>">
                        <i class="fa fa-plus"></i>                              
                        Add New Mp Langingpage 
                    </a>
                </div>
                <div class="col-sm-4 ">
                    <form  class="search" action="<?php print_link('mp_langingpage'); ?>" method="get">
                        <div class="input-group">
                            <input value="<?php echo get_value('search'); ?>" class="form-control" type="text" name="search"  placeholder="Search" />
                                <div class="input-group-append">
                                    <button class="btn btn-primary"><i class="fa fa-search"></i></button>
                                </div>
                            </div>
                        </form>
                    </div>
                    <div class="col-md-12 comp-grid">
                        <div class="">
                            <!-- Page bread crumbs components-->
                            <?php
                            if(!empty($field_name) || !empty($_GET['search'])){
                            ?>
                            <hr class="sm d-block d-sm-none" />
                            <nav class="page-header-breadcrumbs mt-2" aria-label="breadcrumb">
                                <ul class="breadcrumb m-0 p-1">
                                    <?php
                                    if(!empty($field_name)){
                                    ?>
                                    <li class="breadcrumb-item">
                                        <a class="text-decoration-none" href="<?php print_link('mp_langingpage'); ?>">
                                            <i class="fa fa-angle-left"></i>
                                        </a>
                                    </li>
                                    <li class="breadcrumb-item">
                                        <?php echo (get_value("tag") ? get_value("tag")  :  make_readable($field_name)); ?>
                                    </li>
                                    <li  class="breadcrumb-item active text-capitalize font-weight-bold">
                                        <?php echo (get_value("label") ? get_value("label")  :  make_readable(urldecode($field_value))); ?>
                                    </li>
                                    <?php 
                                    }   
                                    ?>
                                    <?php
                                    if(get_value("search")){
                                    ?>
                                    <li class="breadcrumb-item">
                                        <a class="text-decoration-none" href="<?php print_link('mp_langingpage'); ?>">
                                            <i class="fa fa-angle-left"></i>
                                        </a>
                                    </li>
                                    <li class="breadcrumb-item text-capitalize">
                                        Search
                                    </li>
                                    <li  class="breadcrumb-item active text-capitalize font-weight-bold"><?php echo get_value("search"); ?></li>
                                    <?php
                                    }
                                    ?>
                                </ul>
                            </nav>
                            <!--End of Page bread crumbs components-->
                            <?php
                            }
                            ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php
        }
        ?>
        <div  class="">
            <div class="container-fluid">
                <div class="row ">
                    <div class="col-md-12 comp-grid">
                        <?php $this :: display_page_errors(); ?>
                        <div  class=" animated fadeIn page-content">
                            <div id="mp_langingpage-list-records">
                                <div id="page-report-body" class="table-responsive">
                                    <table class="table  table-striped table-sm text-left">
                                        <thead class="table-header bg-light">
                                            <tr>
                                                <th class="td-checkbox">
                                                    <label class="custom-control custom-checkbox custom-control-inline">
                                                        <input class="toggle-check-all custom-control-input" type="checkbox" />
                                                        <span class="custom-control-label"></span>
                                                    </label>
                                                </th>
                                                <th class="td-sno">#</th>
                                                <th  class="td-id"> Id</th>
                                                <th  class="td-companyname"> Companyname</th>
                                                <th  class="td-companydescription"> Companydescription</th>
                                                <th  class="td-companykeywords"> Companykeywords</th>
                                                <th  class="td-license_no"> License No</th>
                                                <th  class="td-printer_enable"> Printer Enable</th>
                                                <th  class="td-address"> Address</th>
                                                <th  class="td-email"> Email</th>
                                                <th  class="td-contact"> Contact</th>
                                                <th  class="td-logo"> Logo</th>
                                                <th  class="td-left_icon"> Left Icon</th>
                                                <th  class="td-right_icon"> Right Icon</th>
                                                <th  class="td-banner"> Banner</th>
                                                <th  class="td-slider1"> Slider1</th>
                                                <th  class="td-slider2"> Slider2</th>
                                                <th  class="td-slider3"> Slider3</th>
                                                <th  class="td-slider4"> Slider4</th>
                                                <th  class="td-slider5"> Slider5</th>
                                                <th  class="td-title1"> Title1</th>
                                                <th  class="td-title2"> Title2</th>
                                                <th  class="td-title3"> Title3</th>
                                                <th  class="td-title4"> Title4</th>
                                                <th  class="td-title5"> Title5</th>
                                                <th  class="td-title6"> Title6</th>
                                                <th  class="td-subtitle6"> Subtitle6</th>
                                                <th  class="td-subtitle6one"> Subtitle6one</th>
                                                <th  class="td-title8"> Title8</th>
                                                <th  class="td-title9"> Title9</th>
                                                <th  class="td-title10"> Title10</th>
                                                <th  class="td-currency"> Currency</th>
                                                <th  class="td-decimal_points"> Decimal Points</th>
                                                <th  class="td-language"> Language</th>
                                                <th  class="td-primarycolor"> Primarycolor</th>
                                                <th  class="td-theme_pri_hover"> Theme Pri Hover</th>
                                                <th  class="td-expirey"> Expirey</th>
                                                <th  class="td-startday"> Startday</th>
                                                <th  class="td-startmonth"> Startmonth</th>
                                                <th  class="td-endday"> Endday</th>
                                                <th  class="td-endmonth"> Endmonth</th>
                                                <th  class="td-enable_sms"> Enable Sms</th>
                                                <th  class="td-sms_domain_name"> Sms Domain Name</th>
                                                <th  class="td-sms_email_id"> Sms Email Id</th>
                                                <th  class="td-sms_token_key"> Sms Token Key</th>
                                                <th  class="td-sms_mobile_number"> Sms Mobile Number</th>
                                                <th  class="td-enable_email"> Enable Email</th>
                                                <th  class="td-account_address"> Account Address</th>
                                                <th  class="td-account_password"> Account Password</th>
                                                <th  class="td-email_host_port"> Email Host Port</th>
                                                <th  class="td-email_host_server"> Email Host Server</th>
                                                <th  class="td-receipt_labels"> Receipt Labels</th>
                                                <th class="td-btn"></th>
                                            </tr>
                                        </thead>
                                        <?php
                                        if(!empty($records)){
                                        ?>
                                        <tbody class="page-data" id="page-data-<?php echo $page_element_id; ?>">
                                            <!--record-->
                                            <?php
                                            $counter = 0;
                                            foreach($records as $data){
                                            $rec_id = (!empty($data['id']) ? urlencode($data['id']) : null);
                                            $counter++;
                                            ?>
                                            <tr>
                                                <th class=" td-checkbox">
                                                    <label class="custom-control custom-checkbox custom-control-inline">
                                                        <input class="optioncheck custom-control-input" name="optioncheck[]" value="<?php echo $data['id'] ?>" type="checkbox" />
                                                            <span class="custom-control-label"></span>
                                                        </label>
                                                    </th>
                                                    <th class="td-sno"><?php echo $counter; ?></th>
                                                    <td class="td-id"><a href="<?php print_link("mp_langingpage/view/$data[id]") ?>"><?php echo $data['id']; ?></a></td>
                                                    <td class="td-companyname">
                                                        <span  data-value="<?php echo $data['companyname']; ?>" 
                                                            data-pk="<?php echo $data['id'] ?>" 
                                                            data-url="<?php print_link("mp_langingpage/editfield/" . urlencode($data['id'])); ?>" 
                                                            data-name="companyname" 
                                                            data-title="Enter Companyname" 
                                                            data-placement="left" 
                                                            data-toggle="click" 
                                                            data-type="text" 
                                                            data-mode="popover" 
                                                            data-showbuttons="left" 
                                                            class="is-editable" >
                                                            <?php echo $data['companyname']; ?> 
                                                        </span>
                                                    </td>
                                                    <td class="td-companydescription">
                                                        <span  data-value="<?php echo $data['companydescription']; ?>" 
                                                            data-pk="<?php echo $data['id'] ?>" 
                                                            data-url="<?php print_link("mp_langingpage/editfield/" . urlencode($data['id'])); ?>" 
                                                            data-name="companydescription" 
                                                            data-title="Enter Companydescription" 
                                                            data-placement="left" 
                                                            data-toggle="click" 
                                                            data-type="text" 
                                                            data-mode="popover" 
                                                            data-showbuttons="left" 
                                                            class="is-editable" >
                                                            <?php echo $data['companydescription']; ?> 
                                                        </span>
                                                    </td>
                                                    <td class="td-companykeywords">
                                                        <span  data-value="<?php echo $data['companykeywords']; ?>" 
                                                            data-pk="<?php echo $data['id'] ?>" 
                                                            data-url="<?php print_link("mp_langingpage/editfield/" . urlencode($data['id'])); ?>" 
                                                            data-name="companykeywords" 
                                                            data-title="Enter Companykeywords" 
                                                            data-placement="left" 
                                                            data-toggle="click" 
                                                            data-type="text" 
                                                            data-mode="popover" 
                                                            data-showbuttons="left" 
                                                            class="is-editable" >
                                                            <?php echo $data['companykeywords']; ?> 
                                                        </span>
                                                    </td>
                                                    <td class="td-license_no">
                                                        <span  data-value="<?php echo $data['license_no']; ?>" 
                                                            data-pk="<?php echo $data['id'] ?>" 
                                                            data-url="<?php print_link("mp_langingpage/editfield/" . urlencode($data['id'])); ?>" 
                                                            data-name="license_no" 
                                                            data-title="Enter License No" 
                                                            data-placement="left" 
                                                            data-toggle="click" 
                                                            data-type="text" 
                                                            data-mode="popover" 
                                                            data-showbuttons="left" 
                                                            class="is-editable" >
                                                            <?php echo $data['license_no']; ?> 
                                                        </span>
                                                    </td>
                                                    <td class="td-printer_enable">
                                                        <span  data-value="<?php echo $data['printer_enable']; ?>" 
                                                            data-pk="<?php echo $data['id'] ?>" 
                                                            data-url="<?php print_link("mp_langingpage/editfield/" . urlencode($data['id'])); ?>" 
                                                            data-name="printer_enable" 
                                                            data-title="Enter Printer Enable" 
                                                            data-placement="left" 
                                                            data-toggle="click" 
                                                            data-type="text" 
                                                            data-mode="popover" 
                                                            data-showbuttons="left" 
                                                            class="is-editable" >
                                                            <?php echo $data['printer_enable']; ?> 
                                                        </span>
                                                    </td>
                                                    <td class="td-address">
                                                        <span  data-value="<?php echo $data['address']; ?>" 
                                                            data-pk="<?php echo $data['id'] ?>" 
                                                            data-url="<?php print_link("mp_langingpage/editfield/" . urlencode($data['id'])); ?>" 
                                                            data-name="address" 
                                                            data-title="Enter Address" 
                                                            data-placement="left" 
                                                            data-toggle="click" 
                                                            data-type="text" 
                                                            data-mode="popover" 
                                                            data-showbuttons="left" 
                                                            class="is-editable" >
                                                            <?php echo $data['address']; ?> 
                                                        </span>
                                                    </td>
                                                    <td class="td-email"><a href="<?php print_link("mailto:$data[email]") ?>"><?php echo $data['email']; ?></a></td>
                                                    <td class="td-contact">
                                                        <span  data-value="<?php echo $data['contact']; ?>" 
                                                            data-pk="<?php echo $data['id'] ?>" 
                                                            data-url="<?php print_link("mp_langingpage/editfield/" . urlencode($data['id'])); ?>" 
                                                            data-name="contact" 
                                                            data-title="Enter Contact" 
                                                            data-placement="left" 
                                                            data-toggle="click" 
                                                            data-type="text" 
                                                            data-mode="popover" 
                                                            data-showbuttons="left" 
                                                            class="is-editable" >
                                                            <?php echo $data['contact']; ?> 
                                                        </span>
                                                    </td>
                                                    <td class="td-logo">
                                                        <span  data-value="<?php echo $data['logo']; ?>" 
                                                            data-pk="<?php echo $data['id'] ?>" 
                                                            data-url="<?php print_link("mp_langingpage/editfield/" . urlencode($data['id'])); ?>" 
                                                            data-name="logo" 
                                                            data-title="Enter Logo" 
                                                            data-placement="left" 
                                                            data-toggle="click" 
                                                            data-type="text" 
                                                            data-mode="popover" 
                                                            data-showbuttons="left" 
                                                            class="is-editable" >
                                                            <?php echo $data['logo']; ?> 
                                                        </span>
                                                    </td>
                                                    <td class="td-left_icon">
                                                        <span  data-value="<?php echo $data['left_icon']; ?>" 
                                                            data-pk="<?php echo $data['id'] ?>" 
                                                            data-url="<?php print_link("mp_langingpage/editfield/" . urlencode($data['id'])); ?>" 
                                                            data-name="left_icon" 
                                                            data-title="Enter Left Icon" 
                                                            data-placement="left" 
                                                            data-toggle="click" 
                                                            data-type="text" 
                                                            data-mode="popover" 
                                                            data-showbuttons="left" 
                                                            class="is-editable" >
                                                            <?php echo $data['left_icon']; ?> 
                                                        </span>
                                                    </td>
                                                    <td class="td-right_icon">
                                                        <span  data-value="<?php echo $data['right_icon']; ?>" 
                                                            data-pk="<?php echo $data['id'] ?>" 
                                                            data-url="<?php print_link("mp_langingpage/editfield/" . urlencode($data['id'])); ?>" 
                                                            data-name="right_icon" 
                                                            data-title="Enter Right Icon" 
                                                            data-placement="left" 
                                                            data-toggle="click" 
                                                            data-type="text" 
                                                            data-mode="popover" 
                                                            data-showbuttons="left" 
                                                            class="is-editable" >
                                                            <?php echo $data['right_icon']; ?> 
                                                        </span>
                                                    </td>
                                                    <td class="td-banner">
                                                        <span  data-value="<?php echo $data['banner']; ?>" 
                                                            data-pk="<?php echo $data['id'] ?>" 
                                                            data-url="<?php print_link("mp_langingpage/editfield/" . urlencode($data['id'])); ?>" 
                                                            data-name="banner" 
                                                            data-title="Enter Banner" 
                                                            data-placement="left" 
                                                            data-toggle="click" 
                                                            data-type="text" 
                                                            data-mode="popover" 
                                                            data-showbuttons="left" 
                                                            class="is-editable" >
                                                            <?php echo $data['banner']; ?> 
                                                        </span>
                                                    </td>
                                                    <td class="td-slider1">
                                                        <span  data-value="<?php echo $data['slider1']; ?>" 
                                                            data-pk="<?php echo $data['id'] ?>" 
                                                            data-url="<?php print_link("mp_langingpage/editfield/" . urlencode($data['id'])); ?>" 
                                                            data-name="slider1" 
                                                            data-title="Enter Slider1" 
                                                            data-placement="left" 
                                                            data-toggle="click" 
                                                            data-type="text" 
                                                            data-mode="popover" 
                                                            data-showbuttons="left" 
                                                            class="is-editable" >
                                                            <?php echo $data['slider1']; ?> 
                                                        </span>
                                                    </td>
                                                    <td class="td-slider2">
                                                        <span  data-value="<?php echo $data['slider2']; ?>" 
                                                            data-pk="<?php echo $data['id'] ?>" 
                                                            data-url="<?php print_link("mp_langingpage/editfield/" . urlencode($data['id'])); ?>" 
                                                            data-name="slider2" 
                                                            data-title="Enter Slider2" 
                                                            data-placement="left" 
                                                            data-toggle="click" 
                                                            data-type="text" 
                                                            data-mode="popover" 
                                                            data-showbuttons="left" 
                                                            class="is-editable" >
                                                            <?php echo $data['slider2']; ?> 
                                                        </span>
                                                    </td>
                                                    <td class="td-slider3">
                                                        <span  data-value="<?php echo $data['slider3']; ?>" 
                                                            data-pk="<?php echo $data['id'] ?>" 
                                                            data-url="<?php print_link("mp_langingpage/editfield/" . urlencode($data['id'])); ?>" 
                                                            data-name="slider3" 
                                                            data-title="Enter Slider3" 
                                                            data-placement="left" 
                                                            data-toggle="click" 
                                                            data-type="text" 
                                                            data-mode="popover" 
                                                            data-showbuttons="left" 
                                                            class="is-editable" >
                                                            <?php echo $data['slider3']; ?> 
                                                        </span>
                                                    </td>
                                                    <td class="td-slider4">
                                                        <span  data-value="<?php echo $data['slider4']; ?>" 
                                                            data-pk="<?php echo $data['id'] ?>" 
                                                            data-url="<?php print_link("mp_langingpage/editfield/" . urlencode($data['id'])); ?>" 
                                                            data-name="slider4" 
                                                            data-title="Enter Slider4" 
                                                            data-placement="left" 
                                                            data-toggle="click" 
                                                            data-type="text" 
                                                            data-mode="popover" 
                                                            data-showbuttons="left" 
                                                            class="is-editable" >
                                                            <?php echo $data['slider4']; ?> 
                                                        </span>
                                                    </td>
                                                    <td class="td-slider5">
                                                        <span  data-value="<?php echo $data['slider5']; ?>" 
                                                            data-pk="<?php echo $data['id'] ?>" 
                                                            data-url="<?php print_link("mp_langingpage/editfield/" . urlencode($data['id'])); ?>" 
                                                            data-name="slider5" 
                                                            data-title="Enter Slider5" 
                                                            data-placement="left" 
                                                            data-toggle="click" 
                                                            data-type="text" 
                                                            data-mode="popover" 
                                                            data-showbuttons="left" 
                                                            class="is-editable" >
                                                            <?php echo $data['slider5']; ?> 
                                                        </span>
                                                    </td>
                                                    <td class="td-title1">
                                                        <span  data-value="<?php echo $data['title1']; ?>" 
                                                            data-pk="<?php echo $data['id'] ?>" 
                                                            data-url="<?php print_link("mp_langingpage/editfield/" . urlencode($data['id'])); ?>" 
                                                            data-name="title1" 
                                                            data-title="Enter Title1" 
                                                            data-placement="left" 
                                                            data-toggle="click" 
                                                            data-type="text" 
                                                            data-mode="popover" 
                                                            data-showbuttons="left" 
                                                            class="is-editable" >
                                                            <?php echo $data['title1']; ?> 
                                                        </span>
                                                    </td>
                                                    <td class="td-title2">
                                                        <span  data-value="<?php echo $data['title2']; ?>" 
                                                            data-pk="<?php echo $data['id'] ?>" 
                                                            data-url="<?php print_link("mp_langingpage/editfield/" . urlencode($data['id'])); ?>" 
                                                            data-name="title2" 
                                                            data-title="Enter Title2" 
                                                            data-placement="left" 
                                                            data-toggle="click" 
                                                            data-type="text" 
                                                            data-mode="popover" 
                                                            data-showbuttons="left" 
                                                            class="is-editable" >
                                                            <?php echo $data['title2']; ?> 
                                                        </span>
                                                    </td>
                                                    <td class="td-title3">
                                                        <span  data-value="<?php echo $data['title3']; ?>" 
                                                            data-pk="<?php echo $data['id'] ?>" 
                                                            data-url="<?php print_link("mp_langingpage/editfield/" . urlencode($data['id'])); ?>" 
                                                            data-name="title3" 
                                                            data-title="Enter Title3" 
                                                            data-placement="left" 
                                                            data-toggle="click" 
                                                            data-type="text" 
                                                            data-mode="popover" 
                                                            data-showbuttons="left" 
                                                            class="is-editable" >
                                                            <?php echo $data['title3']; ?> 
                                                        </span>
                                                    </td>
                                                    <td class="td-title4">
                                                        <span  data-value="<?php echo $data['title4']; ?>" 
                                                            data-pk="<?php echo $data['id'] ?>" 
                                                            data-url="<?php print_link("mp_langingpage/editfield/" . urlencode($data['id'])); ?>" 
                                                            data-name="title4" 
                                                            data-title="Enter Title4" 
                                                            data-placement="left" 
                                                            data-toggle="click" 
                                                            data-type="text" 
                                                            data-mode="popover" 
                                                            data-showbuttons="left" 
                                                            class="is-editable" >
                                                            <?php echo $data['title4']; ?> 
                                                        </span>
                                                    </td>
                                                    <td class="td-title5">
                                                        <span  data-value="<?php echo $data['title5']; ?>" 
                                                            data-pk="<?php echo $data['id'] ?>" 
                                                            data-url="<?php print_link("mp_langingpage/editfield/" . urlencode($data['id'])); ?>" 
                                                            data-name="title5" 
                                                            data-title="Enter Title5" 
                                                            data-placement="left" 
                                                            data-toggle="click" 
                                                            data-type="text" 
                                                            data-mode="popover" 
                                                            data-showbuttons="left" 
                                                            class="is-editable" >
                                                            <?php echo $data['title5']; ?> 
                                                        </span>
                                                    </td>
                                                    <td class="td-title6">
                                                        <span  data-value="<?php echo $data['title6']; ?>" 
                                                            data-pk="<?php echo $data['id'] ?>" 
                                                            data-url="<?php print_link("mp_langingpage/editfield/" . urlencode($data['id'])); ?>" 
                                                            data-name="title6" 
                                                            data-title="Enter Title6" 
                                                            data-placement="left" 
                                                            data-toggle="click" 
                                                            data-type="text" 
                                                            data-mode="popover" 
                                                            data-showbuttons="left" 
                                                            class="is-editable" >
                                                            <?php echo $data['title6']; ?> 
                                                        </span>
                                                    </td>
                                                    <td class="td-subtitle6">
                                                        <span  data-value="<?php echo $data['subtitle6']; ?>" 
                                                            data-pk="<?php echo $data['id'] ?>" 
                                                            data-url="<?php print_link("mp_langingpage/editfield/" . urlencode($data['id'])); ?>" 
                                                            data-name="subtitle6" 
                                                            data-title="Enter Subtitle6" 
                                                            data-placement="left" 
                                                            data-toggle="click" 
                                                            data-type="text" 
                                                            data-mode="popover" 
                                                            data-showbuttons="left" 
                                                            class="is-editable" >
                                                            <?php echo $data['subtitle6']; ?> 
                                                        </span>
                                                    </td>
                                                    <td class="td-subtitle6one">
                                                        <span  data-value="<?php echo $data['subtitle6one']; ?>" 
                                                            data-pk="<?php echo $data['id'] ?>" 
                                                            data-url="<?php print_link("mp_langingpage/editfield/" . urlencode($data['id'])); ?>" 
                                                            data-name="subtitle6one" 
                                                            data-title="Enter Subtitle6one" 
                                                            data-placement="left" 
                                                            data-toggle="click" 
                                                            data-type="text" 
                                                            data-mode="popover" 
                                                            data-showbuttons="left" 
                                                            class="is-editable" >
                                                            <?php echo $data['subtitle6one']; ?> 
                                                        </span>
                                                    </td>
                                                    <td class="td-title8">
                                                        <span  data-value="<?php echo $data['title8']; ?>" 
                                                            data-pk="<?php echo $data['id'] ?>" 
                                                            data-url="<?php print_link("mp_langingpage/editfield/" . urlencode($data['id'])); ?>" 
                                                            data-name="title8" 
                                                            data-title="Enter Title8" 
                                                            data-placement="left" 
                                                            data-toggle="click" 
                                                            data-type="text" 
                                                            data-mode="popover" 
                                                            data-showbuttons="left" 
                                                            class="is-editable" >
                                                            <?php echo $data['title8']; ?> 
                                                        </span>
                                                    </td>
                                                    <td class="td-title9">
                                                        <span  data-value="<?php echo $data['title9']; ?>" 
                                                            data-pk="<?php echo $data['id'] ?>" 
                                                            data-url="<?php print_link("mp_langingpage/editfield/" . urlencode($data['id'])); ?>" 
                                                            data-name="title9" 
                                                            data-title="Enter Title9" 
                                                            data-placement="left" 
                                                            data-toggle="click" 
                                                            data-type="text" 
                                                            data-mode="popover" 
                                                            data-showbuttons="left" 
                                                            class="is-editable" >
                                                            <?php echo $data['title9']; ?> 
                                                        </span>
                                                    </td>
                                                    <td class="td-title10">
                                                        <span  data-value="<?php echo $data['title10']; ?>" 
                                                            data-pk="<?php echo $data['id'] ?>" 
                                                            data-url="<?php print_link("mp_langingpage/editfield/" . urlencode($data['id'])); ?>" 
                                                            data-name="title10" 
                                                            data-title="Enter Title10" 
                                                            data-placement="left" 
                                                            data-toggle="click" 
                                                            data-type="text" 
                                                            data-mode="popover" 
                                                            data-showbuttons="left" 
                                                            class="is-editable" >
                                                            <?php echo $data['title10']; ?> 
                                                        </span>
                                                    </td>
                                                    <td class="td-currency">
                                                        <span  data-value="<?php echo $data['currency']; ?>" 
                                                            data-pk="<?php echo $data['id'] ?>" 
                                                            data-url="<?php print_link("mp_langingpage/editfield/" . urlencode($data['id'])); ?>" 
                                                            data-name="currency" 
                                                            data-title="Enter Currency" 
                                                            data-placement="left" 
                                                            data-toggle="click" 
                                                            data-type="text" 
                                                            data-mode="popover" 
                                                            data-showbuttons="left" 
                                                            class="is-editable" >
                                                            <?php echo $data['currency']; ?> 
                                                        </span>
                                                    </td>
                                                    <td class="td-decimal_points">
                                                        <span  data-value="<?php echo $data['decimal_points']; ?>" 
                                                            data-pk="<?php echo $data['id'] ?>" 
                                                            data-url="<?php print_link("mp_langingpage/editfield/" . urlencode($data['id'])); ?>" 
                                                            data-name="decimal_points" 
                                                            data-title="Enter Decimal Points" 
                                                            data-placement="left" 
                                                            data-toggle="click" 
                                                            data-type="number" 
                                                            data-mode="popover" 
                                                            data-showbuttons="left" 
                                                            class="is-editable" >
                                                            <?php echo $data['decimal_points']; ?> 
                                                        </span>
                                                    </td>
                                                    <td class="td-language">
                                                        <span  data-value="<?php echo $data['language']; ?>" 
                                                            data-pk="<?php echo $data['id'] ?>" 
                                                            data-url="<?php print_link("mp_langingpage/editfield/" . urlencode($data['id'])); ?>" 
                                                            data-name="language" 
                                                            data-title="Enter Language" 
                                                            data-placement="left" 
                                                            data-toggle="click" 
                                                            data-type="text" 
                                                            data-mode="popover" 
                                                            data-showbuttons="left" 
                                                            class="is-editable" >
                                                            <?php echo $data['language']; ?> 
                                                        </span>
                                                    </td>
                                                    <td class="td-primarycolor">
                                                        <span  data-value="<?php echo $data['primarycolor']; ?>" 
                                                            data-pk="<?php echo $data['id'] ?>" 
                                                            data-url="<?php print_link("mp_langingpage/editfield/" . urlencode($data['id'])); ?>" 
                                                            data-name="primarycolor" 
                                                            data-title="Enter Primarycolor" 
                                                            data-placement="left" 
                                                            data-toggle="click" 
                                                            data-type="text" 
                                                            data-mode="popover" 
                                                            data-showbuttons="left" 
                                                            class="is-editable" >
                                                            <?php echo $data['primarycolor']; ?> 
                                                        </span>
                                                    </td>
                                                    <td class="td-theme_pri_hover">
                                                        <span  data-value="<?php echo $data['theme_pri_hover']; ?>" 
                                                            data-pk="<?php echo $data['id'] ?>" 
                                                            data-url="<?php print_link("mp_langingpage/editfield/" . urlencode($data['id'])); ?>" 
                                                            data-name="theme_pri_hover" 
                                                            data-title="Enter Theme Pri Hover" 
                                                            data-placement="left" 
                                                            data-toggle="click" 
                                                            data-type="text" 
                                                            data-mode="popover" 
                                                            data-showbuttons="left" 
                                                            class="is-editable" >
                                                            <?php echo $data['theme_pri_hover']; ?> 
                                                        </span>
                                                    </td>
                                                    <td class="td-expirey">
                                                        <span  data-value="<?php echo $data['expirey']; ?>" 
                                                            data-pk="<?php echo $data['id'] ?>" 
                                                            data-url="<?php print_link("mp_langingpage/editfield/" . urlencode($data['id'])); ?>" 
                                                            data-name="expirey" 
                                                            data-title="Enter Expirey" 
                                                            data-placement="left" 
                                                            data-toggle="click" 
                                                            data-type="number" 
                                                            data-mode="popover" 
                                                            data-showbuttons="left" 
                                                            class="is-editable" >
                                                            <?php echo $data['expirey']; ?> 
                                                        </span>
                                                    </td>
                                                    <td class="td-startday">
                                                        <span  data-value="<?php echo $data['startday']; ?>" 
                                                            data-pk="<?php echo $data['id'] ?>" 
                                                            data-url="<?php print_link("mp_langingpage/editfield/" . urlencode($data['id'])); ?>" 
                                                            data-name="startday" 
                                                            data-title="Enter Startday" 
                                                            data-placement="left" 
                                                            data-toggle="click" 
                                                            data-type="number" 
                                                            data-mode="popover" 
                                                            data-showbuttons="left" 
                                                            class="is-editable" >
                                                            <?php echo $data['startday']; ?> 
                                                        </span>
                                                    </td>
                                                    <td class="td-startmonth">
                                                        <span  data-value="<?php echo $data['startmonth']; ?>" 
                                                            data-pk="<?php echo $data['id'] ?>" 
                                                            data-url="<?php print_link("mp_langingpage/editfield/" . urlencode($data['id'])); ?>" 
                                                            data-name="startmonth" 
                                                            data-title="Enter Startmonth" 
                                                            data-placement="left" 
                                                            data-toggle="click" 
                                                            data-type="number" 
                                                            data-mode="popover" 
                                                            data-showbuttons="left" 
                                                            class="is-editable" >
                                                            <?php echo $data['startmonth']; ?> 
                                                        </span>
                                                    </td>
                                                    <td class="td-endday">
                                                        <span  data-value="<?php echo $data['endday']; ?>" 
                                                            data-pk="<?php echo $data['id'] ?>" 
                                                            data-url="<?php print_link("mp_langingpage/editfield/" . urlencode($data['id'])); ?>" 
                                                            data-name="endday" 
                                                            data-title="Enter Endday" 
                                                            data-placement="left" 
                                                            data-toggle="click" 
                                                            data-type="number" 
                                                            data-mode="popover" 
                                                            data-showbuttons="left" 
                                                            class="is-editable" >
                                                            <?php echo $data['endday']; ?> 
                                                        </span>
                                                    </td>
                                                    <td class="td-endmonth">
                                                        <span  data-value="<?php echo $data['endmonth']; ?>" 
                                                            data-pk="<?php echo $data['id'] ?>" 
                                                            data-url="<?php print_link("mp_langingpage/editfield/" . urlencode($data['id'])); ?>" 
                                                            data-name="endmonth" 
                                                            data-title="Enter Endmonth" 
                                                            data-placement="left" 
                                                            data-toggle="click" 
                                                            data-type="number" 
                                                            data-mode="popover" 
                                                            data-showbuttons="left" 
                                                            class="is-editable" >
                                                            <?php echo $data['endmonth']; ?> 
                                                        </span>
                                                    </td>
                                                    <td class="td-enable_sms">
                                                        <span  data-value="<?php echo $data['enable_sms']; ?>" 
                                                            data-pk="<?php echo $data['id'] ?>" 
                                                            data-url="<?php print_link("mp_langingpage/editfield/" . urlencode($data['id'])); ?>" 
                                                            data-name="enable_sms" 
                                                            data-title="Enter Enable Sms" 
                                                            data-placement="left" 
                                                            data-toggle="click" 
                                                            data-type="text" 
                                                            data-mode="popover" 
                                                            data-showbuttons="left" 
                                                            class="is-editable" >
                                                            <?php echo $data['enable_sms']; ?> 
                                                        </span>
                                                    </td>
                                                    <td class="td-sms_domain_name">
                                                        <span  data-value="<?php echo $data['sms_domain_name']; ?>" 
                                                            data-pk="<?php echo $data['id'] ?>" 
                                                            data-url="<?php print_link("mp_langingpage/editfield/" . urlencode($data['id'])); ?>" 
                                                            data-name="sms_domain_name" 
                                                            data-title="Enter Sms Domain Name" 
                                                            data-placement="left" 
                                                            data-toggle="click" 
                                                            data-type="text" 
                                                            data-mode="popover" 
                                                            data-showbuttons="left" 
                                                            class="is-editable" >
                                                            <?php echo $data['sms_domain_name']; ?> 
                                                        </span>
                                                    </td>
                                                    <td class="td-sms_email_id"><a href="<?php print_link("mailto:$data[sms_email_id]") ?>"><?php echo $data['sms_email_id']; ?></a></td>
                                                    <td class="td-sms_token_key">
                                                        <span  data-value="<?php echo $data['sms_token_key']; ?>" 
                                                            data-pk="<?php echo $data['id'] ?>" 
                                                            data-url="<?php print_link("mp_langingpage/editfield/" . urlencode($data['id'])); ?>" 
                                                            data-name="sms_token_key" 
                                                            data-title="Enter Sms Token Key" 
                                                            data-placement="left" 
                                                            data-toggle="click" 
                                                            data-type="text" 
                                                            data-mode="popover" 
                                                            data-showbuttons="left" 
                                                            class="is-editable" >
                                                            <?php echo $data['sms_token_key']; ?> 
                                                        </span>
                                                    </td>
                                                    <td class="td-sms_mobile_number">
                                                        <span  data-value="<?php echo $data['sms_mobile_number']; ?>" 
                                                            data-pk="<?php echo $data['id'] ?>" 
                                                            data-url="<?php print_link("mp_langingpage/editfield/" . urlencode($data['id'])); ?>" 
                                                            data-name="sms_mobile_number" 
                                                            data-title="Enter Sms Mobile Number" 
                                                            data-placement="left" 
                                                            data-toggle="click" 
                                                            data-type="text" 
                                                            data-mode="popover" 
                                                            data-showbuttons="left" 
                                                            class="is-editable" >
                                                            <?php echo $data['sms_mobile_number']; ?> 
                                                        </span>
                                                    </td>
                                                    <td class="td-enable_email"><a href="<?php print_link("mailto:$data[enable_email]") ?>"><?php echo $data['enable_email']; ?></a></td>
                                                    <td class="td-account_address">
                                                        <span  data-value="<?php echo $data['account_address']; ?>" 
                                                            data-pk="<?php echo $data['id'] ?>" 
                                                            data-url="<?php print_link("mp_langingpage/editfield/" . urlencode($data['id'])); ?>" 
                                                            data-name="account_address" 
                                                            data-title="Enter Account Address" 
                                                            data-placement="left" 
                                                            data-toggle="click" 
                                                            data-type="text" 
                                                            data-mode="popover" 
                                                            data-showbuttons="left" 
                                                            class="is-editable" >
                                                            <?php echo $data['account_address']; ?> 
                                                        </span>
                                                    </td>
                                                    <td class="td-account_password">
                                                        <span  data-value="<?php echo $data['account_password']; ?>" 
                                                            data-pk="<?php echo $data['id'] ?>" 
                                                            data-url="<?php print_link("mp_langingpage/editfield/" . urlencode($data['id'])); ?>" 
                                                            data-name="account_password" 
                                                            data-title="Enter Account Password" 
                                                            data-placement="left" 
                                                            data-toggle="click" 
                                                            data-type="password" 
                                                            data-mode="popover" 
                                                            data-showbuttons="left" 
                                                            class="is-editable" >
                                                            <?php echo $data['account_password']; ?> 
                                                        </span>
                                                    </td>
                                                    <td class="td-email_host_port"><a href="<?php print_link("mailto:$data[email_host_port]") ?>"><?php echo $data['email_host_port']; ?></a></td>
                                                    <td class="td-email_host_server"><a href="<?php print_link("mailto:$data[email_host_server]") ?>"><?php echo $data['email_host_server']; ?></a></td>
                                                    <td class="td-receipt_labels">
                                                        <span  data-pk="<?php echo $data['id'] ?>" 
                                                            data-url="<?php print_link("mp_langingpage/editfield/" . urlencode($data['id'])); ?>" 
                                                            data-name="receipt_labels" 
                                                            data-title="Enter Receipt Labels" 
                                                            data-placement="left" 
                                                            data-toggle="click" 
                                                            data-type="textarea" 
                                                            data-mode="popover" 
                                                            data-showbuttons="left" 
                                                            class="is-editable" >
                                                            <?php echo $data['receipt_labels']; ?> 
                                                        </span>
                                                    </td>
                                                    <th class="td-btn">
                                                        <a class="btn btn-sm btn-success has-tooltip" title="View Record" href="<?php print_link("mp_langingpage/view/$rec_id"); ?>">
                                                            <i class="fa fa-eye"></i> View
                                                        </a>
                                                        <a class="btn btn-sm btn-info has-tooltip" title="Edit This Record" href="<?php print_link("mp_langingpage/edit/$rec_id"); ?>">
                                                            <i class="fa fa-edit"></i> Edit
                                                        </a>
                                                        <a class="btn btn-sm btn-danger has-tooltip record-delete-btn" title="Delete this record" href="<?php print_link("mp_langingpage/delete/$rec_id/?csrf_token=$csrf_token&redirect=$current_page"); ?>" data-prompt-msg="Are you sure you want to delete this record?" data-display-style="modal">
                                                            <i class="fa fa-times"></i>
                                                            Delete
                                                        </a>
                                                    </th>
                                                </tr>
                                                <?php 
                                                }
                                                ?>
                                                <!--endrecord-->
                                            </tbody>
                                            <tbody class="search-data" id="search-data-<?php echo $page_element_id; ?>"></tbody>
                                            <?php
                                            }
                                            ?>
                                        </table>
                                        <?php 
                                        if(empty($records)){
                                        ?>
                                        <h4 class="bg-light text-center border-top text-muted animated bounce  p-3">
                                            <i class="fa fa-ban"></i> No record found
                                        </h4>
                                        <?php
                                        }
                                        ?>
                                    </div>
                                    <?php
                                    if( $show_footer && !empty($records)){
                                    ?>
                                    <div class=" border-top mt-2">
                                        <div class="row justify-content-center">    
                                            <div class="col-md-auto justify-content-center">    
                                                <div class="p-3 d-flex justify-content-between">    
                                                    <button data-prompt-msg="Are you sure you want to delete these records?" data-display-style="modal" data-url="<?php print_link("mp_langingpage/delete/{sel_ids}/?csrf_token=$csrf_token&redirect=$current_page"); ?>" class="btn btn-sm btn-danger btn-delete-selected d-none">
                                                        <i class="fa fa-times"></i> Delete Selected
                                                    </button>
                                                    <div class="dropup export-btn-holder mx-1">
                                                        <button class="btn btn-sm btn-primary dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                            <i class="fa fa-save"></i> Export
                                                        </button>
                                                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                                            <?php $export_print_link = $this->set_current_page_link(array('format' => 'print')); ?>
                                                            <a class="dropdown-item export-link-btn" data-format="print" href="<?php print_link($export_print_link); ?>" target="_blank">
                                                                <img src="<?php print_link('assets/images/print.png') ?>" class="mr-2" /> PRINT
                                                                </a>
                                                                <?php $export_pdf_link = $this->set_current_page_link(array('format' => 'pdf')); ?>
                                                                <a class="dropdown-item export-link-btn" data-format="pdf" href="<?php print_link($export_pdf_link); ?>" target="_blank">
                                                                    <img src="<?php print_link('assets/images/pdf.png') ?>" class="mr-2" /> PDF
                                                                    </a>
                                                                    <?php $export_word_link = $this->set_current_page_link(array('format' => 'word')); ?>
                                                                    <a class="dropdown-item export-link-btn" data-format="word" href="<?php print_link($export_word_link); ?>" target="_blank">
                                                                        <img src="<?php print_link('assets/images/doc.png') ?>" class="mr-2" /> WORD
                                                                        </a>
                                                                        <?php $export_csv_link = $this->set_current_page_link(array('format' => 'csv')); ?>
                                                                        <a class="dropdown-item export-link-btn" data-format="csv" href="<?php print_link($export_csv_link); ?>" target="_blank">
                                                                            <img src="<?php print_link('assets/images/csv.png') ?>" class="mr-2" /> CSV
                                                                            </a>
                                                                            <?php $export_excel_link = $this->set_current_page_link(array('format' => 'excel')); ?>
                                                                            <a class="dropdown-item export-link-btn" data-format="excel" href="<?php print_link($export_excel_link); ?>" target="_blank">
                                                                                <img src="<?php print_link('assets/images/xsl.png') ?>" class="mr-2" /> EXCEL
                                                                                </a>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="col">   
                                                                    <?php
                                                                    if($show_pagination == true){
                                                                    $pager = new Pagination($total_records, $record_count);
                                                                    $pager->route = $this->route;
                                                                    $pager->show_page_count = true;
                                                                    $pager->show_record_count = true;
                                                                    $pager->show_page_limit =true;
                                                                    $pager->limit_count = $this->limit_count;
                                                                    $pager->show_page_number_list = true;
                                                                    $pager->pager_link_range=5;
                                                                    $pager->render();
                                                                    }
                                                                    ?>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <?php
                                                        }
                                                        ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </section>
