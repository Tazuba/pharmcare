<?php
$comp_model = new SharedController;
$page_element_id = "add-page-" . random_str();
$current_page = $this->set_current_page_link();
$csrf_token = Csrf::$token;
$show_header = $this->show_header;
$view_title = $this->view_title;
$redirect_to = $this->redirect_to;
?>
<section class="page" id="<?php echo $page_element_id; ?>" data-page-type="add"  data-display-type="" data-page-url="<?php print_link($current_page); ?>">
    <?php
    if( $show_header == true ){
    ?>
    <div  class="bg-light p-3 mb-3">
        <div class="container">
            <div class="row ">
                <div class="col ">
                    <h4 class="record-title">Add New Mp Langingpage</h4>
                </div>
            </div>
        </div>
    </div>
    <?php
    }
    ?>
    <div  class="">
        <div class="container">
            <div class="row ">
                <div class="col-md-7 comp-grid">
                    <?php $this :: display_page_errors(); ?>
                    <div  class="bg-light p-3 animated fadeIn page-content">
                        <form id="mp_langingpage-add-form" role="form" novalidate enctype="multipart/form-data" class="form page-form form-horizontal needs-validation" action="<?php print_link("mp_langingpage/add?csrf_token=$csrf_token") ?>" method="post">
                            <div>
                                <div class="form-group ">
                                    <div class="row">
                                        <div class="col-sm-4">
                                            <label class="control-label" for="companyname">Companyname <span class="text-danger">*</span></label>
                                        </div>
                                        <div class="col-sm-8">
                                            <div class="">
                                                <input id="ctrl-companyname"  value="<?php  echo $this->set_field_value('companyname',""); ?>" type="text" placeholder="Enter Companyname"  required="" name="companyname"  class="form-control " />
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group ">
                                        <div class="row">
                                            <div class="col-sm-4">
                                                <label class="control-label" for="companydescription">Companydescription <span class="text-danger">*</span></label>
                                            </div>
                                            <div class="col-sm-8">
                                                <div class="">
                                                    <input id="ctrl-companydescription"  value="<?php  echo $this->set_field_value('companydescription',""); ?>" type="text" placeholder="Enter Companydescription"  required="" name="companydescription"  class="form-control " />
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group ">
                                            <div class="row">
                                                <div class="col-sm-4">
                                                    <label class="control-label" for="companykeywords">Companykeywords <span class="text-danger">*</span></label>
                                                </div>
                                                <div class="col-sm-8">
                                                    <div class="">
                                                        <input id="ctrl-companykeywords"  value="<?php  echo $this->set_field_value('companykeywords',""); ?>" type="text" placeholder="Enter Companykeywords"  required="" name="companykeywords"  class="form-control " />
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="form-group ">
                                                <div class="row">
                                                    <div class="col-sm-4">
                                                        <label class="control-label" for="license_no">License No <span class="text-danger">*</span></label>
                                                    </div>
                                                    <div class="col-sm-8">
                                                        <div class="">
                                                            <input id="ctrl-license_no"  value="<?php  echo $this->set_field_value('license_no',""); ?>" type="text" placeholder="Enter License No"  required="" name="license_no"  class="form-control " />
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="form-group ">
                                                    <div class="row">
                                                        <div class="col-sm-4">
                                                            <label class="control-label" for="printer_enable">Printer Enable <span class="text-danger">*</span></label>
                                                        </div>
                                                        <div class="col-sm-8">
                                                            <div class="">
                                                                <input id="ctrl-printer_enable"  value="<?php  echo $this->set_field_value('printer_enable',""); ?>" type="text" placeholder="Enter Printer Enable"  required="" name="printer_enable"  class="form-control " />
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="form-group ">
                                                        <div class="row">
                                                            <div class="col-sm-4">
                                                                <label class="control-label" for="address">Address <span class="text-danger">*</span></label>
                                                            </div>
                                                            <div class="col-sm-8">
                                                                <div class="">
                                                                    <input id="ctrl-address"  value="<?php  echo $this->set_field_value('address',""); ?>" type="text" placeholder="Enter Address"  required="" name="address"  class="form-control " />
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="form-group ">
                                                            <div class="row">
                                                                <div class="col-sm-4">
                                                                    <label class="control-label" for="email">Email <span class="text-danger">*</span></label>
                                                                </div>
                                                                <div class="col-sm-8">
                                                                    <div class="">
                                                                        <input id="ctrl-email"  value="<?php  echo $this->set_field_value('email',""); ?>" type="email" placeholder="Enter Email"  required="" name="email"  class="form-control " />
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="form-group ">
                                                                <div class="row">
                                                                    <div class="col-sm-4">
                                                                        <label class="control-label" for="contact">Contact <span class="text-danger">*</span></label>
                                                                    </div>
                                                                    <div class="col-sm-8">
                                                                        <div class="">
                                                                            <input id="ctrl-contact"  value="<?php  echo $this->set_field_value('contact',""); ?>" type="text" placeholder="Enter Contact"  required="" name="contact"  class="form-control " />
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="form-group ">
                                                                    <div class="row">
                                                                        <div class="col-sm-4">
                                                                            <label class="control-label" for="logo">Logo <span class="text-danger">*</span></label>
                                                                        </div>
                                                                        <div class="col-sm-8">
                                                                            <div class="">
                                                                                <input id="ctrl-logo"  value="<?php  echo $this->set_field_value('logo',""); ?>" type="text" placeholder="Enter Logo"  required="" name="logo"  class="form-control " />
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="form-group ">
                                                                        <div class="row">
                                                                            <div class="col-sm-4">
                                                                                <label class="control-label" for="left_icon">Left Icon <span class="text-danger">*</span></label>
                                                                            </div>
                                                                            <div class="col-sm-8">
                                                                                <div class="">
                                                                                    <input id="ctrl-left_icon"  value="<?php  echo $this->set_field_value('left_icon',""); ?>" type="text" placeholder="Enter Left Icon"  required="" name="left_icon"  class="form-control " />
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="form-group ">
                                                                            <div class="row">
                                                                                <div class="col-sm-4">
                                                                                    <label class="control-label" for="right_icon">Right Icon <span class="text-danger">*</span></label>
                                                                                </div>
                                                                                <div class="col-sm-8">
                                                                                    <div class="">
                                                                                        <input id="ctrl-right_icon"  value="<?php  echo $this->set_field_value('right_icon',""); ?>" type="text" placeholder="Enter Right Icon"  required="" name="right_icon"  class="form-control " />
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div class="form-group ">
                                                                                <div class="row">
                                                                                    <div class="col-sm-4">
                                                                                        <label class="control-label" for="banner">Banner <span class="text-danger">*</span></label>
                                                                                    </div>
                                                                                    <div class="col-sm-8">
                                                                                        <div class="">
                                                                                            <input id="ctrl-banner"  value="<?php  echo $this->set_field_value('banner',""); ?>" type="text" placeholder="Enter Banner"  required="" name="banner"  class="form-control " />
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="form-group ">
                                                                                    <div class="row">
                                                                                        <div class="col-sm-4">
                                                                                            <label class="control-label" for="slider1">Slider1 <span class="text-danger">*</span></label>
                                                                                        </div>
                                                                                        <div class="col-sm-8">
                                                                                            <div class="">
                                                                                                <input id="ctrl-slider1"  value="<?php  echo $this->set_field_value('slider1',""); ?>" type="text" placeholder="Enter Slider1"  required="" name="slider1"  class="form-control " />
                                                                                                </div>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="form-group ">
                                                                                        <div class="row">
                                                                                            <div class="col-sm-4">
                                                                                                <label class="control-label" for="slider2">Slider2 <span class="text-danger">*</span></label>
                                                                                            </div>
                                                                                            <div class="col-sm-8">
                                                                                                <div class="">
                                                                                                    <input id="ctrl-slider2"  value="<?php  echo $this->set_field_value('slider2',""); ?>" type="text" placeholder="Enter Slider2"  required="" name="slider2"  class="form-control " />
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </div>
                                                                                        <div class="form-group ">
                                                                                            <div class="row">
                                                                                                <div class="col-sm-4">
                                                                                                    <label class="control-label" for="slider3">Slider3 <span class="text-danger">*</span></label>
                                                                                                </div>
                                                                                                <div class="col-sm-8">
                                                                                                    <div class="">
                                                                                                        <input id="ctrl-slider3"  value="<?php  echo $this->set_field_value('slider3',""); ?>" type="text" placeholder="Enter Slider3"  required="" name="slider3"  class="form-control " />
                                                                                                        </div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                            <div class="form-group ">
                                                                                                <div class="row">
                                                                                                    <div class="col-sm-4">
                                                                                                        <label class="control-label" for="slider4">Slider4 <span class="text-danger">*</span></label>
                                                                                                    </div>
                                                                                                    <div class="col-sm-8">
                                                                                                        <div class="">
                                                                                                            <input id="ctrl-slider4"  value="<?php  echo $this->set_field_value('slider4',""); ?>" type="text" placeholder="Enter Slider4"  required="" name="slider4"  class="form-control " />
                                                                                                            </div>
                                                                                                        </div>
                                                                                                    </div>
                                                                                                </div>
                                                                                                <div class="form-group ">
                                                                                                    <div class="row">
                                                                                                        <div class="col-sm-4">
                                                                                                            <label class="control-label" for="slider5">Slider5 <span class="text-danger">*</span></label>
                                                                                                        </div>
                                                                                                        <div class="col-sm-8">
                                                                                                            <div class="">
                                                                                                                <input id="ctrl-slider5"  value="<?php  echo $this->set_field_value('slider5',""); ?>" type="text" placeholder="Enter Slider5"  required="" name="slider5"  class="form-control " />
                                                                                                                </div>
                                                                                                            </div>
                                                                                                        </div>
                                                                                                    </div>
                                                                                                    <div class="form-group ">
                                                                                                        <div class="row">
                                                                                                            <div class="col-sm-4">
                                                                                                                <label class="control-label" for="title1">Title1 <span class="text-danger">*</span></label>
                                                                                                            </div>
                                                                                                            <div class="col-sm-8">
                                                                                                                <div class="">
                                                                                                                    <input id="ctrl-title1"  value="<?php  echo $this->set_field_value('title1',""); ?>" type="text" placeholder="Enter Title1"  required="" name="title1"  class="form-control " />
                                                                                                                    </div>
                                                                                                                </div>
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="form-group ">
                                                                                                            <div class="row">
                                                                                                                <div class="col-sm-4">
                                                                                                                    <label class="control-label" for="title2">Title2 <span class="text-danger">*</span></label>
                                                                                                                </div>
                                                                                                                <div class="col-sm-8">
                                                                                                                    <div class="">
                                                                                                                        <input id="ctrl-title2"  value="<?php  echo $this->set_field_value('title2',""); ?>" type="text" placeholder="Enter Title2"  required="" name="title2"  class="form-control " />
                                                                                                                        </div>
                                                                                                                    </div>
                                                                                                                </div>
                                                                                                            </div>
                                                                                                            <div class="form-group ">
                                                                                                                <div class="row">
                                                                                                                    <div class="col-sm-4">
                                                                                                                        <label class="control-label" for="title3">Title3 <span class="text-danger">*</span></label>
                                                                                                                    </div>
                                                                                                                    <div class="col-sm-8">
                                                                                                                        <div class="">
                                                                                                                            <input id="ctrl-title3"  value="<?php  echo $this->set_field_value('title3',""); ?>" type="text" placeholder="Enter Title3"  required="" name="title3"  class="form-control " />
                                                                                                                            </div>
                                                                                                                        </div>
                                                                                                                    </div>
                                                                                                                </div>
                                                                                                                <div class="form-group ">
                                                                                                                    <div class="row">
                                                                                                                        <div class="col-sm-4">
                                                                                                                            <label class="control-label" for="title4">Title4 <span class="text-danger">*</span></label>
                                                                                                                        </div>
                                                                                                                        <div class="col-sm-8">
                                                                                                                            <div class="">
                                                                                                                                <input id="ctrl-title4"  value="<?php  echo $this->set_field_value('title4',""); ?>" type="text" placeholder="Enter Title4"  required="" name="title4"  class="form-control " />
                                                                                                                                </div>
                                                                                                                            </div>
                                                                                                                        </div>
                                                                                                                    </div>
                                                                                                                    <div class="form-group ">
                                                                                                                        <div class="row">
                                                                                                                            <div class="col-sm-4">
                                                                                                                                <label class="control-label" for="title5">Title5 <span class="text-danger">*</span></label>
                                                                                                                            </div>
                                                                                                                            <div class="col-sm-8">
                                                                                                                                <div class="">
                                                                                                                                    <input id="ctrl-title5"  value="<?php  echo $this->set_field_value('title5',""); ?>" type="text" placeholder="Enter Title5"  required="" name="title5"  class="form-control " />
                                                                                                                                    </div>
                                                                                                                                </div>
                                                                                                                            </div>
                                                                                                                        </div>
                                                                                                                        <div class="form-group ">
                                                                                                                            <div class="row">
                                                                                                                                <div class="col-sm-4">
                                                                                                                                    <label class="control-label" for="title6">Title6 <span class="text-danger">*</span></label>
                                                                                                                                </div>
                                                                                                                                <div class="col-sm-8">
                                                                                                                                    <div class="">
                                                                                                                                        <input id="ctrl-title6"  value="<?php  echo $this->set_field_value('title6',""); ?>" type="text" placeholder="Enter Title6"  required="" name="title6"  class="form-control " />
                                                                                                                                        </div>
                                                                                                                                    </div>
                                                                                                                                </div>
                                                                                                                            </div>
                                                                                                                            <div class="form-group ">
                                                                                                                                <div class="row">
                                                                                                                                    <div class="col-sm-4">
                                                                                                                                        <label class="control-label" for="subtitle6">Subtitle6 <span class="text-danger">*</span></label>
                                                                                                                                    </div>
                                                                                                                                    <div class="col-sm-8">
                                                                                                                                        <div class="">
                                                                                                                                            <input id="ctrl-subtitle6"  value="<?php  echo $this->set_field_value('subtitle6',""); ?>" type="text" placeholder="Enter Subtitle6"  required="" name="subtitle6"  class="form-control " />
                                                                                                                                            </div>
                                                                                                                                        </div>
                                                                                                                                    </div>
                                                                                                                                </div>
                                                                                                                                <div class="form-group ">
                                                                                                                                    <div class="row">
                                                                                                                                        <div class="col-sm-4">
                                                                                                                                            <label class="control-label" for="subtitle6one">Subtitle6one <span class="text-danger">*</span></label>
                                                                                                                                        </div>
                                                                                                                                        <div class="col-sm-8">
                                                                                                                                            <div class="">
                                                                                                                                                <input id="ctrl-subtitle6one"  value="<?php  echo $this->set_field_value('subtitle6one',""); ?>" type="text" placeholder="Enter Subtitle6one"  required="" name="subtitle6one"  class="form-control " />
                                                                                                                                                </div>
                                                                                                                                            </div>
                                                                                                                                        </div>
                                                                                                                                    </div>
                                                                                                                                    <div class="form-group ">
                                                                                                                                        <div class="row">
                                                                                                                                            <div class="col-sm-4">
                                                                                                                                                <label class="control-label" for="title8">Title8 <span class="text-danger">*</span></label>
                                                                                                                                            </div>
                                                                                                                                            <div class="col-sm-8">
                                                                                                                                                <div class="">
                                                                                                                                                    <input id="ctrl-title8"  value="<?php  echo $this->set_field_value('title8',""); ?>" type="text" placeholder="Enter Title8"  required="" name="title8"  class="form-control " />
                                                                                                                                                    </div>
                                                                                                                                                </div>
                                                                                                                                            </div>
                                                                                                                                        </div>
                                                                                                                                        <div class="form-group ">
                                                                                                                                            <div class="row">
                                                                                                                                                <div class="col-sm-4">
                                                                                                                                                    <label class="control-label" for="title9">Title9 <span class="text-danger">*</span></label>
                                                                                                                                                </div>
                                                                                                                                                <div class="col-sm-8">
                                                                                                                                                    <div class="">
                                                                                                                                                        <input id="ctrl-title9"  value="<?php  echo $this->set_field_value('title9',""); ?>" type="text" placeholder="Enter Title9"  required="" name="title9"  class="form-control " />
                                                                                                                                                        </div>
                                                                                                                                                    </div>
                                                                                                                                                </div>
                                                                                                                                            </div>
                                                                                                                                            <div class="form-group ">
                                                                                                                                                <div class="row">
                                                                                                                                                    <div class="col-sm-4">
                                                                                                                                                        <label class="control-label" for="title10">Title10 <span class="text-danger">*</span></label>
                                                                                                                                                    </div>
                                                                                                                                                    <div class="col-sm-8">
                                                                                                                                                        <div class="">
                                                                                                                                                            <input id="ctrl-title10"  value="<?php  echo $this->set_field_value('title10',""); ?>" type="text" placeholder="Enter Title10"  required="" name="title10"  class="form-control " />
                                                                                                                                                            </div>
                                                                                                                                                        </div>
                                                                                                                                                    </div>
                                                                                                                                                </div>
                                                                                                                                                <div class="form-group ">
                                                                                                                                                    <div class="row">
                                                                                                                                                        <div class="col-sm-4">
                                                                                                                                                            <label class="control-label" for="currency">Currency <span class="text-danger">*</span></label>
                                                                                                                                                        </div>
                                                                                                                                                        <div class="col-sm-8">
                                                                                                                                                            <div class="">
                                                                                                                                                                <input id="ctrl-currency"  value="<?php  echo $this->set_field_value('currency',""); ?>" type="text" placeholder="Enter Currency"  required="" name="currency"  class="form-control " />
                                                                                                                                                                </div>
                                                                                                                                                            </div>
                                                                                                                                                        </div>
                                                                                                                                                    </div>
                                                                                                                                                    <div class="form-group ">
                                                                                                                                                        <div class="row">
                                                                                                                                                            <div class="col-sm-4">
                                                                                                                                                                <label class="control-label" for="decimal_points">Decimal Points <span class="text-danger">*</span></label>
                                                                                                                                                            </div>
                                                                                                                                                            <div class="col-sm-8">
                                                                                                                                                                <div class="">
                                                                                                                                                                    <input id="ctrl-decimal_points"  value="<?php  echo $this->set_field_value('decimal_points',""); ?>" type="number" placeholder="Enter Decimal Points" step="1"  required="" name="decimal_points"  class="form-control " />
                                                                                                                                                                    </div>
                                                                                                                                                                </div>
                                                                                                                                                            </div>
                                                                                                                                                        </div>
                                                                                                                                                        <div class="form-group ">
                                                                                                                                                            <div class="row">
                                                                                                                                                                <div class="col-sm-4">
                                                                                                                                                                    <label class="control-label" for="language">Language <span class="text-danger">*</span></label>
                                                                                                                                                                </div>
                                                                                                                                                                <div class="col-sm-8">
                                                                                                                                                                    <div class="">
                                                                                                                                                                        <input id="ctrl-language"  value="<?php  echo $this->set_field_value('language',""); ?>" type="text" placeholder="Enter Language"  required="" name="language"  class="form-control " />
                                                                                                                                                                        </div>
                                                                                                                                                                    </div>
                                                                                                                                                                </div>
                                                                                                                                                            </div>
                                                                                                                                                            <div class="form-group ">
                                                                                                                                                                <div class="row">
                                                                                                                                                                    <div class="col-sm-4">
                                                                                                                                                                        <label class="control-label" for="primarycolor">Primarycolor <span class="text-danger">*</span></label>
                                                                                                                                                                    </div>
                                                                                                                                                                    <div class="col-sm-8">
                                                                                                                                                                        <div class="">
                                                                                                                                                                            <input id="ctrl-primarycolor"  value="<?php  echo $this->set_field_value('primarycolor',""); ?>" type="text" placeholder="Enter Primarycolor"  required="" name="primarycolor"  class="form-control " />
                                                                                                                                                                            </div>
                                                                                                                                                                        </div>
                                                                                                                                                                    </div>
                                                                                                                                                                </div>
                                                                                                                                                                <div class="form-group ">
                                                                                                                                                                    <div class="row">
                                                                                                                                                                        <div class="col-sm-4">
                                                                                                                                                                            <label class="control-label" for="theme_pri_hover">Theme Pri Hover <span class="text-danger">*</span></label>
                                                                                                                                                                        </div>
                                                                                                                                                                        <div class="col-sm-8">
                                                                                                                                                                            <div class="">
                                                                                                                                                                                <input id="ctrl-theme_pri_hover"  value="<?php  echo $this->set_field_value('theme_pri_hover',""); ?>" type="text" placeholder="Enter Theme Pri Hover"  required="" name="theme_pri_hover"  class="form-control " />
                                                                                                                                                                                </div>
                                                                                                                                                                            </div>
                                                                                                                                                                        </div>
                                                                                                                                                                    </div>
                                                                                                                                                                    <div class="form-group ">
                                                                                                                                                                        <div class="row">
                                                                                                                                                                            <div class="col-sm-4">
                                                                                                                                                                                <label class="control-label" for="expirey">Expirey <span class="text-danger">*</span></label>
                                                                                                                                                                            </div>
                                                                                                                                                                            <div class="col-sm-8">
                                                                                                                                                                                <div class="">
                                                                                                                                                                                    <input id="ctrl-expirey"  value="<?php  echo $this->set_field_value('expirey',""); ?>" type="number" placeholder="Enter Expirey" step="1"  required="" name="expirey"  class="form-control " />
                                                                                                                                                                                    </div>
                                                                                                                                                                                </div>
                                                                                                                                                                            </div>
                                                                                                                                                                        </div>
                                                                                                                                                                        <div class="form-group ">
                                                                                                                                                                            <div class="row">
                                                                                                                                                                                <div class="col-sm-4">
                                                                                                                                                                                    <label class="control-label" for="startday">Startday <span class="text-danger">*</span></label>
                                                                                                                                                                                </div>
                                                                                                                                                                                <div class="col-sm-8">
                                                                                                                                                                                    <div class="">
                                                                                                                                                                                        <input id="ctrl-startday"  value="<?php  echo $this->set_field_value('startday',""); ?>" type="number" placeholder="Enter Startday" step="1"  required="" name="startday"  class="form-control " />
                                                                                                                                                                                        </div>
                                                                                                                                                                                    </div>
                                                                                                                                                                                </div>
                                                                                                                                                                            </div>
                                                                                                                                                                            <div class="form-group ">
                                                                                                                                                                                <div class="row">
                                                                                                                                                                                    <div class="col-sm-4">
                                                                                                                                                                                        <label class="control-label" for="startmonth">Startmonth <span class="text-danger">*</span></label>
                                                                                                                                                                                    </div>
                                                                                                                                                                                    <div class="col-sm-8">
                                                                                                                                                                                        <div class="">
                                                                                                                                                                                            <input id="ctrl-startmonth"  value="<?php  echo $this->set_field_value('startmonth',""); ?>" type="number" placeholder="Enter Startmonth" step="1"  required="" name="startmonth"  class="form-control " />
                                                                                                                                                                                            </div>
                                                                                                                                                                                        </div>
                                                                                                                                                                                    </div>
                                                                                                                                                                                </div>
                                                                                                                                                                                <div class="form-group ">
                                                                                                                                                                                    <div class="row">
                                                                                                                                                                                        <div class="col-sm-4">
                                                                                                                                                                                            <label class="control-label" for="endday">Endday <span class="text-danger">*</span></label>
                                                                                                                                                                                        </div>
                                                                                                                                                                                        <div class="col-sm-8">
                                                                                                                                                                                            <div class="">
                                                                                                                                                                                                <input id="ctrl-endday"  value="<?php  echo $this->set_field_value('endday',""); ?>" type="number" placeholder="Enter Endday" step="1"  required="" name="endday"  class="form-control " />
                                                                                                                                                                                                </div>
                                                                                                                                                                                            </div>
                                                                                                                                                                                        </div>
                                                                                                                                                                                    </div>
                                                                                                                                                                                    <div class="form-group ">
                                                                                                                                                                                        <div class="row">
                                                                                                                                                                                            <div class="col-sm-4">
                                                                                                                                                                                                <label class="control-label" for="endmonth">Endmonth <span class="text-danger">*</span></label>
                                                                                                                                                                                            </div>
                                                                                                                                                                                            <div class="col-sm-8">
                                                                                                                                                                                                <div class="">
                                                                                                                                                                                                    <input id="ctrl-endmonth"  value="<?php  echo $this->set_field_value('endmonth',""); ?>" type="number" placeholder="Enter Endmonth" step="1"  required="" name="endmonth"  class="form-control " />
                                                                                                                                                                                                    </div>
                                                                                                                                                                                                </div>
                                                                                                                                                                                            </div>
                                                                                                                                                                                        </div>
                                                                                                                                                                                        <div class="form-group ">
                                                                                                                                                                                            <div class="row">
                                                                                                                                                                                                <div class="col-sm-4">
                                                                                                                                                                                                    <label class="control-label" for="enable_sms">Enable Sms <span class="text-danger">*</span></label>
                                                                                                                                                                                                </div>
                                                                                                                                                                                                <div class="col-sm-8">
                                                                                                                                                                                                    <div class="">
                                                                                                                                                                                                        <input id="ctrl-enable_sms"  value="<?php  echo $this->set_field_value('enable_sms',""); ?>" type="text" placeholder="Enter Enable Sms"  required="" name="enable_sms"  class="form-control " />
                                                                                                                                                                                                        </div>
                                                                                                                                                                                                    </div>
                                                                                                                                                                                                </div>
                                                                                                                                                                                            </div>
                                                                                                                                                                                            <div class="form-group ">
                                                                                                                                                                                                <div class="row">
                                                                                                                                                                                                    <div class="col-sm-4">
                                                                                                                                                                                                        <label class="control-label" for="sms_domain_name">Sms Domain Name <span class="text-danger">*</span></label>
                                                                                                                                                                                                    </div>
                                                                                                                                                                                                    <div class="col-sm-8">
                                                                                                                                                                                                        <div class="">
                                                                                                                                                                                                            <input id="ctrl-sms_domain_name"  value="<?php  echo $this->set_field_value('sms_domain_name',""); ?>" type="text" placeholder="Enter Sms Domain Name"  required="" name="sms_domain_name"  class="form-control " />
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                        </div>
                                                                                                                                                                                                    </div>
                                                                                                                                                                                                </div>
                                                                                                                                                                                                <div class="form-group ">
                                                                                                                                                                                                    <div class="row">
                                                                                                                                                                                                        <div class="col-sm-4">
                                                                                                                                                                                                            <label class="control-label" for="sms_email_id">Sms Email Id <span class="text-danger">*</span></label>
                                                                                                                                                                                                        </div>
                                                                                                                                                                                                        <div class="col-sm-8">
                                                                                                                                                                                                            <div class="">
                                                                                                                                                                                                                <input id="ctrl-sms_email_id"  value="<?php  echo $this->set_field_value('sms_email_id',""); ?>" type="email" placeholder="Enter Sms Email Id"  required="" name="sms_email_id"  class="form-control " />
                                                                                                                                                                                                                </div>
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                        </div>
                                                                                                                                                                                                    </div>
                                                                                                                                                                                                    <div class="form-group ">
                                                                                                                                                                                                        <div class="row">
                                                                                                                                                                                                            <div class="col-sm-4">
                                                                                                                                                                                                                <label class="control-label" for="sms_token_key">Sms Token Key <span class="text-danger">*</span></label>
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            <div class="col-sm-8">
                                                                                                                                                                                                                <div class="">
                                                                                                                                                                                                                    <input id="ctrl-sms_token_key"  value="<?php  echo $this->set_field_value('sms_token_key',""); ?>" type="text" placeholder="Enter Sms Token Key"  required="" name="sms_token_key"  class="form-control " />
                                                                                                                                                                                                                    </div>
                                                                                                                                                                                                                </div>
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                        </div>
                                                                                                                                                                                                        <div class="form-group ">
                                                                                                                                                                                                            <div class="row">
                                                                                                                                                                                                                <div class="col-sm-4">
                                                                                                                                                                                                                    <label class="control-label" for="sms_mobile_number">Sms Mobile Number <span class="text-danger">*</span></label>
                                                                                                                                                                                                                </div>
                                                                                                                                                                                                                <div class="col-sm-8">
                                                                                                                                                                                                                    <div class="">
                                                                                                                                                                                                                        <input id="ctrl-sms_mobile_number"  value="<?php  echo $this->set_field_value('sms_mobile_number',""); ?>" type="text" placeholder="Enter Sms Mobile Number"  required="" name="sms_mobile_number"  class="form-control " />
                                                                                                                                                                                                                        </div>
                                                                                                                                                                                                                    </div>
                                                                                                                                                                                                                </div>
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            <div class="form-group ">
                                                                                                                                                                                                                <div class="row">
                                                                                                                                                                                                                    <div class="col-sm-4">
                                                                                                                                                                                                                        <label class="control-label" for="enable_email">Enable Email <span class="text-danger">*</span></label>
                                                                                                                                                                                                                    </div>
                                                                                                                                                                                                                    <div class="col-sm-8">
                                                                                                                                                                                                                        <div class="">
                                                                                                                                                                                                                            <input id="ctrl-enable_email"  value="<?php  echo $this->set_field_value('enable_email',""); ?>" type="email" placeholder="Enter Enable Email"  required="" name="enable_email"  class="form-control " />
                                                                                                                                                                                                                            </div>
                                                                                                                                                                                                                        </div>
                                                                                                                                                                                                                    </div>
                                                                                                                                                                                                                </div>
                                                                                                                                                                                                                <div class="form-group ">
                                                                                                                                                                                                                    <div class="row">
                                                                                                                                                                                                                        <div class="col-sm-4">
                                                                                                                                                                                                                            <label class="control-label" for="account_address">Account Address <span class="text-danger">*</span></label>
                                                                                                                                                                                                                        </div>
                                                                                                                                                                                                                        <div class="col-sm-8">
                                                                                                                                                                                                                            <div class="">
                                                                                                                                                                                                                                <input id="ctrl-account_address"  value="<?php  echo $this->set_field_value('account_address',""); ?>" type="text" placeholder="Enter Account Address"  required="" name="account_address"  class="form-control " />
                                                                                                                                                                                                                                </div>
                                                                                                                                                                                                                            </div>
                                                                                                                                                                                                                        </div>
                                                                                                                                                                                                                    </div>
                                                                                                                                                                                                                    <div class="form-group ">
                                                                                                                                                                                                                        <div class="row">
                                                                                                                                                                                                                            <div class="col-sm-4">
                                                                                                                                                                                                                                <label class="control-label" for="account_password">Account Password <span class="text-danger">*</span></label>
                                                                                                                                                                                                                            </div>
                                                                                                                                                                                                                            <div class="col-sm-8">
                                                                                                                                                                                                                                <div class="input-group">
                                                                                                                                                                                                                                    <input id="ctrl-account_password"  value="<?php  echo $this->set_field_value('account_password',""); ?>" type="password" placeholder="Enter Account Password"  required="" name="account_password"  class="form-control  password password-strength" />
                                                                                                                                                                                                                                        <div class="input-group-append cursor-pointer btn-toggle-password">
                                                                                                                                                                                                                                            <span class="input-group-text"><i class="fa fa-eye"></i></span>
                                                                                                                                                                                                                                        </div>
                                                                                                                                                                                                                                    </div>
                                                                                                                                                                                                                                    <div class="password-strength-msg">
                                                                                                                                                                                                                                        <small class="font-weight-bold">Should contain</small>
                                                                                                                                                                                                                                        <small class="length chip">6 Characters minimum</small>
                                                                                                                                                                                                                                        <small class="caps chip">Capital Letter</small>
                                                                                                                                                                                                                                        <small class="number chip">Number</small>
                                                                                                                                                                                                                                        <small class="special chip">Symbol</small>
                                                                                                                                                                                                                                    </div>
                                                                                                                                                                                                                                </div>
                                                                                                                                                                                                                            </div>
                                                                                                                                                                                                                        </div>
                                                                                                                                                                                                                        <div class="form-group ">
                                                                                                                                                                                                                            <div class="row">
                                                                                                                                                                                                                                <div class="col-sm-4">
                                                                                                                                                                                                                                    <label class="control-label" for="confirm_password">Confirm Password <span class="text-danger">*</span></label>
                                                                                                                                                                                                                                </div>
                                                                                                                                                                                                                                <div class="col-sm-8">
                                                                                                                                                                                                                                    <div class="input-group">
                                                                                                                                                                                                                                        <input id="ctrl-account_password-confirm" data-match="#ctrl-account_password"  class="form-control password-confirm " type="password" name="confirm_password" required placeholder="Confirm Password" />
                                                                                                                                                                                                                                        <div class="input-group-append cursor-pointer btn-toggle-password">
                                                                                                                                                                                                                                            <span class="input-group-text"><i class="fa fa-eye"></i></span>
                                                                                                                                                                                                                                        </div>
                                                                                                                                                                                                                                        <div class="invalid-feedback">
                                                                                                                                                                                                                                            Password does not match
                                                                                                                                                                                                                                        </div>
                                                                                                                                                                                                                                    </div>
                                                                                                                                                                                                                                </div>
                                                                                                                                                                                                                            </div>
                                                                                                                                                                                                                        </div>
                                                                                                                                                                                                                        <div class="form-group ">
                                                                                                                                                                                                                            <div class="row">
                                                                                                                                                                                                                                <div class="col-sm-4">
                                                                                                                                                                                                                                    <label class="control-label" for="email_host_port">Email Host Port <span class="text-danger">*</span></label>
                                                                                                                                                                                                                                </div>
                                                                                                                                                                                                                                <div class="col-sm-8">
                                                                                                                                                                                                                                    <div class="">
                                                                                                                                                                                                                                        <input id="ctrl-email_host_port"  value="<?php  echo $this->set_field_value('email_host_port',""); ?>" type="email" placeholder="Enter Email Host Port"  required="" name="email_host_port"  class="form-control " />
                                                                                                                                                                                                                                        </div>
                                                                                                                                                                                                                                    </div>
                                                                                                                                                                                                                                </div>
                                                                                                                                                                                                                            </div>
                                                                                                                                                                                                                            <div class="form-group ">
                                                                                                                                                                                                                                <div class="row">
                                                                                                                                                                                                                                    <div class="col-sm-4">
                                                                                                                                                                                                                                        <label class="control-label" for="email_host_server">Email Host Server <span class="text-danger">*</span></label>
                                                                                                                                                                                                                                    </div>
                                                                                                                                                                                                                                    <div class="col-sm-8">
                                                                                                                                                                                                                                        <div class="">
                                                                                                                                                                                                                                            <input id="ctrl-email_host_server"  value="<?php  echo $this->set_field_value('email_host_server',""); ?>" type="email" placeholder="Enter Email Host Server"  required="" name="email_host_server"  class="form-control " />
                                                                                                                                                                                                                                            </div>
                                                                                                                                                                                                                                        </div>
                                                                                                                                                                                                                                    </div>
                                                                                                                                                                                                                                </div>
                                                                                                                                                                                                                                <div class="form-group ">
                                                                                                                                                                                                                                    <div class="row">
                                                                                                                                                                                                                                        <div class="col-sm-4">
                                                                                                                                                                                                                                            <label class="control-label" for="receipt_labels">Receipt Labels <span class="text-danger">*</span></label>
                                                                                                                                                                                                                                        </div>
                                                                                                                                                                                                                                        <div class="col-sm-8">
                                                                                                                                                                                                                                            <div class="">
                                                                                                                                                                                                                                                <textarea placeholder="Enter Receipt Labels" id="ctrl-receipt_labels"  required="" rows="5" name="receipt_labels" class=" form-control"><?php  echo $this->set_field_value('receipt_labels',""); ?></textarea>
                                                                                                                                                                                                                                                <!--<div class="invalid-feedback animated bounceIn text-center">Please enter text</div>-->
                                                                                                                                                                                                                                            </div>
                                                                                                                                                                                                                                        </div>
                                                                                                                                                                                                                                    </div>
                                                                                                                                                                                                                                </div>
                                                                                                                                                                                                                            </div>
                                                                                                                                                                                                                            <div class="form-group form-submit-btn-holder text-center mt-3">
                                                                                                                                                                                                                                <div class="form-ajax-status"></div>
                                                                                                                                                                                                                                <button class="btn btn-primary" type="submit">
                                                                                                                                                                                                                                    Submit
                                                                                                                                                                                                                                    <i class="fa fa-send"></i>
                                                                                                                                                                                                                                </button>
                                                                                                                                                                                                                            </div>
                                                                                                                                                                                                                        </form>
                                                                                                                                                                                                                    </div>
                                                                                                                                                                                                                </div>
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                        </div>
                                                                                                                                                                                                    </div>
                                                                                                                                                                                                </section>
