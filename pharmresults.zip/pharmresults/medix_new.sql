-- Adminer 4.8.0 MySQL 5.5.5-10.4.21-MariaDB dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

DROP TABLE IF EXISTS `mp_banks`;
CREATE TABLE `mp_banks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bankname` varchar(255) NOT NULL,
  `branch` varchar(100) NOT NULL,
  `branchcode` varchar(100) NOT NULL,
  `title` varchar(100) NOT NULL,
  `accountno` varchar(100) NOT NULL,
  `status` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `mp_bank_opening`;
CREATE TABLE `mp_bank_opening` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date_created` date NOT NULL,
  `bank_id` int(11) NOT NULL,
  `amount` decimal(11,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `bank_id` (`bank_id`),
  CONSTRAINT `opening_bank_id` FOREIGN KEY (`bank_id`) REFERENCES `mp_banks` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `mp_bank_transaction`;
CREATE TABLE `mp_bank_transaction` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `transaction_id` int(11) NOT NULL,
  `bank_id` int(11) NOT NULL,
  `method` varchar(50) NOT NULL,
  `total_bill` decimal(11,2) NOT NULL,
  `ref_no` varchar(100) NOT NULL,
  `transaction_status` int(1) NOT NULL,
  `transaction_type` varchar(50) NOT NULL,
  `cleared_date` date NOT NULL,
  `total_paid` decimal(11,2) NOT NULL,
  `attachment` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `transaction_id` (`transaction_id`),
  KEY `bank_id` (`bank_id`),
  CONSTRAINT `bankid_bank_fk` FOREIGN KEY (`bank_id`) REFERENCES `mp_banks` (`id`),
  CONSTRAINT `transaction_general_fk` FOREIGN KEY (`transaction_id`) REFERENCES `mp_generalentry` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `mp_bank_transaction_payee`;
CREATE TABLE `mp_bank_transaction_payee` (
  `tran_id` int(11) NOT NULL AUTO_INCREMENT,
  `transaction_id` int(11) NOT NULL,
  `payee_id` int(11) NOT NULL,
  PRIMARY KEY (`tran_id`),
  KEY `transaction_id` (`transaction_id`),
  KEY `payee_id` (`payee_id`),
  CONSTRAINT `bank_general_transaction_fk` FOREIGN KEY (`transaction_id`) REFERENCES `mp_generalentry` (`id`),
  CONSTRAINT `payee_bank_fk` FOREIGN KEY (`payee_id`) REFERENCES `mp_payee` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `mp_barcode`;
CREATE TABLE `mp_barcode` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `barcode` varchar(255) NOT NULL,
  `random_no` varchar(255) NOT NULL,
  `description` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `mp_brand`;
CREATE TABLE `mp_brand` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `company_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `company_id` (`company_id`),
  CONSTRAINT `brand_company_fk` FOREIGN KEY (`company_id`) REFERENCES `mp_payee` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `mp_brand` (`id`, `name`, `company_id`) VALUES
(1,	'Meggi',	1);

DROP TABLE IF EXISTS `mp_brand_sector`;
CREATE TABLE `mp_brand_sector` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sector` varchar(255) NOT NULL,
  `created` date NOT NULL,
  `updated` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `mp_brand_sector` (`id`, `sector`, `created`, `updated`) VALUES
(1,	'Chocolates',	'2020-08-31',	'2020-08-31'),
(2,	'Chocolates',	'2020-08-31',	'2020-08-31'),
(3,	'AmoxICILIN',	'2022-05-31',	'2022-05-31');

DROP TABLE IF EXISTS `mp_category`;
CREATE TABLE `mp_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_name` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `register_date` date NOT NULL,
  `status` int(1) NOT NULL,
  `added_by` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `id_2` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `mp_category` (`id`, `category_name`, `description`, `register_date`, `status`, `added_by`) VALUES
(1,	'Hard',	'Any Description:',	'2020-08-31',	0,	'Admin');

DROP TABLE IF EXISTS `mp_contactabout`;
CREATE TABLE `mp_contactabout` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `contact_title` varchar(255) NOT NULL,
  `contact_description` varchar(255) NOT NULL,
  `phone_number` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `facebook` varchar(255) NOT NULL,
  `twitter` varchar(255) NOT NULL,
  `linked` varchar(255) NOT NULL,
  `googleplus` varchar(255) NOT NULL,
  `about_title` varchar(255) NOT NULL,
  `about_quotation` varchar(255) NOT NULL,
  `about_name` varchar(255) NOT NULL,
  `about_title2` varchar(255) NOT NULL,
  `about_description` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `mp_contactabout` (`id`, `contact_title`, `contact_description`, `phone_number`, `address`, `email`, `facebook`, `twitter`, `linked`, `googleplus`, `about_title`, `about_quotation`, `about_name`, `about_title2`, `about_description`) VALUES
(1,	'Contact Us',	'Lorum Ipsum dolar sit ami ',	'+1 800 123 1234',	'21th Street North way Commerical Market Mohenjo Daro',	'info@gbdevelopers.net',	'http://www.facebook.com/ali.i.roshan',	'ali.i.roshan',	'ali.i.roshan',	'ali.i.roshan',	'« Lorem Ipsum is simply dummy text of the printing  »',	'Lorem Ipsum is simply dummy text of the printing and typesetting industry.p;#039;s standard dummy text ever since the 1500s, when an unknown printer took a ga',	'— Medix Pharmacy',	'About Us',	'Praesent convallis tortor et enim laoreet, vel consectetur purus latoque penatibus et dis parturient.');

DROP TABLE IF EXISTS `mp_drivers`;
CREATE TABLE `mp_drivers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `contact` varchar(15) NOT NULL,
  `address` varchar(255) NOT NULL,
  `lisence` varchar(255) NOT NULL,
  `ref` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `cus_picture` varchar(255) NOT NULL,
  `status` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `mp_drivers` (`id`, `name`, `contact`, `address`, `lisence`, `ref`, `date`, `cus_picture`, `status`) VALUES
(1,	'No Driver',	'123456',	'',	'',	'',	'0000-00-00',	'default.jpg',	0);

DROP TABLE IF EXISTS `mp_estimate`;
CREATE TABLE `mp_estimate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `total_bill` decimal(11,2) NOT NULL,
  `total_discount` decimal(11,2) NOT NULL,
  `total_tax` decimal(11,2) NOT NULL,
  `gross_total` decimal(11,2) NOT NULL,
  `date` date NOT NULL,
  `expire_date` date NOT NULL,
  `user` varchar(255) NOT NULL,
  `memo` longtext NOT NULL,
  `payee_id` int(11) NOT NULL,
  `billing` varchar(255) NOT NULL,
  `invoicemessage` varchar(255) NOT NULL,
  `status` int(1) NOT NULL,
  `parent_tax_name` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `payee_id` (`payee_id`),
  CONSTRAINT `estimate_payee_fk` FOREIGN KEY (`payee_id`) REFERENCES `mp_payee` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `mp_estimate_sales`;
CREATE TABLE `mp_estimate_sales` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `estimate_id` int(11) NOT NULL,
  `product_id` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `qty` int(11) NOT NULL,
  `price` decimal(11,2) NOT NULL,
  `discount` decimal(11,2) NOT NULL,
  `subtotal` decimal(11,2) NOT NULL,
  `tax` longtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `invoice_id` (`estimate_id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `estimate_parent_id` FOREIGN KEY (`estimate_id`) REFERENCES `mp_estimate` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `mp_expense`;
CREATE TABLE `mp_expense` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `transaction_id` int(11) NOT NULL,
  `total_bill` decimal(11,2) NOT NULL,
  `total_paid` decimal(11,2) NOT NULL,
  `date` date NOT NULL,
  `in_time` time NOT NULL,
  `user` varchar(255) NOT NULL,
  `method` varchar(50) NOT NULL,
  `description` longtext NOT NULL,
  `payee_id` int(11) NOT NULL,
  `ref_no` varchar(255) NOT NULL,
  `attachment` varchar(255) NOT NULL,
  `total_discount` decimal(11,2) NOT NULL,
  `gross_total` decimal(11,2) NOT NULL,
  `total_tax` decimal(11,2) NOT NULL,
  `parent_tax_name` varchar(50) NOT NULL,
  `expense_type` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `transaction_id` (`transaction_id`),
  KEY `payee_id` (`payee_id`),
  CONSTRAINT `general_expense_fk` FOREIGN KEY (`transaction_id`) REFERENCES `mp_generalentry` (`id`),
  CONSTRAINT `payee_expense_fk` FOREIGN KEY (`payee_id`) REFERENCES `mp_payee` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `mp_generalentry`;
CREATE TABLE `mp_generalentry` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `naration` varchar(255) NOT NULL,
  `generated_source` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `mp_generalentry` (`id`, `date`, `naration`, `generated_source`) VALUES
(1,	'2021-08-02',	'Transaction occurred from create purchases',	'create_purchases'),
(2,	'2021-08-02',	'Transaction occurred from POS',	'pos'),
(3,	'2021-08-02',	'Transaction occurred from POS',	'pos'),
(4,	'2021-08-02',	'Transaction occurred from POS',	'pos'),
(5,	'2021-08-02',	'Transaction occurred from POS',	'pos'),
(6,	'2021-08-02',	'Transaction occurred from supply POS',	'pos'),
(7,	'2022-06-02',	'Transaction occurred from POS',	'pos'),
(8,	'2022-06-02',	'Transaction occurred from supply POS',	'pos'),
(9,	'2022-06-04',	'Transaction occurred from POS',	'pos');

DROP TABLE IF EXISTS `mp_head`;
CREATE TABLE `mp_head` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `nature` varchar(50) NOT NULL,
  `type` varchar(50) NOT NULL,
  `relation_id` int(11) NOT NULL,
  `expense_type` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `mp_head` (`id`, `name`, `nature`, `type`, `relation_id`, `expense_type`) VALUES
(1,	'Salary',	'Expense',	'Current',	0,	'Cash Expense'),
(2,	'Cash',	'Assets',	'Non-Current',	0,	'Non-Cash Expense'),
(3,	'Inventory',	'Assets',	'Current',	0,	'-'),
(4,	'Accounts receivable',	'Assets',	'Current',	0,	'-'),
(5,	'Accounts payable',	'Libility',	'Current',	0,	'Cash Expense'),
(6,	'Telephone Expense',	'Expense',	'Current',	0,	'-'),
(7,	'CapitalStock',	'Equity',	'Current',	0,	'-'),
(8,	'Land',	'Assets',	'Non-Current',	0,	'-'),
(9,	'Building',	'Assets',	'Non-Current',	0,	'-'),
(10,	'Notes payable',	'Libility',	'Non-Current',	0,	'-'),
(11,	'Tools and Equipments',	'Assets',	'Current',	0,	'-'),
(12,	'Repair Service Revenue',	'Revenue',	'Current',	0,	'-'),
(13,	'Wages Expense',	'Expense',	'Current',	0,	'-'),
(14,	'Utitlity Expense',	'Expense',	'Current',	0,	'Cash Expense'),
(15,	'Adverstising Expense',	'Expense',	'Current',	0,	'-'),
(16,	'Cash in bank',	'Assets',	'Current',	0,	'-'),
(17,	'Collection fee',	'Expense',	'Current',	0,	'Bank Expense'),
(18,	'Cost of goods',	'Expense',	'Current',	0,	'Cash Expense'),
(19,	'Sales',	'Revenue',	'Current',	0,	'-'),
(20,	'Tax payable',	'Libility',	'Non-Current',	0,	'-'),
(21,	'General and Administration Expense',	'Expense',	'Current',	0,	'Cash Expense'),
(22,	'Internet Bill',	'Expense',	'Current',	0,	'Cash Expense'),
(23,	'Advance from Customer',	'Libility',	'Current',	0,	'-'),
(24,	'Sms Charges',	'Expense',	'Current',	0,	'Bank Expense'),
(25,	'Interest Earned',	'Revenue',	'Current',	0,	'-');

DROP TABLE IF EXISTS `mp_invoices`;
CREATE TABLE `mp_invoices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `transaction_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `in_time` time NOT NULL,
  `discount` decimal(11,2) NOT NULL,
  `status` varchar(50) NOT NULL,
  `description` varchar(255) NOT NULL,
  `agentname` varchar(100) NOT NULL,
  `cus_id` int(11) NOT NULL,
  `cus_picture` varchar(255) NOT NULL,
  `delivered_to` varchar(100) NOT NULL,
  `delivered_by` varchar(100) NOT NULL,
  `delivered_date` date NOT NULL,
  `delivered_description` varchar(255) NOT NULL,
  `shippingcharges` decimal(11,2) NOT NULL,
  `prescription_id` int(11) NOT NULL,
  `region_id` int(11) NOT NULL,
  `vehicle_id` int(11) NOT NULL,
  `driver_id` int(11) NOT NULL,
  `payment_method` int(1) NOT NULL,
  `total_gross_amt` decimal(11,2) NOT NULL,
  `total_bill` decimal(11,2) NOT NULL,
  `total_paid` decimal(11,2) NOT NULL,
  `source` int(1) NOT NULL,
  `store_id` int(11) NOT NULL,
  `sales_man_id` int(11) NOT NULL,
  `total_tax` decimal(11,2) NOT NULL,
  `doctor_details` longtext NOT NULL,
  `patient_details` longtext NOT NULL,
  `taxes_names` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `cus_id` (`cus_id`),
  KEY `prescription_id` (`prescription_id`),
  KEY `transaction_id` (`transaction_id`),
  KEY `store_id` (`store_id`),
  KEY `sales_man_id` (`sales_man_id`),
  KEY `invoice_driver_fk` (`driver_id`),
  KEY `invoice_region_fk` (`region_id`),
  KEY `invoice_vehicle_fk` (`vehicle_id`),
  CONSTRAINT `invoice_payee_fk` FOREIGN KEY (`cus_id`) REFERENCES `mp_payee` (`id`),
  CONSTRAINT `invoice_transaction_fk` FOREIGN KEY (`transaction_id`) REFERENCES `mp_generalentry` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `mp_invoices` (`id`, `transaction_id`, `date`, `in_time`, `discount`, `status`, `description`, `agentname`, `cus_id`, `cus_picture`, `delivered_to`, `delivered_by`, `delivered_date`, `delivered_description`, `shippingcharges`, `prescription_id`, `region_id`, `vehicle_id`, `driver_id`, `payment_method`, `total_gross_amt`, `total_bill`, `total_paid`, `source`, `store_id`, `sales_man_id`, `total_tax`, `doctor_details`, `patient_details`, `taxes_names`) VALUES
(1,	7,	'2022-06-02',	'14:33:25',	0.00,	'0',	'',	'Ken',	3,	'',	'',	'',	'0000-00-00',	'',	0.00,	0,	0,	0,	0,	0,	600000.00,	600000.00,	600000.00,	0,	0,	1,	0.00,	'',	'',	'Parent Tax'),
(2,	8,	'2022-06-02',	'14:38:29',	320000.00,	'0',	'',	'Ken',	3,	'',	'',	'',	'0000-00-00',	'',	0.00,	0,	1,	1,	1,	0,	4000000.00,	3680000.00,	3680000.00,	1,	2,	1,	0.00,	'',	'',	'Parent Tax'),
(3,	9,	'2022-06-04',	'16:18:58',	1600.00,	'0',	'',	'Ken',	3,	'',	'',	'',	'0000-00-00',	'',	0.00,	0,	0,	0,	0,	0,	20000.00,	18400.00,	18400.00,	0,	0,	1,	0.00,	'',	'',	'Parent Tax');

DROP TABLE IF EXISTS `mp_langingpage`;
CREATE TABLE `mp_langingpage` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `companyname` varchar(255) NOT NULL,
  `companydescription` varchar(255) NOT NULL,
  `companykeywords` varchar(255) NOT NULL,
  `license_no` varchar(255) NOT NULL,
  `printer_enable` varchar(20) NOT NULL,
  `address` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `contact` varchar(255) NOT NULL,
  `logo` varchar(255) NOT NULL,
  `left_icon` varchar(255) NOT NULL,
  `right_icon` varchar(255) NOT NULL,
  `banner` varchar(255) NOT NULL,
  `slider1` varchar(255) NOT NULL,
  `slider2` varchar(255) NOT NULL,
  `slider3` varchar(255) NOT NULL,
  `slider4` varchar(255) NOT NULL,
  `slider5` varchar(255) NOT NULL,
  `title1` varchar(255) NOT NULL,
  `title2` varchar(255) NOT NULL,
  `title3` varchar(255) NOT NULL,
  `title4` varchar(255) NOT NULL,
  `title5` varchar(255) NOT NULL,
  `title6` varchar(255) NOT NULL,
  `subtitle6` varchar(255) NOT NULL,
  `subtitle6one` varchar(255) NOT NULL,
  `title8` varchar(255) NOT NULL,
  `title9` varchar(255) NOT NULL,
  `title10` varchar(255) NOT NULL,
  `currency` varchar(10) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `decimal_points` int(2) NOT NULL,
  `language` varchar(50) NOT NULL,
  `primarycolor` varchar(50) NOT NULL,
  `theme_pri_hover` varchar(50) NOT NULL,
  `expirey` int(2) NOT NULL,
  `startday` int(2) NOT NULL,
  `startmonth` int(2) NOT NULL,
  `endday` int(2) NOT NULL,
  `endmonth` int(2) NOT NULL,
  `enable_sms` varchar(20) NOT NULL,
  `sms_domain_name` varchar(100) NOT NULL,
  `sms_email_id` varchar(50) NOT NULL,
  `sms_token_key` varchar(255) NOT NULL,
  `sms_mobile_number` varchar(20) NOT NULL,
  `enable_email` varchar(20) NOT NULL,
  `account_address` varchar(100) NOT NULL,
  `account_password` varchar(100) NOT NULL,
  `email_host_port` varchar(10) NOT NULL,
  `email_host_server` varchar(100) NOT NULL,
  `receipt_labels` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `mp_langingpage` (`id`, `companyname`, `companydescription`, `companykeywords`, `license_no`, `printer_enable`, `address`, `email`, `contact`, `logo`, `left_icon`, `right_icon`, `banner`, `slider1`, `slider2`, `slider3`, `slider4`, `slider5`, `title1`, `title2`, `title3`, `title4`, `title5`, `title6`, `subtitle6`, `subtitle6one`, `title8`, `title9`, `title10`, `currency`, `decimal_points`, `language`, `primarycolor`, `theme_pri_hover`, `expirey`, `startday`, `startmonth`, `endday`, `endmonth`, `enable_sms`, `sms_domain_name`, `sms_email_id`, `sms_token_key`, `sms_mobile_number`, `enable_email`, `account_address`, `account_password`, `email_host_port`, `email_host_server`, `receipt_labels`) VALUES
(1,	'Acholi Pride Medicines',	'Acholi Pride Medicines',	'Acholi Pride Medicines',	'1994 Subar Vivio',	'disable',	'2064  Circle Drive, Houston 77060',	'testing@spantiklab.com',	'832-514-352-9',	'8f911938d4045070bee3880f947a7ec0.png',	'5169636033ecf2efef95c188c40da783.png',	'49049576448786b2519e4169941daa6b.png',	'5036a0a87811ec91fe250e1a89b8eb5a.jpg',	'0ef31e5cb4de3258e4dbe684568afa79.png',	'37dce1f59be9b60fcb61b37c5d4696e2.jpg',	'f8204ab4a2dcc551cbecb34581f8520c.jpg',	'35a3127814e54bbccee737ec4188164c.jpg',	'9035bad363e32576af5b84b031c0c03c.jpg',	'THE  PHARMACY AND POS MANAGER v3.0',	'OUR SERVICES',	'THINGS YOU SHOULD KNOW ABOUT US',	'MEET OUR PHARMACIST!.',	'SEE WHAT PATIENTS ARE SAYING?.',	'CONTACT US.',	'Contact Info.',	'Having Any Query! Or Book an appointment.',	'Quick Links.',	'Follow us.',	'© Copyright Acholi Pride 2020- 2020  All Rights Reserved.',	'Shs',	2,	'EN',	'#4a6984',	'#1f5788',	5,	1,	3,	28,	2,	'disable',	'',	'',	'',	'',	'disable',	'',	'',	'587',	'',	'a:29:{s:7:\"product\";s:4:\"show\";s:7:\"generic\";N;s:5:\"brand\";N;s:6:\"sector\";N;s:8:\"batch_no\";N;s:8:\"category\";N;s:6:\"weight\";N;s:6:\"expiry\";N;s:6:\"number\";s:4:\"show\";s:4:\"date\";s:4:\"show\";s:8:\"salesman\";s:4:\"show\";s:4:\"mode\";s:4:\"show\";s:13:\"customer_name\";s:4:\"show\";s:10:\"cus_mobile\";s:4:\"show\";s:8:\"username\";s:4:\"show\";s:11:\"gross_total\";s:4:\"show\";s:14:\"total_discount\";s:4:\"show\";s:11:\"no_of_items\";s:4:\"show\";s:9:\"child_tax\";s:4:\"show\";s:10:\"parent_tax\";s:4:\"show\";s:11:\"doctor_info\";s:4:\"show\";s:12:\"patient_info\";s:4:\"show\";s:11:\"description\";s:4:\"show\";s:14:\"payment_method\";s:4:\"show\";s:7:\"tax_col\";s:4:\"show\";s:8:\"disc_col\";s:4:\"show\";s:9:\"left_icon\";s:4:\"show\";s:10:\"right_icon\";s:4:\"show\";s:14:\"senior_citizen\";s:4:\"show\";}');

DROP TABLE IF EXISTS `mp_orders`;
CREATE TABLE `mp_orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cus_id` int(11) NOT NULL,
  `cus_picture` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `amount` decimal(11,2) NOT NULL,
  `discount` decimal(11,2) NOT NULL,
  `shippedcharges` decimal(11,2) NOT NULL,
  `status` int(1) NOT NULL,
  `shippinaddress` varchar(255) NOT NULL,
  `prescription_image` longtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `cus_id` (`cus_id`),
  CONSTRAINT `mp_orders_payee_fk` FOREIGN KEY (`cus_id`) REFERENCES `mp_payee` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `mp_payee`;
CREATE TABLE `mp_payee` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_name` varchar(50) NOT NULL,
  `cus_email` varchar(50) NOT NULL,
  `cus_password` varchar(255) NOT NULL,
  `cus_address` varchar(255) NOT NULL,
  `cus_contact_1` varchar(50) NOT NULL,
  `cus_contact_2` varchar(50) NOT NULL,
  `cus_company` varchar(50) NOT NULL,
  `cus_description` varchar(100) NOT NULL,
  `cus_picture` varchar(100) NOT NULL,
  `cus_status` int(1) NOT NULL,
  `cus_region` varchar(255) NOT NULL,
  `cus_town` varchar(255) NOT NULL,
  `cus_type` varchar(50) NOT NULL,
  `cus_balance` decimal(11,2) NOT NULL,
  `cus_date` date NOT NULL,
  `customer_nationalid` varchar(255) NOT NULL,
  `type` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `mp_payee` (`id`, `customer_name`, `cus_email`, `cus_password`, `cus_address`, `cus_contact_1`, `cus_contact_2`, `cus_company`, `cus_description`, `cus_picture`, `cus_status`, `cus_region`, `cus_town`, `cus_type`, `cus_balance`, `cus_date`, `customer_nationalid`, `type`) VALUES
(1,	'Medix',	'',	'',	'',	'',	'',	'',	'',	'default.jpg',	0,	'',	'',	'',	0.00,	'2021-08-02',	'',	''),
(2,	'user@medix.net',	'tazubac@gmail.com',	'b1b3773a05c0ed0176787a4f1574ff0075f7521e',	'',	'',	'',	'',	'',	'default.jpg',	0,	'',	'',	'',	0.00,	'0000-00-00',	'',	'customer'),
(3,	'Acholi Pride Medicine',	'info@acholipridemedicines.com',	'',	'00000000000000000',	'000000000000000',	'',	'',	'',	'default.jpg',	0,	'',	'',	'',	0.00,	'2022-05-31',	'0989000000',	'company'),
(4,	'Acholi Pride Medicine',	'info@acholipridemedicines.com',	'',	'',	'',	'000000',	'cure',	'',	'default.jpg',	0,	'kampala',	'',	'',	0.00,	'2022-06-02',	'78888888',	''),
(5,	'Acholi Pride Medicine',	'info@acholipridemedicines.com',	'',	'namulanda',	'00000000',	'000000',	'cure',	'all is the client',	'default.jpg',	0,	'kampala',	'jkk',	'',	0.00,	'2022-06-02',	'78888888',	''),
(6,	'Acholi Pride Medicine',	'info@acholipridemedicines.com',	'',	'namulanda',	'000000000',	'0000000',	'cure',	'all is the client',	'59fe3c8450d0613ff2346aacef410975.JPG',	0,	'sdfgvh',	'jkk',	'',	0.00,	'2022-06-02',	'00000000000000000000',	''),
(7,	'Acholi Pride Medicine',	'info@acholipridemedicines.com',	'',	'namulandaff',	'090909090',	'6666',	'vvvvvvvvvvvvv',	'ilkuyjhgfdwes',	'90a541b3c2b2aa4200929f4d4d0d7245.PNG',	0,	'vvvvvv',	'vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv',	'',	0.00,	'2022-06-02',	'45556677654',	''),
(8,	'Acholi Pride Medicine',	'info@acholipridemedicines.com',	'',	'namulanda',	'000000000',	'',	'',	'all is the client',	'c9bd7a4079450dc1df82a81b4d03dbd2.PNG',	0,	'',	'',	'',	0.00,	'2022-06-03',	'000',	'');

DROP TABLE IF EXISTS `mp_payment_voucher`;
CREATE TABLE `mp_payment_voucher` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `transaction_id` int(11) NOT NULL,
  `payee_id` int(11) NOT NULL,
  `receipt_date` date NOT NULL,
  `memo` varchar(255) NOT NULL,
  `total_bill` decimal(11,2) NOT NULL,
  `total_paid` decimal(11,2) NOT NULL,
  `user` varchar(50) NOT NULL,
  `type` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `transaction_id` (`transaction_id`),
  KEY `payee_id` (`payee_id`),
  CONSTRAINT `payment_transaction_fk` FOREIGN KEY (`transaction_id`) REFERENCES `mp_generalentry` (`id`),
  CONSTRAINT `pv_payee_id` FOREIGN KEY (`payee_id`) REFERENCES `mp_payee` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `mp_pharmacist`;
CREATE TABLE `mp_pharmacist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `post_title` varchar(255) NOT NULL,
  `description` longtext NOT NULL,
  `cus_picture` varchar(255) NOT NULL,
  `facebook` varchar(255) NOT NULL,
  `twitter` varchar(255) NOT NULL,
  `linked` varchar(255) NOT NULL,
  `googleplus` varchar(255) NOT NULL,
  `status` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `mp_pharmacist` (`id`, `name`, `post_title`, `description`, `cus_picture`, `facebook`, `twitter`, `linked`, `googleplus`, `status`) VALUES
(1,	'Dr Annie',	'Pharmicst',	'lorum ipsum dollar sit amit.',	'2ebb5234942384026af15473cb736626.jpg',	'https://www.facebook.com/',	'https://www.twitter.com/',	'https://www.linkedin.com/',	'https://www.googleplus.com/',	0),
(2,	'Dr Jhon',	'Pharmicst',	'lorum ipsum dollar sit amit.',	'bf94811cc67d3e69cd6d52b076739832.jpg',	'https://www.facebook.com/',	'https://www.twitter.com/',	'https://www.linkedin.com/',	'https://www.googleplus.com/',	0),
(3,	'Dr Sansa',	'Pharmicst',	'lorum ipsum dollar sit amit.',	'757c8d87a1ba87cb602723d62ce52727.jpg',	'https://www.facebook.com/',	'https://www.twitter.com/',	'https://www.linkedin.com/',	'https://www.googleplus.com/',	0),
(4,	'Dr Kashmala',	'Physician',	'lorum ipsum dollar sit amit.',	'4214cd0b4a27799ee4e8ebbb2975e91d.jpg',	'https://www.facebook.com/',	'https://www.twitter.com/',	'https://www.linkedin.com/',	'https://www.googleplus.com/',	0);

DROP TABLE IF EXISTS `mp_pre_salesman`;
CREATE TABLE `mp_pre_salesman` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `in_time` time NOT NULL,
  `discount` decimal(11,2) NOT NULL,
  `status` varchar(50) NOT NULL,
  `description` varchar(255) NOT NULL,
  `agentname` varchar(100) NOT NULL,
  `cus_id` int(11) NOT NULL,
  `cus_picture` varchar(255) NOT NULL,
  `delivered_to` varchar(100) NOT NULL,
  `delivered_by` varchar(100) NOT NULL,
  `delivered_date` date NOT NULL,
  `delivered_description` varchar(255) NOT NULL,
  `shippingcharges` decimal(11,2) NOT NULL,
  `prescription_id` int(11) NOT NULL,
  `region_id` int(11) NOT NULL,
  `vehicle_id` int(11) NOT NULL,
  `driver_id` int(11) NOT NULL,
  `payment_method` int(1) NOT NULL,
  `total_gross_amt` decimal(11,2) NOT NULL,
  `total_bill` decimal(11,2) NOT NULL,
  `total_paid` decimal(11,2) NOT NULL,
  `source` int(1) NOT NULL,
  `store_id` int(11) NOT NULL,
  `sales_man_id` int(11) NOT NULL,
  `total_tax` decimal(11,2) NOT NULL,
  `doctor_details` longtext NOT NULL,
  `patient_details` longtext NOT NULL,
  `taxes_names` varchar(255) NOT NULL,
  `cash` decimal(11,2) NOT NULL,
  `cheque_amount` decimal(11,2) NOT NULL,
  `credit_amount` decimal(11,2) NOT NULL,
  `schemes` varchar(255) NOT NULL,
  `bank_deposit` decimal(11,2) NOT NULL,
  `return_stock_val` decimal(11,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `cus_id` (`cus_id`),
  KEY `prescription_id` (`prescription_id`),
  KEY `store_id` (`store_id`),
  KEY `sales_man_id` (`sales_man_id`),
  KEY `invoice_driver_fk` (`driver_id`),
  KEY `invoice_region_fk` (`region_id`),
  KEY `invoice_vehicle_fk` (`vehicle_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `mp_printer`;
CREATE TABLE `mp_printer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `printer_name` varchar(255) NOT NULL,
  `fontsize` int(11) NOT NULL,
  `set_default` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `mp_printer` (`id`, `printer_name`, `fontsize`, `set_default`) VALUES
(6,	'Black Copper BC-85AC',	1,	1),
(7,	'asdasd',	2,	0);

DROP TABLE IF EXISTS `mp_product`;
CREATE TABLE `mp_product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_name` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `price` decimal(11,2) NOT NULL,
  `cost` decimal(11,2) NOT NULL,
  `head_id` int(11) NOT NULL,
  `type` int(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `head_id` (`head_id`),
  CONSTRAINT `product_head_fk` FOREIGN KEY (`head_id`) REFERENCES `mp_head` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `mp_product` (`id`, `product_name`, `description`, `price`, `cost`, `head_id`, `type`) VALUES
(1,	'Hosting',	'here goes description',	15.30,	0.00,	19,	0),
(2,	'Reventue',	'Description ',	20.00,	0.00,	12,	0);

DROP TABLE IF EXISTS `mp_productslist`;
CREATE TABLE `mp_productslist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `generic_name` varchar(255) NOT NULL,
  `mg` varchar(50) NOT NULL,
  `quantity` int(11) NOT NULL,
  `purchase` decimal(11,2) NOT NULL,
  `retail` decimal(11,2) NOT NULL,
  `expire` date NOT NULL,
  `manufacturing` date NOT NULL,
  `sideeffects` varchar(100) NOT NULL,
  `description` longtext NOT NULL,
  `barcode` varchar(255) NOT NULL,
  `min_stock` int(11) NOT NULL,
  `status` int(1) NOT NULL,
  `packsize` decimal(11,2) NOT NULL,
  `sku` varchar(255) NOT NULL,
  `location` varchar(255) NOT NULL,
  `tax` longtext NOT NULL,
  `type` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `brand_id` int(11) NOT NULL,
  `brand_sector_id` int(11) NOT NULL,
  `unit_type` varchar(50) NOT NULL,
  `net_weight` varchar(50) NOT NULL,
  `whole_sale` decimal(11,2) NOT NULL,
  `pack_cost` decimal(11,2) NOT NULL,
  `discount_percentage` decimal(11,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `mp_productslist` (`id`, `category_id`, `product_name`, `generic_name`, `mg`, `quantity`, `purchase`, `retail`, `expire`, `manufacturing`, `sideeffects`, `description`, `barcode`, `min_stock`, `status`, `packsize`, `sku`, `location`, `tax`, `type`, `image`, `brand_id`, `brand_sector_id`, `unit_type`, `net_weight`, `whole_sale`, `pack_cost`, `discount_percentage`) VALUES
(1,	1,	'Panadol',	'Paracetamol',	'10',	9000,	8900.00,	90000.00,	'2024-02-29',	'2022-06-19',	'nill',	'								',	'',	9,	1,	1000.00,	'PD123',	'',	'a:3:{i:0;a:4:{s:6:\"tax_id\";s:1:\"2\";s:14:\"tax_percentage\";s:1:\"0\";s:15:\"parent_tax_name\";s:10:\"Parent Tax\";s:14:\"child_tax_name\";s:11:\"Child Tax 1\";}i:1;a:4:{s:6:\"tax_id\";s:1:\"3\";s:14:\"tax_percentage\";s:1:\"0\";s:15:\"parent_tax_name\";s:10:\"Parent Tax\";s:14:\"child_tax_name\";s:11:\"Child Tax 2\";}i:2;a:4:{s:6:\"tax_id\";s:1:\"4\";s:14:\"tax_percentage\";s:1:\"0\";s:15:\"parent_tax_name\";s:10:\"Parent Tax\";s:14:\"child_tax_name\";s:11:\"Child Tax 3\";}}',	'3',	'default.jpg',	1,	1,	'Kg',	'',	8800.00,	8000.00,	0.00),
(2,	1,	'alll',	'alll',	'78',	2147483645,	8900.00,	10000.00,	'2022-06-27',	'2022-05-06',	'nill',	'this is batch 4			',	'09890',	7,	0,	800000000.00,	'0989',	'right coner',	'a:3:{i:0;a:4:{s:6:\"tax_id\";s:1:\"2\";s:14:\"tax_percentage\";s:1:\"0\";s:15:\"parent_tax_name\";s:10:\"Parent Tax\";s:14:\"child_tax_name\";s:11:\"Child Tax 1\";}i:1;a:4:{s:6:\"tax_id\";s:1:\"3\";s:14:\"tax_percentage\";s:1:\"0\";s:15:\"parent_tax_name\";s:10:\"Parent Tax\";s:14:\"child_tax_name\";s:11:\"Child Tax 2\";}i:2;a:4:{s:6:\"tax_id\";s:1:\"4\";s:14:\"tax_percentage\";s:1:\"0\";s:15:\"parent_tax_name\";s:10:\"Parent Tax\";s:14:\"child_tax_name\";s:11:\"Child Tax 3\";}}',	'3',	'default.jpg',	1,	1,	'Kg',	'80',	8000.00,	9000.00,	8.00),
(3,	1,	'Panadol',	'Paracetamol',	'10',	9,	8900.00,	90000.00,	'1970-01-01',	'1970-01-01',	'',	'								',	'',	0,	0,	10.00,	'PD123',	'',	'a:3:{i:0;a:4:{s:6:\"tax_id\";s:1:\"2\";s:14:\"tax_percentage\";s:1:\"0\";s:15:\"parent_tax_name\";s:10:\"Parent Tax\";s:14:\"child_tax_name\";s:11:\"Child Tax 1\";}i:1;a:4:{s:6:\"tax_id\";s:1:\"3\";s:14:\"tax_percentage\";s:1:\"0\";s:15:\"parent_tax_name\";s:10:\"Parent Tax\";s:14:\"child_tax_name\";s:11:\"Child Tax 2\";}i:2;a:4:{s:6:\"tax_id\";s:1:\"4\";s:14:\"tax_percentage\";s:1:\"0\";s:15:\"parent_tax_name\";s:10:\"Parent Tax\";s:14:\"child_tax_name\";s:11:\"Child Tax 3\";}}',	'3',	'',	1,	1,	'Kg',	'',	8800.00,	8000.00,	0.00),
(4,	1,	'Panadol',	'alll',	'78',	2147483645,	8900.00,	10000.00,	'1970-01-01',	'2022-06-05',	'nill',	'this is batch 4			',	'9890',	7,	0,	800000000.00,	'989',	'right coner',	'a:3:{i:0;a:4:{s:6:\"tax_id\";s:1:\"2\";s:14:\"tax_percentage\";s:1:\"0\";s:15:\"parent_tax_name\";s:10:\"Parent Tax\";s:14:\"child_tax_name\";s:11:\"Child Tax 1\";}i:1;a:4:{s:6:\"tax_id\";s:1:\"3\";s:14:\"tax_percentage\";s:1:\"0\";s:15:\"parent_tax_name\";s:10:\"Parent Tax\";s:14:\"child_tax_name\";s:11:\"Child Tax 2\";}i:2;a:4:{s:6:\"tax_id\";s:1:\"4\";s:14:\"tax_percentage\";s:1:\"0\";s:15:\"parent_tax_name\";s:10:\"Parent Tax\";s:14:\"child_tax_name\";s:11:\"Child Tax 3\";}}',	'3',	'',	1,	1,	'Kg',	'80',	8000.00,	9000.00,	8.00),
(5,	1,	'parecetum',	'alll',	'78',	2147483645,	8900.00,	10000.00,	'1970-01-01',	'2022-06-05',	'nill',	'this is batch 4			',	'9890',	7,	0,	800000000.00,	'989',	'right coner',	'a:3:{i:0;a:4:{s:6:\"tax_id\";s:1:\"2\";s:14:\"tax_percentage\";s:1:\"0\";s:15:\"parent_tax_name\";s:10:\"Parent Tax\";s:14:\"child_tax_name\";s:11:\"Child Tax 1\";}i:1;a:4:{s:6:\"tax_id\";s:1:\"3\";s:14:\"tax_percentage\";s:1:\"0\";s:15:\"parent_tax_name\";s:10:\"Parent Tax\";s:14:\"child_tax_name\";s:11:\"Child Tax 2\";}i:2;a:4:{s:6:\"tax_id\";s:1:\"4\";s:14:\"tax_percentage\";s:1:\"0\";s:15:\"parent_tax_name\";s:10:\"Parent Tax\";s:14:\"child_tax_name\";s:11:\"Child Tax 3\";}}',	'3',	'',	1,	1,	'Kg',	'80',	8000.00,	9000.00,	8.00),
(6,	1,	'Books',	'alll',	'78',	2147483645,	8900.00,	10000.00,	'1970-01-01',	'2022-06-05',	'nill',	'this is batch 4			',	'9890',	7,	0,	800000000.00,	'989',	'right coner',	'a:3:{i:0;a:4:{s:6:\"tax_id\";s:1:\"2\";s:14:\"tax_percentage\";s:1:\"0\";s:15:\"parent_tax_name\";s:10:\"Parent Tax\";s:14:\"child_tax_name\";s:11:\"Child Tax 1\";}i:1;a:4:{s:6:\"tax_id\";s:1:\"3\";s:14:\"tax_percentage\";s:1:\"0\";s:15:\"parent_tax_name\";s:10:\"Parent Tax\";s:14:\"child_tax_name\";s:11:\"Child Tax 2\";}i:2;a:4:{s:6:\"tax_id\";s:1:\"4\";s:14:\"tax_percentage\";s:1:\"0\";s:15:\"parent_tax_name\";s:10:\"Parent Tax\";s:14:\"child_tax_name\";s:11:\"Child Tax 3\";}}',	'3',	'',	1,	1,	'Kg',	'80',	8000.00,	9000.00,	8.00),
(7,	1,	'Pens',	'alll',	'78',	2147483645,	8900.00,	10000.00,	'1970-01-01',	'2022-06-05',	'nill',	'this is batch 4			',	'9890',	7,	0,	800000000.00,	'989',	'right coner',	'a:3:{i:0;a:4:{s:6:\"tax_id\";s:1:\"2\";s:14:\"tax_percentage\";s:1:\"0\";s:15:\"parent_tax_name\";s:10:\"Parent Tax\";s:14:\"child_tax_name\";s:11:\"Child Tax 1\";}i:1;a:4:{s:6:\"tax_id\";s:1:\"3\";s:14:\"tax_percentage\";s:1:\"0\";s:15:\"parent_tax_name\";s:10:\"Parent Tax\";s:14:\"child_tax_name\";s:11:\"Child Tax 2\";}i:2;a:4:{s:6:\"tax_id\";s:1:\"4\";s:14:\"tax_percentage\";s:1:\"0\";s:15:\"parent_tax_name\";s:10:\"Parent Tax\";s:14:\"child_tax_name\";s:11:\"Child Tax 3\";}}',	'3',	'',	1,	1,	'Kg',	'80',	8000.00,	9000.00,	8.00),
(8,	1,	'penceils',	'alll',	'78',	2147483645,	8900.00,	10000.00,	'1970-01-01',	'2022-06-05',	'nill',	'this is batch 4			',	'9890',	7,	0,	800000000.00,	'989',	'right coner',	'a:3:{i:0;a:4:{s:6:\"tax_id\";s:1:\"2\";s:14:\"tax_percentage\";s:1:\"0\";s:15:\"parent_tax_name\";s:10:\"Parent Tax\";s:14:\"child_tax_name\";s:11:\"Child Tax 1\";}i:1;a:4:{s:6:\"tax_id\";s:1:\"3\";s:14:\"tax_percentage\";s:1:\"0\";s:15:\"parent_tax_name\";s:10:\"Parent Tax\";s:14:\"child_tax_name\";s:11:\"Child Tax 2\";}i:2;a:4:{s:6:\"tax_id\";s:1:\"4\";s:14:\"tax_percentage\";s:1:\"0\";s:15:\"parent_tax_name\";s:10:\"Parent Tax\";s:14:\"child_tax_name\";s:11:\"Child Tax 3\";}}',	'3',	'',	1,	1,	'Kg',	'80',	8000.00,	9000.00,	8.00),
(9,	1,	'sa',	'alll',	'78',	2147483645,	8900.00,	10000.00,	'1970-01-01',	'2022-06-05',	'nill',	'this is batch 4			',	'9890',	7,	0,	800000000.00,	'989',	'right coner',	'a:3:{i:0;a:4:{s:6:\"tax_id\";s:1:\"2\";s:14:\"tax_percentage\";s:1:\"0\";s:15:\"parent_tax_name\";s:10:\"Parent Tax\";s:14:\"child_tax_name\";s:11:\"Child Tax 1\";}i:1;a:4:{s:6:\"tax_id\";s:1:\"3\";s:14:\"tax_percentage\";s:1:\"0\";s:15:\"parent_tax_name\";s:10:\"Parent Tax\";s:14:\"child_tax_name\";s:11:\"Child Tax 2\";}i:2;a:4:{s:6:\"tax_id\";s:1:\"4\";s:14:\"tax_percentage\";s:1:\"0\";s:15:\"parent_tax_name\";s:10:\"Parent Tax\";s:14:\"child_tax_name\";s:11:\"Child Tax 3\";}}',	'3',	'',	1,	1,	'Kg',	'80',	8000.00,	9000.00,	8.00),
(10,	1,	'alll',	'alll',	'78',	2147483645,	8900.00,	10000.00,	'1970-01-01',	'2022-06-05',	'nill',	'this is batch 4			',	'9890',	7,	0,	800000000.00,	'989',	'right coner',	'a:3:{i:0;a:4:{s:6:\"tax_id\";s:1:\"2\";s:14:\"tax_percentage\";s:1:\"0\";s:15:\"parent_tax_name\";s:10:\"Parent Tax\";s:14:\"child_tax_name\";s:11:\"Child Tax 1\";}i:1;a:4:{s:6:\"tax_id\";s:1:\"3\";s:14:\"tax_percentage\";s:1:\"0\";s:15:\"parent_tax_name\";s:10:\"Parent Tax\";s:14:\"child_tax_name\";s:11:\"Child Tax 2\";}i:2;a:4:{s:6:\"tax_id\";s:1:\"4\";s:14:\"tax_percentage\";s:1:\"0\";s:15:\"parent_tax_name\";s:10:\"Parent Tax\";s:14:\"child_tax_name\";s:11:\"Child Tax 3\";}}',	'3',	'',	1,	1,	'Kg',	'80',	8000.00,	9000.00,	8.00),
(11,	1,	'ffff',	'alll',	'78',	2147483645,	8900.00,	10000.00,	'1970-01-01',	'2022-06-05',	'nill',	'this is batch 4			',	'9890',	7,	0,	800000000.00,	'989',	'right coner',	'a:3:{i:0;a:4:{s:6:\"tax_id\";s:1:\"2\";s:14:\"tax_percentage\";s:1:\"0\";s:15:\"parent_tax_name\";s:10:\"Parent Tax\";s:14:\"child_tax_name\";s:11:\"Child Tax 1\";}i:1;a:4:{s:6:\"tax_id\";s:1:\"3\";s:14:\"tax_percentage\";s:1:\"0\";s:15:\"parent_tax_name\";s:10:\"Parent Tax\";s:14:\"child_tax_name\";s:11:\"Child Tax 2\";}i:2;a:4:{s:6:\"tax_id\";s:1:\"4\";s:14:\"tax_percentage\";s:1:\"0\";s:15:\"parent_tax_name\";s:10:\"Parent Tax\";s:14:\"child_tax_name\";s:11:\"Child Tax 3\";}}',	'3',	'',	1,	1,	'Kg',	'80',	8000.00,	9000.00,	8.00),
(12,	1,	'Ibumex',	'alll',	'78',	2147483645,	8900.00,	10000.00,	'1970-01-01',	'2022-06-05',	'nill',	'this is batch 4			',	'9890',	7,	0,	800000000.00,	'989',	'right coner',	'a:3:{i:0;a:4:{s:6:\"tax_id\";s:1:\"2\";s:14:\"tax_percentage\";s:1:\"0\";s:15:\"parent_tax_name\";s:10:\"Parent Tax\";s:14:\"child_tax_name\";s:11:\"Child Tax 1\";}i:1;a:4:{s:6:\"tax_id\";s:1:\"3\";s:14:\"tax_percentage\";s:1:\"0\";s:15:\"parent_tax_name\";s:10:\"Parent Tax\";s:14:\"child_tax_name\";s:11:\"Child Tax 2\";}i:2;a:4:{s:6:\"tax_id\";s:1:\"4\";s:14:\"tax_percentage\";s:1:\"0\";s:15:\"parent_tax_name\";s:10:\"Parent Tax\";s:14:\"child_tax_name\";s:11:\"Child Tax 3\";}}',	'3',	'',	1,	1,	'Kg',	'80',	8000.00,	9000.00,	8.00),
(13,	1,	'dychro',	'alll',	'78',	2147483645,	8900.00,	10000.00,	'1970-01-01',	'2022-06-05',	'nill',	'this is batch 4			',	'9890',	7,	0,	800000000.00,	'989',	'right coner',	'a:3:{i:0;a:4:{s:6:\"tax_id\";s:1:\"2\";s:14:\"tax_percentage\";s:1:\"0\";s:15:\"parent_tax_name\";s:10:\"Parent Tax\";s:14:\"child_tax_name\";s:11:\"Child Tax 1\";}i:1;a:4:{s:6:\"tax_id\";s:1:\"3\";s:14:\"tax_percentage\";s:1:\"0\";s:15:\"parent_tax_name\";s:10:\"Parent Tax\";s:14:\"child_tax_name\";s:11:\"Child Tax 2\";}i:2;a:4:{s:6:\"tax_id\";s:1:\"4\";s:14:\"tax_percentage\";s:1:\"0\";s:15:\"parent_tax_name\";s:10:\"Parent Tax\";s:14:\"child_tax_name\";s:11:\"Child Tax 3\";}}',	'3',	'',	1,	1,	'Kg',	'80',	8000.00,	9000.00,	8.00),
(14,	1,	'xycel',	'alll',	'78',	2147483645,	8900.00,	10000.00,	'1970-01-01',	'2022-06-05',	'nill',	'this is batch 4			',	'9890',	7,	0,	800000000.00,	'989',	'right coner',	'a:3:{i:0;a:4:{s:6:\"tax_id\";s:1:\"2\";s:14:\"tax_percentage\";s:1:\"0\";s:15:\"parent_tax_name\";s:10:\"Parent Tax\";s:14:\"child_tax_name\";s:11:\"Child Tax 1\";}i:1;a:4:{s:6:\"tax_id\";s:1:\"3\";s:14:\"tax_percentage\";s:1:\"0\";s:15:\"parent_tax_name\";s:10:\"Parent Tax\";s:14:\"child_tax_name\";s:11:\"Child Tax 2\";}i:2;a:4:{s:6:\"tax_id\";s:1:\"4\";s:14:\"tax_percentage\";s:1:\"0\";s:15:\"parent_tax_name\";s:10:\"Parent Tax\";s:14:\"child_tax_name\";s:11:\"Child Tax 3\";}}',	'3',	'',	1,	1,	'Kg',	'80',	8000.00,	9000.00,	8.00),
(15,	1,	'pain kill',	'alll',	'78',	2147483645,	8900.00,	10000.00,	'1970-01-01',	'2022-06-05',	'nill',	'this is batch 4			',	'9890',	7,	0,	800000000.00,	'989',	'right coner',	'a:3:{i:0;a:4:{s:6:\"tax_id\";s:1:\"2\";s:14:\"tax_percentage\";s:1:\"0\";s:15:\"parent_tax_name\";s:10:\"Parent Tax\";s:14:\"child_tax_name\";s:11:\"Child Tax 1\";}i:1;a:4:{s:6:\"tax_id\";s:1:\"3\";s:14:\"tax_percentage\";s:1:\"0\";s:15:\"parent_tax_name\";s:10:\"Parent Tax\";s:14:\"child_tax_name\";s:11:\"Child Tax 2\";}i:2;a:4:{s:6:\"tax_id\";s:1:\"4\";s:14:\"tax_percentage\";s:1:\"0\";s:15:\"parent_tax_name\";s:10:\"Parent Tax\";s:14:\"child_tax_name\";s:11:\"Child Tax 3\";}}',	'3',	'',	1,	1,	'Kg',	'80',	8000.00,	9000.00,	8.00),
(16,	1,	'tabs',	'alll',	'78',	2147483645,	8900.00,	10000.00,	'1970-01-01',	'2022-06-05',	'nill',	'this is batch 4			',	'9890',	7,	0,	800000000.00,	'989',	'right coner',	'a:3:{i:0;a:4:{s:6:\"tax_id\";s:1:\"2\";s:14:\"tax_percentage\";s:1:\"0\";s:15:\"parent_tax_name\";s:10:\"Parent Tax\";s:14:\"child_tax_name\";s:11:\"Child Tax 1\";}i:1;a:4:{s:6:\"tax_id\";s:1:\"3\";s:14:\"tax_percentage\";s:1:\"0\";s:15:\"parent_tax_name\";s:10:\"Parent Tax\";s:14:\"child_tax_name\";s:11:\"Child Tax 2\";}i:2;a:4:{s:6:\"tax_id\";s:1:\"4\";s:14:\"tax_percentage\";s:1:\"0\";s:15:\"parent_tax_name\";s:10:\"Parent Tax\";s:14:\"child_tax_name\";s:11:\"Child Tax 3\";}}',	'3',	'',	1,	1,	'Kg',	'80',	8000.00,	9000.00,	8.00),
(17,	1,	'malaria',	'alll',	'78',	2147483645,	8900.00,	10000.00,	'1970-01-01',	'2022-06-05',	'nill',	'this is batch 4			',	'9890',	7,	0,	800000000.00,	'989',	'right coner',	'a:3:{i:0;a:4:{s:6:\"tax_id\";s:1:\"2\";s:14:\"tax_percentage\";s:1:\"0\";s:15:\"parent_tax_name\";s:10:\"Parent Tax\";s:14:\"child_tax_name\";s:11:\"Child Tax 1\";}i:1;a:4:{s:6:\"tax_id\";s:1:\"3\";s:14:\"tax_percentage\";s:1:\"0\";s:15:\"parent_tax_name\";s:10:\"Parent Tax\";s:14:\"child_tax_name\";s:11:\"Child Tax 2\";}i:2;a:4:{s:6:\"tax_id\";s:1:\"4\";s:14:\"tax_percentage\";s:1:\"0\";s:15:\"parent_tax_name\";s:10:\"Parent Tax\";s:14:\"child_tax_name\";s:11:\"Child Tax 3\";}}',	'3',	'',	1,	1,	'Kg',	'80',	8000.00,	9000.00,	8.00),
(18,	1,	'hjdjdj',	'alll',	'78',	2147483645,	8900.00,	10000.00,	'1970-01-01',	'2022-06-05',	'nill',	'this is batch 4			',	'9890',	7,	0,	800000000.00,	'989',	'right coner',	'a:3:{i:0;a:4:{s:6:\"tax_id\";s:1:\"2\";s:14:\"tax_percentage\";s:1:\"0\";s:15:\"parent_tax_name\";s:10:\"Parent Tax\";s:14:\"child_tax_name\";s:11:\"Child Tax 1\";}i:1;a:4:{s:6:\"tax_id\";s:1:\"3\";s:14:\"tax_percentage\";s:1:\"0\";s:15:\"parent_tax_name\";s:10:\"Parent Tax\";s:14:\"child_tax_name\";s:11:\"Child Tax 2\";}i:2;a:4:{s:6:\"tax_id\";s:1:\"4\";s:14:\"tax_percentage\";s:1:\"0\";s:15:\"parent_tax_name\";s:10:\"Parent Tax\";s:14:\"child_tax_name\";s:11:\"Child Tax 3\";}}',	'3',	'',	1,	1,	'Kg',	'80',	8000.00,	9000.00,	8.00),
(19,	1,	'jfjfj',	'alll',	'78',	2147483645,	8900.00,	10000.00,	'1970-01-01',	'2022-06-05',	'nill',	'this is batch 4			',	'9890',	7,	0,	800000000.00,	'989',	'right coner',	'a:3:{i:0;a:4:{s:6:\"tax_id\";s:1:\"2\";s:14:\"tax_percentage\";s:1:\"0\";s:15:\"parent_tax_name\";s:10:\"Parent Tax\";s:14:\"child_tax_name\";s:11:\"Child Tax 1\";}i:1;a:4:{s:6:\"tax_id\";s:1:\"3\";s:14:\"tax_percentage\";s:1:\"0\";s:15:\"parent_tax_name\";s:10:\"Parent Tax\";s:14:\"child_tax_name\";s:11:\"Child Tax 2\";}i:2;a:4:{s:6:\"tax_id\";s:1:\"4\";s:14:\"tax_percentage\";s:1:\"0\";s:15:\"parent_tax_name\";s:10:\"Parent Tax\";s:14:\"child_tax_name\";s:11:\"Child Tax 3\";}}',	'3',	'',	1,	1,	'Kg',	'80',	8000.00,	9000.00,	8.00),
(20,	1,	'nn',	'nj',	'789',	1,	9000.00,	10000.00,	'2023-11-25',	'2021-12-25',	'nill',	'							rxxfxffx	',	'890987',	9,	0,	890.00,	'909899',	'908',	'a:3:{i:0;a:4:{s:6:\"tax_id\";s:1:\"2\";s:14:\"tax_percentage\";s:0:\"\";s:15:\"parent_tax_name\";s:10:\"Parent Tax\";s:14:\"child_tax_name\";s:11:\"Child Tax 1\";}i:1;a:4:{s:6:\"tax_id\";s:1:\"3\";s:14:\"tax_percentage\";s:0:\"\";s:15:\"parent_tax_name\";s:10:\"Parent Tax\";s:14:\"child_tax_name\";s:11:\"Child Tax 2\";}i:2;a:4:{s:6:\"tax_id\";s:1:\"4\";s:14:\"tax_percentage\";s:0:\"\";s:15:\"parent_tax_name\";s:10:\"Parent Tax\";s:14:\"child_tax_name\";s:11:\"Child Tax 3\";}}',	'Finished Products',	'default.jpg',	1,	1,	'Kg',	'90',	8500.00,	8000.00,	0.00),
(21,	1,	'AmoxICILIN',	'AmoxICILIN',	'89',	6000,	90000.00,	89000.00,	'2022-06-05',	'2022-06-05',	'nill',	'sdfghjkljhgf',	'qwertyui',	89,	0,	4.00,	'123456789',	'right coner',	'a:3:{i:0;a:4:{s:6:\"tax_id\";s:1:\"2\";s:14:\"tax_percentage\";s:0:\"\";s:15:\"parent_tax_name\";s:10:\"Parent Tax\";s:14:\"child_tax_name\";s:11:\"Child Tax 1\";}i:1;a:4:{s:6:\"tax_id\";s:1:\"3\";s:14:\"tax_percentage\";s:0:\"\";s:15:\"parent_tax_name\";s:10:\"Parent Tax\";s:14:\"child_tax_name\";s:11:\"Child Tax 2\";}i:2;a:4:{s:6:\"tax_id\";s:1:\"4\";s:14:\"tax_percentage\";s:0:\"\";s:15:\"parent_tax_name\";s:10:\"Parent Tax\";s:14:\"child_tax_name\";s:11:\"Child Tax 3\";}}',	'Raw Product',	'default.jpg',	1,	1,	'Kg',	'800',	900000.00,	90000.00,	0.00),
(22,	1,	'sdfghjkl;',	'dfghjkl;',	'6789',	98,	90000.00,	90000.00,	'2022-06-12',	'2022-06-17',	'5467',	'								sdfghjkl,mnbvcwasdfgufd\\zxcvb',	'234567890-098709876543',	67,	0,	65.00,	'34567890',	'right coner',	'a:3:{i:0;a:4:{s:6:\"tax_id\";s:1:\"2\";s:14:\"tax_percentage\";s:0:\"\";s:15:\"parent_tax_name\";s:10:\"Parent Tax\";s:14:\"child_tax_name\";s:11:\"Child Tax 1\";}i:1;a:4:{s:6:\"tax_id\";s:1:\"3\";s:14:\"tax_percentage\";s:0:\"\";s:15:\"parent_tax_name\";s:10:\"Parent Tax\";s:14:\"child_tax_name\";s:11:\"Child Tax 2\";}i:2;a:4:{s:6:\"tax_id\";s:1:\"4\";s:14:\"tax_percentage\";s:2:\"90\";s:15:\"parent_tax_name\";s:10:\"Parent Tax\";s:14:\"child_tax_name\";s:11:\"Child Tax 3\";}}',	'Raw Product',	'default.jpg',	1,	1,	'Kg',	'5678',	9000.00,	90000.00,	0.00);

DROP TABLE IF EXISTS `mp_product_stock`;
CREATE TABLE `mp_product_stock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `generic_name` varchar(255) NOT NULL,
  `mg` varchar(50) NOT NULL,
  `quantity` int(11) NOT NULL,
  `purchase` decimal(11,2) NOT NULL,
  `retail` decimal(11,2) NOT NULL,
  `expire` date NOT NULL,
  `manufacturing` date NOT NULL,
  `sideeffects` varchar(100) NOT NULL,
  `description` varchar(100) NOT NULL,
  `barcode` varchar(255) NOT NULL,
  `min_stock` int(11) NOT NULL,
  `status` int(1) NOT NULL,
  `packsize` decimal(11,2) NOT NULL,
  `sku` varchar(255) NOT NULL,
  `location` varchar(255) NOT NULL,
  `tax` longtext NOT NULL,
  `type` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `brand_id` int(11) NOT NULL,
  `brand_sector_id` int(11) NOT NULL,
  `unit_type` varchar(50) NOT NULL,
  `net_weight` varchar(50) NOT NULL,
  `whole_sale` decimal(11,2) NOT NULL,
  `pack_cost` decimal(11,2) NOT NULL,
  `discount_percentage` decimal(11,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


SET NAMES utf8mb4;

DROP TABLE IF EXISTS `mp_product_type`;
CREATE TABLE `mp_product_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_type` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `mp_product_type` (`id`, `product_type`) VALUES
(3,	'Finished Products'),
(4,	'Raw Product'),
(5,	'Ticket');

DROP TABLE IF EXISTS `mp_purchase`;
CREATE TABLE `mp_purchase` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `transaction_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `in_time` time NOT NULL,
  `supplier_id` int(11) NOT NULL,
  `store` int(11) NOT NULL,
  `invoice_id` int(11) NOT NULL,
  `description` longtext NOT NULL,
  `total_bill` decimal(11,2) NOT NULL,
  `taxes_names` varchar(255) NOT NULL,
  `total_tax_value` decimal(11,2) NOT NULL,
  `payment_type_id` varchar(50) NOT NULL,
  `payment_date` date NOT NULL,
  `total_paid` decimal(11,2) NOT NULL,
  `discount` decimal(11,2) NOT NULL,
  `cus_picture` varchar(255) NOT NULL,
  `status` int(1) NOT NULL,
  `purchase_status` varchar(50) NOT NULL,
  `before_total` decimal(11,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `transaction_id` (`transaction_id`),
  KEY `supplier_id` (`supplier_id`),
  CONSTRAINT `purchase_payee_fk` FOREIGN KEY (`supplier_id`) REFERENCES `mp_payee` (`id`),
  CONSTRAINT `purchase_transaction_fk` FOREIGN KEY (`transaction_id`) REFERENCES `mp_generalentry` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `mp_purchase_order`;
CREATE TABLE `mp_purchase_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `total_bill` decimal(11,2) NOT NULL,
  `date` date NOT NULL,
  `expire_date` date NOT NULL,
  `user` varchar(255) NOT NULL,
  `memo` longtext NOT NULL,
  `payee_id` int(11) NOT NULL,
  `billing` varchar(255) NOT NULL,
  `invoicemessage` varchar(255) NOT NULL,
  `status` int(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `payee_id` (`payee_id`),
  CONSTRAINT `po_payee_fk` FOREIGN KEY (`payee_id`) REFERENCES `mp_payee` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `mp_region`;
CREATE TABLE `mp_region` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `code` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `mp_region` (`id`, `name`, `code`) VALUES
(1,	'No Region',	'0001');

DROP TABLE IF EXISTS `mp_returns`;
CREATE TABLE `mp_returns` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_no` varchar(100) NOT NULL,
  `transaction_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `in_time` time NOT NULL,
  `discount` decimal(11,2) NOT NULL,
  `status` varchar(50) NOT NULL,
  `description` varchar(255) NOT NULL,
  `agentname` varchar(100) NOT NULL,
  `cus_id` int(11) NOT NULL,
  `cus_picture` varchar(255) NOT NULL,
  `delivered_to` varchar(100) NOT NULL,
  `delivered_by` varchar(100) NOT NULL,
  `delivered_date` date NOT NULL,
  `delivered_description` varchar(255) NOT NULL,
  `shippingcharges` decimal(11,2) NOT NULL,
  `prescription_id` int(11) NOT NULL,
  `region_id` int(11) NOT NULL,
  `vehicle_id` int(11) NOT NULL,
  `driver_id` int(11) NOT NULL,
  `payment_method` int(1) NOT NULL,
  `total_gross_amt` decimal(11,2) NOT NULL,
  `total_bill` decimal(11,2) NOT NULL,
  `total_paid` decimal(11,2) NOT NULL,
  `source` int(1) NOT NULL,
  `store_id` int(11) NOT NULL,
  `sales_man_id` int(11) NOT NULL,
  `total_tax` decimal(11,2) NOT NULL,
  `doctor_details` longtext NOT NULL,
  `patient_details` longtext NOT NULL,
  `taxes_names` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `cus_id` (`cus_id`),
  KEY `prescription_id` (`prescription_id`),
  KEY `transaction_id` (`transaction_id`),
  KEY `store_id` (`store_id`),
  KEY `sales_man_id` (`sales_man_id`),
  KEY `invoice_driver_fk` (`driver_id`),
  KEY `invoice_region_fk` (`region_id`),
  KEY `invoice_vehicle_fk` (`vehicle_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `mp_return_sales`;
CREATE TABLE `mp_return_sales` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `product_name` varchar(100) NOT NULL,
  `mg` varchar(255) NOT NULL,
  `price` decimal(11,2) NOT NULL,
  `discount` decimal(11,2) NOT NULL,
  `purchase` decimal(11,2) NOT NULL,
  `qty` int(11) NOT NULL,
  `tax` longtext NOT NULL,
  `sku` varchar(255) NOT NULL,
  `expiry_date` date NOT NULL,
  `brand_name` varchar(255) NOT NULL,
  `brand_sector` varchar(255) NOT NULL,
  `generic_name` varchar(255) NOT NULL,
  `category` varchar(255) NOT NULL,
  `senior_citizen` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `medicine_id` (`product_id`),
  KEY `order_id` (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `mp_sales`;
CREATE TABLE `mp_sales` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `product_name` varchar(100) NOT NULL,
  `mg` varchar(255) NOT NULL,
  `price` decimal(11,2) NOT NULL,
  `discount` decimal(11,2) NOT NULL,
  `purchase` decimal(11,2) NOT NULL,
  `qty` int(11) NOT NULL,
  `tax` longtext NOT NULL,
  `sku` varchar(255) NOT NULL,
  `expiry_date` date NOT NULL,
  `brand_name` varchar(255) NOT NULL,
  `brand_sector` varchar(255) NOT NULL,
  `generic_name` varchar(255) NOT NULL,
  `category` varchar(255) NOT NULL,
  `senior_citizen` varchar(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `medicine_id` (`product_id`),
  KEY `order_id` (`order_id`),
  CONSTRAINT `sales_invoice_fk` FOREIGN KEY (`order_id`) REFERENCES `mp_invoices` (`id`),
  CONSTRAINT `sales_productlist_fk` FOREIGN KEY (`product_id`) REFERENCES `mp_productslist` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `mp_sales` (`id`, `product_id`, `order_id`, `product_name`, `mg`, `price`, `discount`, `purchase`, `qty`, `tax`, `sku`, `expiry_date`, `brand_name`, `brand_sector`, `generic_name`, `category`, `senior_citizen`) VALUES
(1,	2,	1,	'alll',	'78 Kg',	10000.00,	0.00,	8900.00,	60,	'a:3:{i:0;a:4:{s:6:\"tax_id\";s:1:\"2\";s:14:\"tax_percentage\";d:0;s:15:\"parent_tax_name\";s:10:\"Parent Tax\";s:14:\"child_tax_name\";s:11:\"Child Tax 1\";}i:1;a:4:{s:6:\"tax_id\";s:1:\"3\";s:14:\"tax_percentage\";d:0;s:15:\"parent_tax_name\";s:10:\"Parent Tax\";s:14:\"child_tax_name\";s:11:\"Child Tax 2\";}i:2;a:4:{s:6:\"tax_id\";s:1:\"4\";s:14:\"tax_percentage\";d:0;s:15:\"parent_tax_name\";s:10:\"Parent Tax\";s:14:\"child_tax_name\";s:11:\"Child Tax 3\";}}',	'0989',	'2022-06-27',	'Meggi',	'Chocolates',	'alll',	'Hard',	'no'),
(2,	2,	2,	'alll',	'78 Kg',	8000.00,	0.00,	9000.00,	500,	'a:3:{i:0;a:4:{s:6:\"tax_id\";s:1:\"2\";s:14:\"tax_percentage\";d:0;s:15:\"parent_tax_name\";s:10:\"Parent Tax\";s:14:\"child_tax_name\";s:11:\"Child Tax 1\";}i:1;a:4:{s:6:\"tax_id\";s:1:\"3\";s:14:\"tax_percentage\";d:0;s:15:\"parent_tax_name\";s:10:\"Parent Tax\";s:14:\"child_tax_name\";s:11:\"Child Tax 2\";}i:2;a:4:{s:6:\"tax_id\";s:1:\"4\";s:14:\"tax_percentage\";d:0;s:15:\"parent_tax_name\";s:10:\"Parent Tax\";s:14:\"child_tax_name\";s:11:\"Child Tax 3\";}}',	'0989',	'2022-06-27',	'Meggi',	'Chocolates',	'alll',	'Hard',	'no'),
(3,	2,	3,	'alll',	'78 Kg',	10000.00,	8.00,	8900.00,	2,	'a:3:{i:0;a:4:{s:6:\"tax_id\";s:1:\"2\";s:14:\"tax_percentage\";d:0;s:15:\"parent_tax_name\";s:10:\"Parent Tax\";s:14:\"child_tax_name\";s:11:\"Child Tax 1\";}i:1;a:4:{s:6:\"tax_id\";s:1:\"3\";s:14:\"tax_percentage\";d:0;s:15:\"parent_tax_name\";s:10:\"Parent Tax\";s:14:\"child_tax_name\";s:11:\"Child Tax 2\";}i:2;a:4:{s:6:\"tax_id\";s:1:\"4\";s:14:\"tax_percentage\";d:0;s:15:\"parent_tax_name\";s:10:\"Parent Tax\";s:14:\"child_tax_name\";s:11:\"Child Tax 3\";}}',	'0989',	'2022-06-27',	'Meggi',	'Chocolates',	'alll',	'Hard',	'no');

DROP TABLE IF EXISTS `mp_salesman`;
CREATE TABLE `mp_salesman` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `contact` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `ref` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `cus_picture` varchar(255) NOT NULL,
  `status` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `mp_salesman` (`id`, `name`, `contact`, `address`, `description`, `ref`, `date`, `cus_picture`, `status`) VALUES
(1,	'No Salesman',	'123456',	'',	'',	'',	'0000-00-00',	'default.jpg',	0);

DROP TABLE IF EXISTS `mp_sales_orderlist`;
CREATE TABLE `mp_sales_orderlist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `product_name` varchar(100) NOT NULL,
  `mg` varchar(255) NOT NULL,
  `price` decimal(11,2) NOT NULL,
  `discount` decimal(11,2) NOT NULL,
  `purchase` decimal(11,2) NOT NULL,
  `qty` int(11) NOT NULL,
  `tax` longtext NOT NULL,
  `sku` varchar(255) NOT NULL,
  `expiry_date` date NOT NULL,
  `brand_name` varchar(255) NOT NULL,
  `brand_sector` varchar(255) NOT NULL,
  `generic_name` varchar(255) NOT NULL,
  `category` varchar(255) NOT NULL,
  `sales_item` varchar(50) NOT NULL,
  `returned_items` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `medicine_id` (`product_id`),
  KEY `order_id` (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `mp_sales_receipt`;
CREATE TABLE `mp_sales_receipt` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `transaction_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `time_in` time NOT NULL,
  `user` varchar(255) NOT NULL,
  `payee_id` int(11) NOT NULL,
  `method` varchar(255) NOT NULL,
  `ref_no` varchar(255) NOT NULL,
  `billing_address` varchar(255) NOT NULL,
  `total_bill` decimal(11,2) NOT NULL,
  `total_paid` decimal(11,2) NOT NULL,
  `invoicemessage` varchar(255) NOT NULL,
  `memo` varchar(255) NOT NULL,
  `attachment` varchar(255) NOT NULL,
  `total_discount` decimal(11,2) NOT NULL,
  `total_tax` decimal(11,2) NOT NULL,
  `gross_total` decimal(11,2) NOT NULL,
  `parent_tax_name` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `transaction_id` (`transaction_id`),
  KEY `payee_id` (`payee_id`),
  CONSTRAINT `salesreceipt_payee_fk` FOREIGN KEY (`payee_id`) REFERENCES `mp_payee` (`id`),
  CONSTRAINT `salesreceipt_transaction_fk` FOREIGN KEY (`transaction_id`) REFERENCES `mp_generalentry` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `mp_services`;
CREATE TABLE `mp_services` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` longtext NOT NULL,
  `icon` varchar(100) NOT NULL,
  `status` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `mp_sessions`;
CREATE TABLE `mp_sessions` (
  `id` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `ip_address` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `timestamp` int(10) unsigned NOT NULL DEFAULT 0,
  `data` blob NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ci_sessions_timestamp` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `mp_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES
('47g9k9a3nq6t068qnea7hdkpaoevhu9e',	'::1',	1654761638,	'__ci_last_regenerate|i:1654761629;status|a:2:{s:3:\"msg\";s:103:\"<i style=\"color:#fff\" class=\"fa fa-exclamation-triangle\" aria-hidden=\"true\"></i> Enter Email & Password\";s:5:\"alert\";s:6:\"danger\";}__ci_vars|a:1:{s:6:\"status\";s:3:\"old\";}'),
('dpioudblik52ogpb4bjr6q2hr1fira82',	'::1',	1654797312,	'__ci_last_regenerate|i:1654797311;'),
('i2n1c769p0caef7g55v360qdefr7im2f',	'::1',	1654797310,	'__ci_last_regenerate|i:1654797310;user_id|a:2:{s:2:\"id\";s:1:\"1\";s:4:\"name\";s:3:\"Ken\";}'),
('j890r7uh9pjqdn2b11fe0eoee02dbkei',	'::1',	1654764714,	'__ci_last_regenerate|i:1654764713;'),
('q0bpe1spk462k11i8a6o5ft8re5lu0ji',	'::1',	1655457443,	'__ci_last_regenerate|i:1655457443;user_id|a:2:{s:2:\"id\";s:1:\"1\";s:4:\"name\";s:3:\"Ken\";}status|a:2:{s:3:\"msg\";s:94:\"<i style=\"color:#fff\" class=\"fa fa-check-circle-o\" aria-hidden=\"true\"></i> Login  Successfully\";s:5:\"alert\";s:4:\"info\";}__ci_vars|a:1:{s:6:\"status\";s:3:\"old\";}'),
('q9i2qsp7c0t5amcnvih2fkmfvvilkj9s',	'::1',	1654797310,	'__ci_last_regenerate|i:1654797310;user_id|a:2:{s:2:\"id\";s:1:\"1\";s:4:\"name\";s:3:\"Ken\";}'),
('ucp2rvvpj8pjkvu786hq58o31ci06okl',	'127.0.0.1',	1654772722,	'__ci_last_regenerate|i:1654772721;'),
('v3oblc11tqqvaum41squp0votitijrfk',	'::1',	1654760326,	'__ci_last_regenerate|i:1654760309;'),
('vmbe1hqa7hqbaa8pnvsca1rg0aqqnlrm',	'127.0.0.1',	1655456956,	'__ci_last_regenerate|i:1655456955;');

DROP TABLE IF EXISTS `mp_stock`;
CREATE TABLE `mp_stock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mid` int(11) NOT NULL,
  `purchase_id` int(11) NOT NULL,
  `manufacturing` date NOT NULL,
  `expiry` date NOT NULL,
  `qty` int(11) NOT NULL,
  `description` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `added` varchar(255) NOT NULL,
  `purchase` decimal(11,2) NOT NULL,
  `selling` decimal(11,2) NOT NULL,
  `pack_retail_price` decimal(11,2) NOT NULL,
  `pack_purchase_price` decimal(11,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `mid` (`mid`),
  KEY `purchase_id` (`purchase_id`),
  CONSTRAINT `stock_product_fk` FOREIGN KEY (`mid`) REFERENCES `mp_productslist` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `mp_stores`;
CREATE TABLE `mp_stores` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `code` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `mp_stores` (`id`, `name`, `code`, `address`) VALUES
(1,	'Client Store',	'002',	'here goes description'),
(2,	'Kabeer Sons',	'0002',	'Karachi');

DROP TABLE IF EXISTS `mp_subpo_details`;
CREATE TABLE `mp_subpo_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `estimate_id` int(11) NOT NULL,
  `product_id` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `qty` int(11) NOT NULL,
  `price` decimal(11,2) NOT NULL,
  `tax` decimal(11,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `invoice_id` (`estimate_id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `po_sub_fk` FOREIGN KEY (`estimate_id`) REFERENCES `mp_purchase_order` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `mp_sub_entry`;
CREATE TABLE `mp_sub_entry` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL,
  `accounthead` int(11) NOT NULL,
  `amount` decimal(11,2) NOT NULL,
  `type` int(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sid` (`parent_id`),
  KEY `accounthead` (`accounthead`),
  KEY `amount` (`amount`),
  CONSTRAINT `sub_entry_fk` FOREIGN KEY (`parent_id`) REFERENCES `mp_generalentry` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `mp_sub_entry` (`id`, `parent_id`, `accounthead`, `amount`, `type`) VALUES
(1,	7,	2,	600000.00,	0),
(2,	7,	18,	534000.00,	0),
(3,	7,	3,	534000.00,	1),
(4,	7,	19,	600000.00,	1),
(5,	8,	2,	3680000.00,	0),
(6,	8,	18,	4500000.00,	0),
(7,	8,	3,	4500000.00,	1),
(8,	8,	19,	3680000.00,	1),
(9,	9,	2,	18400.00,	0),
(10,	9,	18,	17800.00,	0),
(11,	9,	3,	17800.00,	1),
(12,	9,	19,	18400.00,	1);

DROP TABLE IF EXISTS `mp_sub_expense`;
CREATE TABLE `mp_sub_expense` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `expense_id` int(11) NOT NULL,
  `head_id` int(11) NOT NULL,
  `description` varchar(255) NOT NULL,
  `price` decimal(11,2) NOT NULL,
  `qty` decimal(11,2) NOT NULL,
  `discount` decimal(11,2) NOT NULL,
  `tax` longtext NOT NULL,
  `subtotal` decimal(11,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `expense_id` (`expense_id`),
  KEY `head_id` (`head_id`),
  CONSTRAINT `subexpense_fk` FOREIGN KEY (`expense_id`) REFERENCES `mp_expense` (`id`),
  CONSTRAINT `subexpense_head_fk` FOREIGN KEY (`head_id`) REFERENCES `mp_head` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `mp_sub_purchase`;
CREATE TABLE `mp_sub_purchase` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `purchase_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `mid` int(11) NOT NULL,
  `cost` decimal(11,2) NOT NULL,
  `retail` decimal(11,2) NOT NULL,
  `pack_cost` decimal(11,2) NOT NULL,
  `pack_retail` decimal(11,2) NOT NULL,
  `qty` int(11) NOT NULL,
  `manu_date` date NOT NULL,
  `expiry_date` date NOT NULL,
  `tax_details` longtext NOT NULL,
  `customer_discount` decimal(11,2) NOT NULL,
  `sku` varchar(255) NOT NULL,
  `source` varchar(100) NOT NULL,
  `parent_tax` decimal(11,2) NOT NULL,
  `free_quantity` int(11) NOT NULL,
  `mrp` decimal(11,2) NOT NULL,
  `manufacturer_discount` decimal(11,2) NOT NULL,
  `item_subtotal` decimal(11,2) NOT NULL,
  `unit_qty` int(11) NOT NULL,
  `packsize` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `purchase_id` (`purchase_id`),
  KEY `subpurchase_product_fk` (`mid`),
  CONSTRAINT `sub_purchase_fk` FOREIGN KEY (`purchase_id`) REFERENCES `mp_purchase` (`id`),
  CONSTRAINT `subpurchase_product_fk` FOREIGN KEY (`mid`) REFERENCES `mp_productslist` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `mp_sub_receipt`;
CREATE TABLE `mp_sub_receipt` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sales_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `description` varchar(255) NOT NULL,
  `qty` int(11) NOT NULL,
  `price` decimal(11,2) NOT NULL,
  `tax` longtext NOT NULL,
  `discount` decimal(11,2) NOT NULL,
  `subtotal` decimal(11,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sales_id` (`sales_id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `sales_receipt_fk` FOREIGN KEY (`sales_id`) REFERENCES `mp_sales_receipt` (`id`),
  CONSTRAINT `sub_productlist_fk` FOREIGN KEY (`product_id`) REFERENCES `mp_product` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `mp_supply`;
CREATE TABLE `mp_supply` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `driver_id` int(11) NOT NULL,
  `vehicle_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `region_id` int(11) NOT NULL,
  `town_id` int(11) NOT NULL,
  `expense` decimal(11,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `driver_id` (`driver_id`),
  KEY `vehicle_id` (`vehicle_id`),
  KEY `region_id` (`region_id`),
  KEY `town_id` (`town_id`),
  CONSTRAINT `supply_driver_fk` FOREIGN KEY (`driver_id`) REFERENCES `mp_drivers` (`id`),
  CONSTRAINT `supply_region_fk` FOREIGN KEY (`region_id`) REFERENCES `mp_region` (`id`),
  CONSTRAINT `supply_town_fk` FOREIGN KEY (`town_id`) REFERENCES `mp_town` (`id`),
  CONSTRAINT `supply_vehicle_fk` FOREIGN KEY (`vehicle_id`) REFERENCES `mp_vehicle` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `mp_taxes`;
CREATE TABLE `mp_taxes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tax_parent_name` varchar(255) NOT NULL,
  `tax_parent_id` int(11) NOT NULL,
  `child_tax_name` varchar(255) NOT NULL,
  `is_required` varchar(255) NOT NULL,
  `tax_percentage` decimal(11,2) NOT NULL,
  `tax_type` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `mp_taxes` (`id`, `tax_parent_name`, `tax_parent_id`, `child_tax_name`, `is_required`, `tax_percentage`, `tax_type`) VALUES
(1,	'Parent Tax',	0,	'',	'',	0.00,	'Parent'),
(2,	'Parent Tax',	1,	'Child Tax 1',	'Required',	0.00,	'Child'),
(3,	'Parent Tax',	1,	'Child Tax 2',	'Required',	0.00,	'Child'),
(4,	'Parent Tax',	1,	'Child Tax 3',	'Optional',	0.00,	'Child');

DROP TABLE IF EXISTS `mp_testamonials`;
CREATE TABLE `mp_testamonials` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `cus_picture` varchar(255) NOT NULL,
  `description` longtext NOT NULL,
  `status` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `mp_todolist`;
CREATE TABLE `mp_todolist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `addedby` varchar(255) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `addedby` (`addedby`),
  CONSTRAINT `todo_agent_fk` FOREIGN KEY (`addedby`) REFERENCES `mp_users` (`user_name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `mp_town`;
CREATE TABLE `mp_town` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `region` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `mp_town` (`id`, `name`, `region`) VALUES
(1,	'No Town',	'Region Kabeer');

DROP TABLE IF EXISTS `mp_units`;
CREATE TABLE `mp_units` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `symbol` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `symbol` (`symbol`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `mp_units` (`id`, `name`, `symbol`) VALUES
(1,	'Kilogram',	'Kg'),
(2,	'Mililetre',	'Ml'),
(3,	'Liter',	'ltr'),
(4,	'Pieces',	'Pcs'),
(5,	'Carton',	'Crtn'),
(6,	'Grams',	'GM'),
(7,	'small',	'(S)');

DROP TABLE IF EXISTS `mp_users`;
CREATE TABLE `mp_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(50) NOT NULL,
  `user_email` varchar(50) NOT NULL,
  `user_address` varchar(100) NOT NULL,
  `user_contact_1` varchar(50) NOT NULL,
  `user_contact_2` varchar(50) NOT NULL,
  `cus_picture` varchar(255) NOT NULL,
  `status` int(1) NOT NULL,
  `user_description` varchar(100) NOT NULL,
  `user_password` varchar(255) NOT NULL,
  `user_date` date NOT NULL,
  `agentname` varchar(255) NOT NULL,
  `user_routes` longtext NOT NULL,
  `user_permissions` longtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_name` (`user_name`),
  KEY `user_name_2` (`user_name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `mp_users` (`id`, `user_name`, `user_email`, `user_address`, `user_contact_1`, `user_contact_2`, `cus_picture`, `status`, `user_description`, `user_password`, `user_date`, `agentname`, `user_routes`, `user_permissions`) VALUES
(1,	'Ken',	'ken@acholipride.com',	'Acholi Pride',	'',	'',	'0ee8315d1c15f50103ad8ee46143142b.png',	0,	'admin',	'8cb2237d0679ca88db6464eac60da96345513964',	'2017-08-23',	'Admin',	'a:85:{i:0;s:8:\"homepage\";i:1;s:7:\"product\";i:2;s:8:\"category\";i:3;s:18:\"stock_alert_report\";i:4;s:19:\"product/recent_list\";i:5;s:21:\"product/expired_stock\";i:6;s:21:\"product/product_stock\";i:7;s:9:\"add_stock\";i:8;s:14:\"product/export\";i:9;s:18:\"product/upload_csv\";i:10;s:14:\"product/delete\";i:11;s:13:\"product/popup\";i:12;s:12:\"sales_report\";i:13;s:26:\"sales_report/top_customers\";i:14;s:25:\"sales_report/top_salesman\";i:15;s:23:\"sales_report/brand_sale\";i:16;s:26:\"sales_report/brand_section\";i:17;s:25:\"sales_report/company_wise\";i:18;s:23:\"sales_report/store_wise\";i:19;s:23:\"sales_report/batch_wise\";i:20;s:23:\"reports/purchase_report\";i:21;s:30:\"reports/purchase_return_report\";i:22;s:20:\"reports/sales_report\";i:23;s:27:\"reports/sales_return_report\";i:24;s:10:\"tax_report\";i:25;s:14:\"invoice/manage\";i:26;s:7:\"invoice\";i:27;s:24:\"return_items/return_list\";i:28;s:14:\"stock_transfer\";i:29;s:22:\"invoice/cancel_invoice\";i:30;s:26:\"return_items/cancel_return\";i:31;s:14:\"allow_discount\";i:32;s:12:\"allow_senior\";i:33;s:19:\"bank/written_cheque\";i:34;s:4:\"bank\";i:35;s:17:\"bank/deposit_list\";i:36;s:14:\"bank/bank_book\";i:37;s:23:\"bank/payment_collection\";i:38;s:8:\"purchase\";i:39;s:20:\"purchase/return_list\";i:40;s:14:\"Purchase_order\";i:41;s:24:\"purchase/cancel_purchase\";i:42;s:6:\"supply\";i:43;s:14:\"supply/drivers\";i:44;s:14:\"supply/vehicle\";i:45;s:16:\"supply/sales_man\";i:46;s:10:\"order_list\";i:47;s:13:\"initilization\";i:48;s:26:\"initilization/brand_sector\";i:49;s:20:\"initilization/region\";i:50;s:18:\"initilization/town\";i:51;s:19:\"initilization/units\";i:52;s:20:\"initilization/stores\";i:53;s:26:\"initilization/product_type\";i:54;s:19:\"initilization/taxes\";i:55;s:8:\"accounts\";i:56;s:8:\"vouchers\";i:57;s:24:\"vouchers/credit_vouchers\";i:58;s:17:\"vouchers/payments\";i:59;s:21:\"vouchers/journal_list\";i:60;s:5:\"payee\";i:61;s:26:\"vouchers/open_user_account\";i:62;s:10:\"statements\";i:63;s:26:\"statements/ledger_accounts\";i:64;s:24:\"statements/trail_balance\";i:65;s:27:\"statements/income_statement\";i:66;s:23:\"statements/balancesheet\";i:67;s:30:\"statements/bank_reconciliation\";i:68;s:7:\"profile\";i:69;s:5:\"users\";i:70;s:8:\"todolist\";i:71;s:7:\"expense\";i:72;s:21:\"backup/upload_restore\";i:73;s:16:\"Printer_settings\";i:74;s:20:\"expense/bank_expense\";i:75;s:7:\"service\";i:76;s:6:\"backup\";i:77;s:7:\"company\";i:78;s:8:\"estimate\";i:79;s:13:\"sales_receipt\";i:80;s:11:\"testamonial\";i:81;s:9:\"somewords\";i:82;s:10:\"pharmacist\";i:83;s:6:\"orders\";i:84;s:6:\"layout\";}',	'a:85:{i:0;s:3:\"Yes\";i:1;s:3:\"Yes\";i:2;s:3:\"Yes\";i:3;s:3:\"Yes\";i:4;s:3:\"Yes\";i:5;s:3:\"Yes\";i:6;s:3:\"Yes\";i:7;s:3:\"Yes\";i:8;s:3:\"Yes\";i:9;s:3:\"Yes\";i:10;s:3:\"Yes\";i:11;s:3:\"Yes\";i:12;s:3:\"Yes\";i:13;s:3:\"Yes\";i:14;s:3:\"Yes\";i:15;s:3:\"Yes\";i:16;s:3:\"Yes\";i:17;s:3:\"Yes\";i:18;s:3:\"Yes\";i:19;s:3:\"Yes\";i:20;s:3:\"Yes\";i:21;s:3:\"Yes\";i:22;s:3:\"Yes\";i:23;s:3:\"Yes\";i:24;s:3:\"Yes\";i:25;s:3:\"Yes\";i:26;s:3:\"Yes\";i:27;s:3:\"Yes\";i:28;s:3:\"Yes\";i:29;s:3:\"Yes\";i:30;s:3:\"Yes\";i:31;s:3:\"Yes\";i:32;s:3:\"Yes\";i:33;s:3:\"Yes\";i:34;s:3:\"Yes\";i:35;s:3:\"Yes\";i:36;s:3:\"Yes\";i:37;s:3:\"Yes\";i:38;s:3:\"Yes\";i:39;s:3:\"Yes\";i:40;s:3:\"Yes\";i:41;s:3:\"Yes\";i:42;s:3:\"Yes\";i:43;s:3:\"Yes\";i:44;s:3:\"Yes\";i:45;s:3:\"Yes\";i:46;s:3:\"Yes\";i:47;s:3:\"Yes\";i:48;s:3:\"Yes\";i:49;s:3:\"Yes\";i:50;s:3:\"Yes\";i:51;s:3:\"Yes\";i:52;s:3:\"Yes\";i:53;s:3:\"Yes\";i:54;s:3:\"Yes\";i:55;s:3:\"Yes\";i:56;s:3:\"Yes\";i:57;s:3:\"Yes\";i:58;s:3:\"Yes\";i:59;s:3:\"Yes\";i:60;s:3:\"Yes\";i:61;s:3:\"Yes\";i:62;s:3:\"Yes\";i:63;s:3:\"Yes\";i:64;s:3:\"Yes\";i:65;s:3:\"Yes\";i:66;s:3:\"Yes\";i:67;s:3:\"Yes\";i:68;s:3:\"Yes\";i:69;s:3:\"Yes\";i:70;s:3:\"Yes\";i:71;s:3:\"Yes\";i:72;s:3:\"Yes\";i:73;s:3:\"Yes\";i:74;s:3:\"Yes\";i:75;s:3:\"Yes\";i:76;s:3:\"Yes\";i:77;s:3:\"Yes\";i:78;s:3:\"Yes\";i:79;s:3:\"Yes\";i:80;s:3:\"Yes\";i:81;s:3:\"Yes\";i:82;s:3:\"Yes\";i:83;s:3:\"Yes\";i:84;s:3:\"Yes\";}'),
(5,	'Attendant',	'all@acholipride.com',	'all@acholipride.com',	'0789999999',	'0789999999',	'default.jpg',	0,	'',	'8cb2237d0679ca88db6464eac60da96345513964',	'2020-09-07',	'Attendant',	'a:102:{i:0;s:8:\"homepage\";i:1;s:17:\"dashboard_chart_1\";i:2;s:17:\"dashboard_chart_2\";i:3;s:18:\"dashboard_activity\";i:4;s:18:\"dashboard_shortage\";i:5;s:24:\"dashboard_recently_added\";i:6;s:6:\"tile_1\";i:7;s:6:\"tile_2\";i:8;s:6:\"tile_3\";i:9;s:6:\"tile_4\";i:10;s:6:\"tile_5\";i:11;s:6:\"tile_6\";i:12;s:6:\"tile_7\";i:13;s:6:\"tile_8\";i:14;s:6:\"tile_9\";i:15;s:7:\"tile_10\";i:16;s:7:\"tile_11\";i:17;s:7:\"tile_12\";i:18;s:7:\"product\";i:19;s:8:\"category\";i:20;s:18:\"stock_alert_report\";i:21;s:19:\"product/recent_list\";i:22;s:21:\"product/expired_stock\";i:23;s:21:\"product/product_stock\";i:24;s:9:\"add_stock\";i:25;s:14:\"product/export\";i:26;s:18:\"product/upload_csv\";i:27;s:14:\"product/delete\";i:28;s:13:\"product/popup\";i:29;s:12:\"sales_report\";i:30;s:26:\"sales_report/top_customers\";i:31;s:25:\"sales_report/top_salesman\";i:32;s:23:\"sales_report/brand_sale\";i:33;s:26:\"sales_report/brand_section\";i:34;s:25:\"sales_report/company_wise\";i:35;s:23:\"sales_report/store_wise\";i:36;s:23:\"sales_report/batch_wise\";i:37;s:23:\"reports/purchase_report\";i:38;s:30:\"reports/purchase_return_report\";i:39;s:20:\"reports/sales_report\";i:40;s:27:\"reports/sales_return_report\";i:41;s:10:\"tax_report\";i:42;s:14:\"invoice/manage\";i:43;s:7:\"invoice\";i:44;s:24:\"return_items/return_list\";i:45;s:14:\"stock_transfer\";i:46;s:22:\"invoice/cancel_invoice\";i:47;s:26:\"return_items/cancel_return\";i:48;s:14:\"allow_discount\";i:49;s:12:\"allow_senior\";i:50;s:19:\"bank/written_cheque\";i:51;s:4:\"bank\";i:52;s:17:\"bank/deposit_list\";i:53;s:14:\"bank/bank_book\";i:54;s:23:\"bank/payment_collection\";i:55;s:8:\"purchase\";i:56;s:20:\"purchase/return_list\";i:57;s:14:\"Purchase_order\";i:58;s:24:\"purchase/cancel_purchase\";i:59;s:6:\"supply\";i:60;s:14:\"supply/drivers\";i:61;s:14:\"supply/vehicle\";i:62;s:16:\"supply/sales_man\";i:63;s:10:\"order_list\";i:64;s:13:\"initilization\";i:65;s:26:\"initilization/brand_sector\";i:66;s:20:\"initilization/region\";i:67;s:18:\"initilization/town\";i:68;s:19:\"initilization/units\";i:69;s:20:\"initilization/stores\";i:70;s:26:\"initilization/product_type\";i:71;s:19:\"initilization/taxes\";i:72;s:8:\"accounts\";i:73;s:8:\"vouchers\";i:74;s:24:\"vouchers/credit_vouchers\";i:75;s:17:\"vouchers/payments\";i:76;s:21:\"vouchers/journal_list\";i:77;s:5:\"payee\";i:78;s:26:\"vouchers/open_user_account\";i:79;s:10:\"statements\";i:80;s:26:\"statements/ledger_accounts\";i:81;s:24:\"statements/trail_balance\";i:82;s:27:\"statements/income_statement\";i:83;s:23:\"statements/balancesheet\";i:84;s:30:\"statements/bank_reconciliation\";i:85;s:7:\"profile\";i:86;s:5:\"users\";i:87;s:8:\"todolist\";i:88;s:7:\"expense\";i:89;s:21:\"backup/upload_restore\";i:90;s:16:\"Printer_settings\";i:91;s:20:\"expense/bank_expense\";i:92;s:7:\"service\";i:93;s:6:\"backup\";i:94;s:7:\"company\";i:95;s:8:\"estimate\";i:96;s:13:\"sales_receipt\";i:97;s:11:\"testamonial\";i:98;s:9:\"somewords\";i:99;s:10:\"pharmacist\";i:100;s:6:\"orders\";i:101;s:6:\"layout\";}',	'a:102:{i:0;s:3:\"Yes\";i:1;s:3:\"Yes\";i:2;s:3:\"Yes\";i:3;s:3:\"Yes\";i:4;s:3:\"Yes\";i:5;s:3:\"Yes\";i:6;s:3:\"Yes\";i:7;s:3:\"Yes\";i:8;s:3:\"Yes\";i:9;s:3:\"Yes\";i:10;s:3:\"Yes\";i:11;s:3:\"Yes\";i:12;s:3:\"Yes\";i:13;s:3:\"Yes\";i:14;s:3:\"Yes\";i:15;s:3:\"Yes\";i:16;s:3:\"Yes\";i:17;s:3:\"Yes\";i:18;s:3:\"Yes\";i:19;s:3:\"Yes\";i:20;s:3:\"Yes\";i:21;s:3:\"Yes\";i:22;s:3:\"Yes\";i:23;s:3:\"Yes\";i:24;s:3:\"Yes\";i:25;s:3:\"Yes\";i:26;s:3:\"Yes\";i:27;s:3:\"Yes\";i:28;s:3:\"Yes\";i:29;s:3:\"Yes\";i:30;s:3:\"Yes\";i:31;s:3:\"Yes\";i:32;s:3:\"Yes\";i:33;s:3:\"Yes\";i:34;s:3:\"Yes\";i:35;s:3:\"Yes\";i:36;s:3:\"Yes\";i:37;s:3:\"Yes\";i:38;s:3:\"Yes\";i:39;s:3:\"Yes\";i:40;s:3:\"Yes\";i:41;s:3:\"Yes\";i:42;s:3:\"Yes\";i:43;s:3:\"Yes\";i:44;s:3:\"Yes\";i:45;s:3:\"Yes\";i:46;s:3:\"Yes\";i:47;s:3:\"Yes\";i:48;s:3:\"Yes\";i:49;s:3:\"Yes\";i:50;s:3:\"Yes\";i:51;s:3:\"Yes\";i:52;s:3:\"Yes\";i:53;s:3:\"Yes\";i:54;s:3:\"Yes\";i:55;s:3:\"Yes\";i:56;s:3:\"Yes\";i:57;s:3:\"Yes\";i:58;s:3:\"Yes\";i:59;s:3:\"Yes\";i:60;s:3:\"Yes\";i:61;s:3:\"Yes\";i:62;s:3:\"Yes\";i:63;s:3:\"Yes\";i:64;s:3:\"Yes\";i:65;s:3:\"Yes\";i:66;s:3:\"Yes\";i:67;s:3:\"Yes\";i:68;s:3:\"Yes\";i:69;s:3:\"Yes\";i:70;s:3:\"Yes\";i:71;s:3:\"Yes\";i:72;s:3:\"Yes\";i:73;s:3:\"Yes\";i:74;s:3:\"Yes\";i:75;s:3:\"Yes\";i:76;s:3:\"Yes\";i:77;s:3:\"Yes\";i:78;s:3:\"Yes\";i:79;s:2:\"No\";i:80;s:2:\"No\";i:81;s:2:\"No\";i:82;s:2:\"No\";i:83;s:3:\"Yes\";i:84;s:2:\"No\";i:85;s:3:\"Yes\";i:86;s:2:\"No\";i:87;s:3:\"Yes\";i:88;s:2:\"No\";i:89;s:2:\"No\";i:90;s:2:\"No\";i:91;s:2:\"No\";i:92;s:2:\"No\";i:93;s:2:\"No\";i:94;s:2:\"No\";i:95;s:2:\"No\";i:96;s:2:\"No\";i:97;s:2:\"No\";i:98;s:2:\"No\";i:99;s:3:\"Yes\";i:100;s:2:\"No\";i:101;s:2:\"No\";}');

DROP TABLE IF EXISTS `mp_vehicle`;
CREATE TABLE `mp_vehicle` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `number` varchar(255) NOT NULL,
  `vehicle_id` varchar(255) NOT NULL,
  `chase_no` varchar(255) NOT NULL,
  `engine_no` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `status` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `mp_vehicle` (`id`, `name`, `number`, `vehicle_id`, `chase_no`, `engine_no`, `date`, `status`) VALUES
(1,	'No Vehicle',	'1234567',	'',	'',	'',	'0000-00-00',	0);

DROP TABLE IF EXISTS `mp_words`;
CREATE TABLE `mp_words` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` longtext NOT NULL,
  `icon` varchar(100) NOT NULL,
  `status` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


-- 2022-06-23 12:33:35
