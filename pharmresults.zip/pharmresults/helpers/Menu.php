<?php
/**
 * Menu Items
 * All Project Menu
 * @category  Menu List
 */

class Menu{
	
	
			public static $navbarsideleft = array(
		array(
			'path' => 'home', 
			'label' => 'Home', 
			'icon' => ''
		),
		
		array(
			'path' => 'mp_bank_opening', 
			'label' => 'Mp Bank Opening', 
			'icon' => ''
		),
		
		array(
			'path' => 'mp_bank_transaction', 
			'label' => 'Mp Bank Transaction', 
			'icon' => ''
		),
		
		array(
			'path' => 'mp_bank_transaction_payee', 
			'label' => 'Mp Bank Transaction Payee', 
			'icon' => ''
		),
		
		array(
			'path' => 'mp_banks', 
			'label' => 'Mp Banks', 
			'icon' => ''
		),
		
		array(
			'path' => 'mp_barcode', 
			'label' => 'Mp Barcode', 
			'icon' => ''
		),
		
		array(
			'path' => 'mp_brand', 
			'label' => 'Mp Brand', 
			'icon' => ''
		),
		
		array(
			'path' => 'mp_brand_sector', 
			'label' => 'Mp Brand Sector', 
			'icon' => ''
		),
		
		array(
			'path' => 'mp_category', 
			'label' => 'Mp Category', 
			'icon' => ''
		),
		
		array(
			'path' => 'mp_contactabout', 
			'label' => 'Mp Contactabout', 
			'icon' => ''
		),
		
		array(
			'path' => 'mp_drivers', 
			'label' => 'Mp Drivers', 
			'icon' => ''
		),
		
		array(
			'path' => 'mp_estimate', 
			'label' => 'Mp Estimate', 
			'icon' => ''
		),
		
		array(
			'path' => 'mp_estimate_sales', 
			'label' => 'Mp Estimate Sales', 
			'icon' => ''
		),
		
		array(
			'path' => 'mp_expense', 
			'label' => 'Mp Expense', 
			'icon' => ''
		),
		
		array(
			'path' => 'mp_generalentry', 
			'label' => 'Mp Generalentry', 
			'icon' => ''
		),
		
		array(
			'path' => 'mp_head', 
			'label' => 'Mp Head', 
			'icon' => ''
		),
		
		array(
			'path' => 'mp_invoices', 
			'label' => 'Mp Invoices', 
			'icon' => ''
		),
		
		array(
			'path' => 'mp_langingpage', 
			'label' => 'Mp Langingpage', 
			'icon' => ''
		),
		
		array(
			'path' => 'mp_orders', 
			'label' => 'Mp Orders', 
			'icon' => ''
		),
		
		array(
			'path' => 'mp_payee', 
			'label' => 'Mp Payee', 
			'icon' => ''
		),
		
		array(
			'path' => 'mp_payment_voucher', 
			'label' => 'Mp Payment Voucher', 
			'icon' => ''
		),
		
		array(
			'path' => 'mp_pharmacist', 
			'label' => 'Mp Pharmacist', 
			'icon' => ''
		),
		
		array(
			'path' => 'mp_pre_salesman', 
			'label' => 'Mp Pre Salesman', 
			'icon' => ''
		),
		
		array(
			'path' => 'mp_printer', 
			'label' => 'Mp Printer', 
			'icon' => ''
		),
		
		array(
			'path' => 'mp_product', 
			'label' => 'Mp Product', 
			'icon' => ''
		),
		
		array(
			'path' => 'mp_product_stock', 
			'label' => 'Mp Product Stock', 
			'icon' => ''
		),
		
		array(
			'path' => 'mp_product_type', 
			'label' => 'Mp Product Type', 
			'icon' => ''
		),
		
		array(
			'path' => 'mp_productslist', 
			'label' => 'Mp Productslist', 
			'icon' => ''
		),
		
		array(
			'path' => 'mp_purchase', 
			'label' => 'Mp Purchase', 
			'icon' => ''
		),
		
		array(
			'path' => 'mp_purchase_order', 
			'label' => 'Mp Purchase Order', 
			'icon' => ''
		),
		
		array(
			'path' => 'mp_region', 
			'label' => 'Mp Region', 
			'icon' => ''
		),
		
		array(
			'path' => 'mp_return_sales', 
			'label' => 'Mp Return Sales', 
			'icon' => ''
		),
		
		array(
			'path' => 'mp_returns', 
			'label' => 'Mp Returns', 
			'icon' => ''
		),
		
		array(
			'path' => 'mp_sales', 
			'label' => 'Mp Sales', 
			'icon' => ''
		),
		
		array(
			'path' => 'mp_sales_orderlist', 
			'label' => 'Mp Sales Orderlist', 
			'icon' => ''
		),
		
		array(
			'path' => 'mp_sales_receipt', 
			'label' => 'Mp Sales Receipt', 
			'icon' => ''
		),
		
		array(
			'path' => 'mp_salesman', 
			'label' => 'Mp Salesman', 
			'icon' => ''
		),
		
		array(
			'path' => 'mp_services', 
			'label' => 'Mp Services', 
			'icon' => ''
		),
		
		array(
			'path' => 'mp_sessions', 
			'label' => 'Mp Sessions', 
			'icon' => ''
		),
		
		array(
			'path' => 'mp_stock', 
			'label' => 'Mp Stock', 
			'icon' => ''
		),
		
		array(
			'path' => 'mp_stores', 
			'label' => 'Mp Stores', 
			'icon' => ''
		),
		
		array(
			'path' => 'mp_sub_entry', 
			'label' => 'Mp Sub Entry', 
			'icon' => ''
		),
		
		array(
			'path' => 'mp_sub_expense', 
			'label' => 'Mp Sub Expense', 
			'icon' => ''
		),
		
		array(
			'path' => 'mp_sub_purchase', 
			'label' => 'Mp Sub Purchase', 
			'icon' => ''
		),
		
		array(
			'path' => 'mp_sub_receipt', 
			'label' => 'Mp Sub Receipt', 
			'icon' => ''
		),
		
		array(
			'path' => 'mp_subpo_details', 
			'label' => 'Mp Subpo Details', 
			'icon' => ''
		),
		
		array(
			'path' => 'mp_supply', 
			'label' => 'Mp Supply', 
			'icon' => ''
		),
		
		array(
			'path' => 'mp_taxes', 
			'label' => 'Mp Taxes', 
			'icon' => ''
		),
		
		array(
			'path' => 'mp_testamonials', 
			'label' => 'Mp Testamonials', 
			'icon' => ''
		),
		
		array(
			'path' => 'mp_todolist', 
			'label' => 'Mp Todolist', 
			'icon' => ''
		),
		
		array(
			'path' => 'mp_town', 
			'label' => 'Mp Town', 
			'icon' => ''
		),
		
		array(
			'path' => 'mp_units', 
			'label' => 'Mp Units', 
			'icon' => ''
		),
		
		array(
			'path' => 'mp_users', 
			'label' => 'Mp Users', 
			'icon' => ''
		),
		
		array(
			'path' => 'mp_vehicle', 
			'label' => 'Mp Vehicle', 
			'icon' => ''
		),
		
		array(
			'path' => 'mp_words', 
			'label' => 'Mp Words', 
			'icon' => ''
		)
	);
		
	
	
}